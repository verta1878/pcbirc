John Smith                                      Telephone: 1-800-555-6969
moi@foobar.UUCP                                 Address:   69 Snuffles Lane
                                                           Pandora, KS 99999

This was a sample signature file brought to you by the packager of
UUPC/extended.  Note that it includes the person's real name, telephone
number, and mail address, so that the person can be contacted if the
mail address cannot be replied to.  It does not waste space with "cute"
boxes or drawings.  The only real problem with it is that the quote at
the bottom (this paragraph) is far too long!  :-)
