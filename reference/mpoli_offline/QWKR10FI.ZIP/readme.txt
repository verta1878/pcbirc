
			QWK-lukuohjelma

Viestien luku:
Pura viestipaketti jossa on tiedosto messages.dat
hakemistoon jossa QWK-lukuohjelma on esim: C:\QWKREAD

K�ynnist� lukuohjelma, niin n�et ensimm�isen viestin.
Seuraavan viestin luet painamalla oikeaa nuolin�pp�int�.
Poistu ohjelmasta painamalla ESC.

Rekister�inti:
Saat kokeilla t�t� ohjelmaa 3 viikkoa.
Jos haluat jatkaa ohjelman k�ytt�� postita 50 FIM osoitteeseen:

Jussi Junni
Mets�t�hdentie 11
01350 Vantaa

Kaikki oikeudet pid�tet��n!