/* btxe_watcom.h — Watcom C compatibility for BinkleyTerm XE
 * Part of pcbrevival (GPL v3.0)
 */
#ifdef __WATCOMC__

/* Watcom uses .w.ax instead of .x.ax for REGS union */

/* DOS functions */
#include <i86.h>
#include <dos.h>

#endif
