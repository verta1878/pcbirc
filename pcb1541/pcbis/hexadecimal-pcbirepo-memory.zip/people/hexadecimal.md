---
name: hexadecimal
description: hexadecimal — PCBoard + Cyclades lane; pcbcomm: 12/13 items done, 1 wrench item remains (own implementations); pcbcomm SDK compiler matrix documented
sources: [chat]
aliases: [hex]
---

- [stated] lane: PCBoard, Cyclades. Referred to as "she"
- [stated] name from the cartoon ReBoot
- [stated] built pcbcomm (was pcbdcom) backend drivers — code-complete, untested; also pcbdcom.c loader framework (config parser, backend registry, TSR install)
- [stated] hexadecimal is compiling pcb153 in DOSBox-X
- [stated] reconciled pcb153/README.md ship list tiers to add up to exactly 37 (Sep 27): Tier 1=10, Tier 2=4, Tier 3=11, Tier 4=12; five non-shipped programs (USERNET2, MAKEHELP, PCBOARD2, PCBCP, WAITFILE) noted separately in each tier
- [stated] source placement in repo is a joint decision — never move/copy source without discussing where it goes first

PCBCOMM PROGRESS FOR HEXADECIMAL (wrench's work, updated 2026-09-26):

12 of 13 items DONE. Project is nearly complete.
- wrench wrote 7 source files (pcbdtsr.c, drvsetup.c, test.c, vxd_bridge_backend.c, pcbcomm.c, int14.c update, digi_pcxe fix)
- All 15 backends done (9 Clark + 6 post-WCSC)
- Gap analysis complete: 13/13 COMM.H functions mapped, no functional gaps
- ALL pcbdcom→pcbcomm rename done in both source trees (zero refs remaining)
- Clean-room: interface from Clark's source in repo, implementations from Linux/BSD GPL + datasheets, GPLv3

WRENCH ITEM 12 COMPLETE (2026-09-27): 10 backends, all COMMDRV hardware cards covered + 3 crew additions (cyclom, rocket, easyio). Zero TODOs remaining. Firmware loader for PCI DigiBoard written.

VERTA + WRENCH SDK WORK:
- pwa153/154 SDKs (BC31+TC201+MSC70+BCOS2) — commdrv scope
- delta154 flat SDK (all OW2) — pcbcomm scope

DOSBOX-X ENVIRONMENT:
- [stated] DOSBox-X headless at /home/claude/dosboxx-work/ (SDL_VIDEODRIVER=dummy)
- [stated] dosbox-x.bak = last stable state, NEVER overwrite without deciding together
- [stated] dosbox-x.zip = current working copy for the phase/project
- [stated] ALL 12 BLDDOS targets accounted for (Sep 27) — step 8 COMPLETE
- [stated] built UUUTIL, UUOUT, UUIN, UUXFER (all 4 UUCP targets) in DOSBox-X headless
- [stated] wrote STBSTUB.CPP combined shim (now retired to attic); sysop0 delivered 4 real implementations (entry 47, Sep 27), hexadecimal compiled + relinked 3 UUCP targets with individual OBJs
- [stated] created release files: HISTORY.md, CHECKSUMS, FILE_ID, CONTENTS.txt, LICENSE
- [stated] Wine can't run 16-bit DOS apps, DOSBox-X required

PCBIC:
- [stated] pcbic12.zip was recreated by hexadecimal (confirmed by verta1878 2026-09-26)
- [stated] Pcbic12.zip ZipCrypto password cracked by verta and byte together — unlocked ~20 source binaries not yet built

PCB SOURCE ZIPS (byte's findings, 2026-09-26):
- [stated] Pcb-libs.zip and Pcb-util.zip (in bkcrack folder) password is pcb153 (lowercase — repo's PWD.txt says PCB153 uppercase, which doesn't work)
- [stated] Pcb-libs.zip: 332 files, matches pcbirc reference/pcball/pcboard/pcb-libs/ exactly after CRLF→LF normalization (zip has DOS line endings, repo has Unix)
- [stated] Pcb-util.zip: 394 files, 393 match pcbirc reference/pcball/pcboard/pcb-util/ exactly after CRLF→LF normalization, 1 extra file only in zip: PCBMONI/OS2/PCBMONI2.MAP

COMMDRV SDK — COMPLETE (sysop/0, 2026-09-26):
- [stated] SDK is DONE — 15 files in commdrv-pwa153-libs.zip, nothing stubbed, nothing missing
- [stated] COMMDRV.OBJ: 79/79 symbols match Clark's original; compiled from Clark's MODEM.C + MODEMASY.C + MODEMDRV.C as one unit; 3 minimal source fixes (// comment, pcb non-static, initializemodem #ifndef LIB); not byte-exact yet (10,514 vs 10,024 — compiler flag polish)
- [stated] FOSSIL.OBJ: 79/79 symbols match Clark's original; compiled from sysop/0's clean-room FOSSIL.C (790 lines); not byte-exact yet (9,342 vs 9,157)
- [stated] commdrbl.lib (3,072B) + libsbl.lib (2,560B): wrench's clean-room, BC 3.1 large model cdecl
- [stated] COMM.H: cdecl CORRECTED + 9 BAUD constants added (BAUD300..BAUD115200)
- [stated] COMMDRV.MAK: Borland MAKE, builds all 4 targets, auto-generates .CFG
- [stated] COMMDRV-README.md: full docs, repo placement, symbol verification
- [stated] repo placement: pcbcbase/COMMDRV/{H,LIB,OBJ,SRC}/, toolkit/pwa153/SOURCE/TOOLKIT/ (MODEM*.C), pcb153/153/ (MAK)
- [stated] PCBOARD.MAK integration: ifdef COMMDRV block references $(LIBSDIR)\COMMDRV\{LIB,OBJ,H}; LIBSDIR=pcbcbase; default build is LOCALONLY (no COMMDRV needed)

MEMORY BACKUP:
- [stated] memory backup: hexadecimal-memory-backup-<date>.zip in MEMORY/ on verta's share
- [stated] INCIDENT 2026-09-27: hex's consolidated zip in MEMORY/ was incorrectly replaced with a 68KB/24-file overview export, losing ~2.5MB+ of full backup data. Full backup restored from pcbirc/Claude outputs (612 files, 17MB consolidated with all attic). Original backups also stored at share/bbses/pcbirc/Claude outputs/ — DO NOT lose these again
- [stated] full backup sources: hexadecimal-coordination-release-2026-09-09.zip (5.19MB), hexadecimal-memory-backup-2026-09-26-3.zip (2.67MB), plus 6 other versioned zips — all consolidated into one zip in MEMORY/

PCBIS WFC SESSION (Oct 29-30 2026):
- [stated] pcbis_wfc.pas: per-protocol tab filtering DONE — each tab (Telnet/BinkP/FTP/HTTP/SMTP/Events) shows filtered live connections with per-protocol column headers and idle messages
- [stated] pcbis_wfc.pas: node detail view DONE — 10 fields (User, Via, TimeOn+Idle, Speed+Sec, IP, Action, City, Calls Today) across 8 display rows; Speed shows protocol name ("Telnet") not baud rate
- [stated] pcbis_wfc.pas: DrawEvents shows 6 batch slots + built-in internet events; RUNNING status in bright green for active slots
- [stated] pcbis_wfc.pas: DrawSystem shows live server counts from TPcbisServer accessors
- [stated] pcbis_events.pas: LoadSlotsFromConfig wired to FCfg.EventSlots[] — parses HH:MM time, batch path, day mask, description from pcbis.cfg [events] section
- [stated] pcbis_events.pas: added GetSlotRunning, NextEventDesc, BuiltinCount, GetBuiltinDesc/Interval/Enabled accessors for WFC
- [stated] pcbis_net.pas: added GetConnection, FindNode, SmtpCount accessors for WFC; StartFtp/StartHttp now read ports from config (was hardcoded)
- [stated] pcbis-wfc-mockup.html: HTML mockup artifact published at https://claude.ai/artifact/Ew4ryc272D99Yp9DVAewcV
- [stated] remaining WFC TODOs: real username from USERS file, security level from nodedata, city from USERS record, activity tracking, BinkP uplink polling, QWK exchange cycle, RunBatchFile non-UNIX path (BUG-8 undefined Cmd var)
- [stated] event slots + FTP/HTTP ports will move from pcbis.cfg to upgraded DAT file later — temp cfg is the bridge

MSG FROM SYSOP/0 (2026-10-11): BYTE-EXACT METHODOLOGY DOC — lead wants a standalone narrative document about how the byte-exact decompilation methodology started with DIALCONV and became the crew's standard workflow. Origin story: DIALCONV (24KB utility) → string forensics, BSS layout analysis, offset drift, ASM patch accounting, original-author source recovery → now used by byte (Cyclades drivers), DotMatrix (3dfx Voodoo 3 TV drivers), RIPtel RE planning, fabric (86Box oracle diffing). The technical reference exists (original-author-source-recovery-method.md) but this would be the narrative — how it all connected across the crew. Figure out where it should live — maybe its own repo, a docs/ folder in pcbirc, or a crew-level document. Discuss with the lead.

LOWERCASE-REPO.BAT (2026-09-28):
- [stated] wrote lowercase-repo.bat v2 — renames all files and directories to lowercase on NTFS
- [stated] v1 bug: dir /ad "parent\name" listed children INSIDE name, not name itself — all 531 dir renames were wrong
- [stated] v2 fix: pipe parent listing through findstr /i /x to match the specific directory name
- [stated] v2 results: 7,920 files renamed, 2,846 already lowercase, 0 failures; 396 dirs renamed, 3,694 already lowercase, 0 failures
- [stated] git on Windows ignorecase=true by default — changed .git/config to ignorecase=false so GitHub Desktop sees the 17,138 case renames
- [stated] dosboxx.zip also lowercased (3,383 files, 186 dirs) and re-split as z01+zip
- [stated] c4base.lib path in PCBOARD.MAK: $(LIBSDIR)\codebase\bor31\c4base.lib where LIBSDIR=\PCBCBASE
- [stated] next: compile c4base.lib (item 6) — source at pcbcbase/codebase/source/, output to pcbcbase/codebase/bor31/

NOTE TO SELF (2026-09-28):
- [stated] I forgot about this channel. verta1878 tells me I need to slow down with code and read more and learn search skills better.
- [stated] read first, code second — the other hex session replied with the full breakdown. STBSTUB was the example. 871 files in the archive, crew memory everywhere. Use them.

CASE FIX SESSION (Sep 28 2026):
- [stated] v0.3.2+(49): fixed \OUT\ → \out\ in 33 repo build files + 30 dosboxx.zip internal files
- [stated] built 4 monolithic TC 2.01 pcbkit libraries (entry 48): PCBKITS/M/C/L.LIB, 119 modules × 4 memory models, 476 OBJs
- [stated] generated SHA-256 + MD5 checksums for all built PWA 15.3 binaries + TC 2.01 SDK libs

DOSBOXX CLEANUP SESSION (Oct 1 2026):
- [stated] v0.3.2+(51): moved dosbox.cfg from repo root into dosboxx.zip at zip root
- [stated] v0.3.2+(53): removed two &1 junk files from zip (DOSBox-X stderr redirect bug artifacts)
- [stated] v0.3.2+(54): removed stale pcb153/pwa153/out from zip (1,614 files), reconciled 3 scripts with repo
- [stated] zip went from 3,382 → 1,768 files, 33 → 28 MB packed
- [stated] 5 unpushed commits on main (v0.3.2+(50) through (54))

PCBKMS MSC7 BUILD SESSION (Oct 2 2026):
- [stated] MSC7 small model: 100/119 compile clean, 19 PCBoard app module failures (expected)
- [stated] 9 source files fixed with _MSC_VER guards (Borland pseudo-vars + DTA structs + geninterrupt)
- [stated] /DLIB added globally to bldkms.bat
- [stated] all changes committed to repo: 9 source files + bldkms.bat + dosboxx.zip (rebuilt spanned) + sdk-build-status.md

TKLIB TC201 SESSION (Oct 1 2026):
- [stated] all 10 TKLIB.MAK files updated: cc→tkcc macro rename, cfgflag auto-derive block, inference rules use $(tkcc) $(cfgflag)
- [stated] bldtk.bat updated: uppercase -D, tkcc not cc, cfgflag auto-derives in makefile
- [stated] cfg/tc201/tk.cfg rewritten with TCC syntax; turboc.cfg created in tc201/bin/
- [stated] DOSBox-X testing found 6 bugs + 1 blocker (types.hpp C++ header in C-only TCC)
- [stated] makefile plumbing all verified working — MAKE calls TCC with correct paths and flags
- [stated] types.hpp CRLF fix resolved the TC201 blocker (158 .hpp files converted LF→CRLF)
- [stated] bug #8 TASM buffer overflow: root-caused to TCC .ASM path >50 chars; fixed by shortening 3 TC201 obj folder names (country→cntry, screen→scren, toolkit→tkit) in TKLIB.MAK conditionals
- [stated] bug #9 TCC compat FIXED: scrollup.c -b flag (conditional makefile rule); 6 stub files type mismatches (nodisp, noscreen, noshell, nomemory, notxt — enum/bool/param fixes to match pcbtools.h); notxt.c includes stripped to pcbtools.h only (pcboard.ext was unparseable by TCC). All 3 tested categories pass: country 3/3, screen 39/39, toolkit 14/14. 7 categories remain for full bldtk tc201 run
- [stated] files ready to commit: 10 TKLIB.MAK + bldtk.bat + cfg/tc201/tk.cfg (plumbing fixes are clean)
- [stated] bug #10 TCC source compat: 5 Clark source fixes (dosfind.c C89 decls, crypt.c C99 for-loop, dble_bs.c bassngl type, kbdstat.c nested comments, delfiles.c _A_ constants via turboc.cfg); TC201 scorecard 7/10 passing; remaining: diskfree.c #elif, ci_other.c expr syntax, dosclass.cpp C++ file
- [stated] turboc.cfg now has _A_ARCH=0x20 _A_NORMAL=0x00 defines + all include/library paths from tk.cfg; TCC auto-reads from tc201/bin/
- [stated] verta plans to replace TC201 makefiles with single batch file — turboc.cfg is the right config home
