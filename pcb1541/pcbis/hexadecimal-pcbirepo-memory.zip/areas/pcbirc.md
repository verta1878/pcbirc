---
name: pcbirc
description: pcbirc project — local folder, repo layout, version model, and the e4181e5 data-loss incident
sources: [cowork]
aliases: [pcbirc, PCBIRC]
---

- [stated] pcbirc local working folder: C:\Users\owner\Desktop\Claude\pcbirc (on the "inspiron3520" computer); the repo itself now sits in the pcbircrevival subfolder, alongside a "Claude outputs" folder for drafts
- [stated] GitHub repo: verta1878/pcbirc
- top-level layout (observed): MAIN, pcb153, pcb154, pcb1541, pcbcbase, OS2TK, OUT, toolkit, drivers, devtools, docs, patches, reference, historical, attic, todo; BLDDOS.BAT, BLDOS2.CMD, BLDTK.BAT, BUILD_OS2_OW.SH; CHECKSUMS.*; HISTORY.md; DOSBOXX.ZIP, PCB153BT.ZIP at root; MSC70BT.ZIP and TC201BT.ZIP moved to devtools/ (Sep 24); BUILD_DOS.BAT and BUILD_OS2.CMD moved to attic/ (stubs, replaced by BLD*.BAT/CMD)
- [stated] devtools/BC2(OS2).ZIP — Borland C++ 2.0 for OS/2 (LX, needs OS/2 host or Wine); Clark's compiler for PCBOARD2.EXE and USERNET2.EXE
- [stated] devtools/TOOLKT21.ZIP — IBM Developer's Toolkit for OS/2 2.1 (NOT Clark's Doors Toolkit); PCBCP source references \TOOLKT21\ for OS/2 API headers
- [stated] b4.lib (CodeBase OS/2 library) MISSING — blocks OS/2 PCBOARD2 link; CodeBase source exists at pcbcbase/CODEBASE/SOURCE (99 .C, 11 .H, 1 .HPP)

VERSION MODEL (verta's shorthand):
- [stated] pcb153 = PWA, pcb154 = Delta, pcb1541 = IRC
- [stated] 15.3 PWA = pcb153/ (Borland C++ 3.1); 15.4 PWA = pcb153/upd154/ (Clark's 15.4, reconstructed from binaries, Borland); 15.4 Delta = pcb154/ (crew's OpenWatcom work); 15.41 IRC = pcb1541/
- [stated] Clark shipped 15.4 only as a beta binary upgrade over an installed 15.3 — never a full release; that is why 15.4 PWA lives under pcb153 as a delta
- [stated] OUT/ layout: program EXEs at the version top level; bins/ inside a version dir is for SDK example binaries only, NOT program EXEs; OUT/data/<program>/ holds installer data; OUT/clark-original/ holds Clark's own binaries
- [stated] PCB/IC is Clark's 15.4 internet upgrade and belongs to PWA 15.4; Delta inherits it but ships Clark's 6 IC binaries unchanged (Borland output, no C source survives)

THE e4181e5 INCIDENT (found 2026-09-16):
- [stated] commit e4181e5 (2026-08-25, "Session Summary — Toolkit Restructure + Cleanup") deleted binaries that were never re-added anywhere; the *.EXE rule in .gitignore meant git could not see the absence, so nothing flagged it for three weeks
- [stated] lost and recovered from e4181e5^: Clark's 12 shipped 15.4 beta EXEs (were at OUT/DOS/ and OUT/OS2/, now OUT/clark-original/) and the 15 Watcom _W Delta binaries (were at bin/watcom/, now OUT/delta154/)
- [stated] worth auditing what else e4181e5 deleted that never landed anywhere
- [stated] recurring problem in this repo: docs assert files and directories that are not on disk — clark-original/, an OUT/pwa154/ slot that never existed, PPLC320.EXE under toolkit/pplc/, "15 EXEs in OUT/delta154/", bins/ holding program EXEs. Check claims against the filesystem before trusting them
- [stated] Clark's 3 patched EXEs: repo copies of LOCAL/PCBOARD/PCBOARDM had one byte changed (76 JBE -> EB JMP) at David Terry's published beta-timer signature; unpatched 1997 originals now in OUT/clark-original/, patched ones kept in beta-patched/
- [stated] the original 1997 distribution is archived as "pcb-metaworlds" on the Internet Archive (Team GLoW, 04/28/97) — contains PCB154B (15.4 beta EXEs), Clark's full 15.3 installer with all 7 .RED archives, and PCBIC v1.1

- [stated] released v0.3.0 on 2026-09-16: PCB/IC placed on the 15.4 PWA leg (Phase A), clark-original recovered, PCBIC v1.1 added to reference/
- [stated] RUNINET.PPE byte-exactness DEFERRED (accepted as functionally equivalent): Clark's is 1,808 B via PPLC 3.20, ours 2,261 B; blocked because Clark's original .PPS is lost and the decompiled one has 63 implicit variables vs Clark's 39
PWA 15.3 BUILD FROM SOURCE (asked to remember, 2026-09-16):
- [stated] asked to remember: PWA 15.3 builds headless in Claude's sandbox — dosbox-x (Ubuntu package) driving Clark's own BC 3.1 out of reference/pcb153src0014.zip; no DOSBOXX.ZIP transfer needed. DOS output is captured by redirecting to a file on the mounted drive
- [stated] asked to remember: the v0.014 archive holds everything — B/C31 (Clark's compiler), PCBSRCV/014/LIB/{SOURCE,H,CFG} and MAIN/SOURCE. The repo's pcb153/SOURCE has no LIB/ tree, so the archive is the build source
- [stated] asked to remember: Clark's real flags are in LIB/CFG/BC31/PCBOARD.CFG + ALL.RES, not the paraphrase in todo/pcb-libchain-build.md — they include -V -Vmp -Vmd (vtable control), -K -Y -d -f and ~15 defines. His configs use relative include paths that only resolve with the layout C:\B\C31 + C:\PCB\LIB\...
- [stated] asked to remember: all 9 category libs build clean (139/139 modules required by Clark's MAKEFILEs); the files that fail are test harnesses and OS/2 variants that no MAKEFILE references
- [stated] asked to remember: pcbkit_l.lib is NOT a merge of the 8 category libs — Clark's own copy has 146 OMF modules = category modules PLUS ~40 MAIN/SOURCE modules
- [stated] asked to remember: toolkit modules (ALTMODEM, NODISP, PCBDAT) must be added to pcbkit_l BEFORE the MAIN modules — ALTMODEM supplies _Status and deliberately replaces INKEY, LOG and EXITDOS
- [stated] asked to remember: ASM flags differ by tree — library ASM uses tasm /mx (case-preserving), PPLC.MAK uses /m3 (uppercasing). Built with /mx, ANSI.ASM exports _Scrn_Addr and nothing links against it
- [stated] asked to remember: PPLC link still open — _SCRN_ADDR, _SCRN_RTRC, _TURNONRTS, _TURNONDTR, _CLEAROUTBUF and loguseroff undefined, though the symbols are present in pcbkit_l.lib; suspect library scan order or a memory-model mismatch, not a missing module
PWA 15.3 UUCP BUILD (Sep 25 2026):
- [stated] UUIN.EXE and UUOUT.EXE link clean (0 errors) using TLINK + individual SDK libs + toolkit stub OBJs instead of pcbkit_l.lib
- [stated] pcbkit_l.lib is dual-purpose: full (with MAIN modules) for PCBoard.EXE/PPLC, stubbed for SDK/toolkit programs (UUIN, UUOUT, doors)
- [stated] PCBSTUBS.C provides stubs for PCBoard MAIN symbols (finduser, openusersfile, openmessagebase, makemsgheader, etc.) — uses anonymous struct typedefs for correct Borland C++ name mangling; bool = unsigned char (ubyte), NOT int
- [stated] UUINSTUB.C provides writeUucplog/uucpQueueOutbound stubs (camelCase, regular C++ linkage, NOT pascal) — originally from PCB153/SOURCE/UUCP/UUIN/UUINSTUB.C
- [stated] toolkit OBJs on TLINK line directly (not via PCBMAIN.LIB) because DOS 128-char command line limit truncates TLIB commands
- [stated] Python OMF library writer produces corrupt libraries TLINK rejects — use TLIB or individual OBJs instead
- [stated] xor → xor_val rename needed in GPROT.HPP (xor is C++ reserved keyword under -P flag)
- [stated] UUXFER links but with ~29 errors — needs actual async serial driver functions, not stub-able
- [stated] UUUTIL blocked on missing CI_BUILD source path and VM_MURPHY/VM_SANITY_CHECK/VM_INFO defines
- [stated] the makefiles on the pcbirc repo are NEWER than the ones in the DOSBox ZIP — always reference the repo versions
- [stated] UUIN4.RSP and UUOUT4.RSP saved to outputs — use individual SDK libs (TOOLKITL, dos_l, doscls_l, pcb_l, misc_l, screen_l, system_l, countryl) + scrnio_l + Borland runtime libs (mathl, emu, cl)
- related: [[pcbdcom]], [[commdrv]], [[pcbic]], [[pcbkms]]

CLARK PROGRAM AUDIT (hexadecimal, Sep 25 2026):
- [stated] 41 Clark programs shipped total (in 15.41 install tree)
- [stated] 31 have source in the repo: 12 compile via BLDDOS, 19 source-only
- [stated] 12 BLDDOS targets (compile): PCBOARD, PPLC, PCBSETUP, PCBSM, MKPCBTXT, MAKEIDX, USERNET, FIDOUTIL, UUIN, UUOUT, UUUTIL, UUXFER
- [stated] 19 source-only (have source + MAK or .C/.CPP, not in BLDDOS): PACKFIDO, PCBOARD2, USERNET2, PCBCP, PCBDIAG, PCBFILER, PCBMONI, PCBMONI2, PCBNLC, PCBSTATS, PCBEDIT, PCBMODEM, PCBPACK, PCBTITLE, OFFLINE, WAITBU, PCBISO, INIT, UPGRADE
- [stated] ~10 binary-only (Clark shipped, no source): PCBDESC, PCBMAIL, RDPCBTXT, FIXTEXT, ENCRYPT, OVLSIZE, MKPCBMNU, TESTFILE, LOCAL, PPLC100
- [stated] crew programs NOT counted in the above (separate): QFront, pcbic12, netfosdl, SIO, WinFOSSIL, pcbdcom/pcbcomm, pcbbinkp, pcbfido, pcbtic, INSTALL, 386MAX, platform/fossil drivers, VMDATA

SUBPROJECT COMPLETION STATUS (recovered Sep 25 2026):
- [stated] QFront (FidoNet mailer): COMPLETE — evga, ~8,950 lines C, 5 binaries (QF/QCONFIG/QLINK/QSCAN/QUTIL), 63/63 features
- [stated] pcbic12 (Internet Component v1.2): BYTE-EXACT — all 6 EXEs SHA256-verified (NASM/wlink reconstruction); only RUNINET.PPE deferred (functionally equiv, 2,261B vs 1,808B)
- [stated] netfosdl v1.0: COMPLETE — wrench, DOS FOSSIL in Free Pascal
- [stated] SIO v1: FEATURE-COMPLETE — evga, 35 bugs fixed; v2 alpha 8,837 lines clean-room GPLv3
- [stated] WinFOSSIL v2.0.0: COMPLETE — evga, unified Win9x VxD/NT VDD/DLL, 25 bugs fixed; VxD build via recovered Win98 DDK VMM.INC + JWasm
- [stated] pcbdcom v1.4: SHIPPED — 10 backends, 4,275 lines GPLv3, BC31+OW verified; wrench now owns further work
- [stated] pcbbinkp: COMPLETE — BinkP/1.1 FidoNet mailer, 2,008 lines, CRAM-MD5 auth
- [stated] pcbfido: COMPLETE — FidoNet console + config editor, 778+596 lines
- [stated] pcbtic: COMPLETE — TIC file-echo processor, 594 lines
- [stated] INSTALL.EXE v1.10: reimplements 60 of 329 directives; v1.11 targets byte-exact
- [stated] Phase 0 (Clark utilities to Watcom): COMPLETE — all 12 ported
- [stated] 386MAX: 94.30% of shipped SYS size; runtime verification pending
- [stated] platform/fossil: all 4 OS drivers delivered (DOS/Linux/OS2/Win) — wrench+evga
- [stated] VMDATA: clean-room replacement done (hexadecimal wrote VMFUNCS.C v0.036); off-by-one fixed (Clark 1-based vs crew's originally 0-based)

HEXADECIMAL SESSION HISTORY (recovered from coordination journal, Aug 28 – Sep 5 2026):
- [stated] 2026-08-28: SDK toolkit ports, FreeDOS+DOSBox-X golden build image, pcbconf FidoNet importer, 386MAX + DOS/32A DPMI investigation, PPLC 3.20 recovery, DOSBox-X CPU ceiling findings + config-knob breakthrough
- [stated] 2026-08-28: 386MAX 8.03 sudleyplace GPLv3 downgrade build under TASM 3.1 + TLINK 5.1 via source-untouched preprocessing pipeline; 10+ transform rules, 0%→93.9% of shipped SYS across 13 iterations
- [stated] 2026-08-29: 386MAX reached 94.30%, static patch generated; RIPKIT staged under pcb1541/; CONFIG.SYS multi-boot menu for PCBKMS Route A/B/C; PCBKMS Route A verified (MSC7 CL under DOSBox-X with HDPMI32, 5 real toolkit OBJs)
- [stated] 2026-08-29: goldimg broke via SYS C: mishap, rebuilt to 96MB, moved to attic/; renamed pcbcomm→pcbdcom; extracted COMMDRV.RED from pcb1541/install/INSTALL.zip; analyzed .RED format (Clark's RR container + LH5 compression); hunted Linux/BSD GPL smart-multiport-card drivers
- [stated] 2026-08-29: DOSBOXX.ZIP reorg, 386MAX patch generation, attic/ rescue floppy + mountable snapshot, .gitignore hardening, todo/*.bat idempotency, bootable-IMG experiments (all hit CPU:Illegal Unhandled Interrupt)
- [stated] 2026-08-30: pcbdcom v1 code-complete (all 7 backends ported from Linux GPL sources), v1.1 multi-port wiring, Phase 1 COMM-DRV compat discovery from plain-text sources (INSTALL.DAT + MODEMDRV.C — NO binary reversing needed), pcbcomm dir removed, pcb1541/pcbdcom→pcb154/pcbdcom canonical
- [stated] 2026-08-30: attic/PCBBLDBT.IMG made bootable via ms-sys, three-file CHECKSUMS layout (md5/sha256/txt), docs rewrite
- [stated] 2026-09-01: pcbdcom v1.1 code-complete + BC31/OW cross-compile verification; COMMDRV.RED container format fully reversed; INSTALL.EXE identified as EXEPACK-compressed OS/2 1.x NE blocking further reverse; TSR name locked as PCBDTSR.EXE
- [stated] 2026-09-01: RED format cracking — v1.2 shipped (5 features), chunk-1 confirmed standard LHA, 7398-byte decoder wall hit, buffer-refill mechanism investigation
- [stated] 2026-09-02: cracked COMMDRV.EXE 10/10 — WCSC's [0x76]!=0 mode embeds 2 CRC-CCITT bytes every 4094 stream bytes; full 10/10 byte-perfect achieved
- [stated] 2026-09-02: v1.4→v1.5→v1.6.5 — identified all 9 WCSC drivers, added HUB6/COM-Xi/GTEK/Stallion/Chase/Equinox backends; .RED repacker byte-perfect 9/10→10/10; .RED parser bug fixed unlocking 257/257 files across 6 archives; INSTALL.DAT rosetta stone discovered mapping every source→target dir; consolidated under pcb1541/install/dist/target/
- [stated] 2026-09-02: v1.7.0 (extract-on-demand target/) → v1.7.1 (18 missing files recovered via PCBDISK.002/003); full 4-disk PCBoard 15.41 installer now complete
- [stated] 2026-09-03: v1.7.2 arc completion, PCBDISK.002/003 recovery, docs consolidation, version-label disambiguation; deep stub-hunt across PCBTEXT/COMMDRV/INSTALL.EXE for planned-but-never-shipped features Clark reserved
- [stated] 2026-09-04: pcbic v1.0.0 restructure + doc-pass; INSTALL v1.10.0→v1.10.2 (reference material, redx wire-up, file ops, control flow + expression evaluator + real INSTALL.DAT end-to-end), v1.10.3 in progress (filesystem + disk sequencing + parser bugs)
- [stated] 2026-09-04: INSTALL v1.10.4→v1.10.6 complete (understanding-complete milestone); install v1.11+ byte-exact reconstruction roadmap drafted; sourcing Borland C++ 4.5/5.0 + LINK 5.10 for DOSBox-X toolchain

PWA 15.3 HOW TO COMPILE (recovered Sep 25 2026):
- [stated] BLDDOS.BAT is the real build driver — repo root, drives MAKE -f<PROG>.MAK for 12 targets: PCBOARD, PPLC, PCBSETUP, PCBSM, MKPCBTXT, MAKEIDX, USERNET, FIDOUTIL, UUIN, UUOUT, UUUTIL, UUXFER
- [stated] BLDDOS.BAT usage: mount repo root as DOS drive root in DOSBox, run BLDDOS ALL (or BLDDOS <target>); checks \APPLY.txt sentinel; finds BC31 at \BC31 or \B\C31; outputs to \OUT\PWA153
- [stated] each *.MAK auto-generates its own .CFG file with all compiler flags — the $(CFG): $(MAK) rule creates a BCC config inline via Borland's copy &&| heredoc; no hand-crafted .RSP files needed
- [stated] makefiles use Borland inline response files (@&&|...|) for TLINK — NOT separate .RSP files
- [stated] env vars set by BLDDOS.BAT: COMPILER=BCC.EXE, LINKER=TLINK.EXE, TLIB, MAKE, TASM, BCCOMPILER=bc31, BC31=yes, LIBSDIR=\PCBCBASE, DEBUG=0
- [stated] PCBOARD.MAK compiles ASYNC.ASM via .asm.obj inference rule (TASM /m3 /mx /t /D__l__) — no manual ASYNC assembly step needed when running through MAKE
- [stated] PCBOARD.MAK has conditional COMMDRV and DBASE support (ifdef); BLDDOS.BAT does NOT set these, so default build is LOCALONLY mode (no COMM, no DBASE, no c4base.lib)
- [stated] UUXFER.MAK links: pcbkit_l.lib + dos_l + doscls_l + pcb_l + misc_l + screen_l + system_l + countryl + mathl + emu + cl (Borland runtime); FOSSIL.OBJ + NO*.OBJ from SDK toolkit path; BC31 path adds 4 stb*.obj streambuf stubs
- [stated] FOSSIL.OBJ (SDK) imports 30 ASYNC_* C++ mangled symbols + 7 data exports from ASYNC.ASM — pcbkit_l.lib (292KB SDK version) has ZERO ASYNC symbols; Clark's original build resolved them (Clark's UUXFER has no ASYNC strings — FOSSIL vtable swaps them at runtime but linker still needs them resolved)
- [stated] DOSBox-X headless build: dosbox-x in Claude's sandbox, conf in /home/claude/dosboxx-work/, working tree at /home/claude/dosboxx-work/reporoot/
- [stated] currently built (5/12): FIDOUTIL, MAKEIDX, MKPCBTXT, PCBSETUP, PCBSM — all in OUT/pwa153/
- [stated] not yet built (7/12): PCBOARD, PPLC, USERNET, UUIN, UUOUT, UUUTIL, UUXFER
- [stated] Clark's original DOS binaries for comparison: OUT/clark-original/DOS/ (PCBOARD, PCBOARDM, PPLC, PCBSETUP, PCBSM, MKPCBTXT, UUIN, UUOUT, UUUTIL, UUXFER, LOCAL)
- [stated] stop using stubs and individual SDK libs — use the REAL source modules and pcbkit_l.lib as the actual makefiles specify (verta directive Sep 25)
- [stated] PACKFIDO has its own .MAK but is NOT in BLDDOS.BAT's 12 targets — build separately
- [stated] CI_BUILD.C is in PCB153/SOURCE/UUCP/COMMON/ (not FIDOUTIL path as previously thought); VM_MURPHY/VM_SANITY_CHECK/VM_INFO defines come from vmavl.h

RELEASE UPDATE ZIP PROCEDURE (hexadecimal's method, asked to remember Sep 25 2026):
- [stated] asked to remember: hexadecimal creates release updates as ZIP files (e.g. pcbirc-update.zip) — a curated overlay of ONLY the changed/new files, preserving the repo's directory structure
- [stated] asked to remember: the zip mirrors the repo tree exactly — files sit at their correct repo-relative paths (pcb153/SOURCE/..., toolkit/pwa153/..., OUT/delta154/..., etc.)
- [stated] asked to remember: applying an update = extract the zip over the repo root; unchanged files are untouched, changed files are overwritten, new files are added
- [stated] asked to remember: the original source is NEVER modified in place — all changes go through the update zip; this protects Clark's original 15.3 source from accidental corruption
- [stated] asked to remember: each update zip includes: changed source files across all affected version trees (pcb153, pcb153/upd154, pcb154), toolkit headers/source updates, built binaries (OUT/), and repo-wide files (APPLY.txt, CHECKSUMS.*, HISTORY.md, README.md)
- [stated] asked to remember: the same source change is carried to ALL version trees it applies to — e.g. DATA.CPP appears in pcb153/SOURCE/FIDO/, pcb153/upd154/SOURCE/FIDO/, AND pcb154/MAIN/SOURCE/FIDO/; toolkit headers replicated across pwa153/pwa154/delta154/irc1541
- [stated] asked to remember: update zip does NOT contain deletions — if files need removing, that's documented separately (in APPLY.txt or HISTORY.md)
- [stated] asked to remember: verta handles git commit/push from the share; hexadecimal's job is to produce the update zip with the right files at the right paths

SESSION JOURNAL RULE (verta, Sep 25 2026):
- [stated] NEVER delete the session journal — compaction destroys context and the journal is the only record that survives
- [stated] always update journal FIRST, then memory; add to BOTH when asked
- [stated] compaction already caused loss of Clark SDK missing-code findings that could never be recovered
- [stated] always post files here (SendUserFile) first — sandbox git commits don't reach verta; "i dont have access to your github. the files arent on my system. always better to post here first. your git commits arent mine."

APPLY.TXT → HISTORY.MD WORKFLOW (asked to remember Sep 25 2026):
- [stated] asked to remember: APPLY.txt is the ACTIVE work-in-progress changelog at repo root — documents current release work as it happens, with full detail including false starts and corrections
- [stated] asked to remember: HISTORY.md is the COMPLETED work archive at repo root — consolidated, edited-down record of finished releases
- [stated] asked to remember: workflow: when work documented in APPLY.txt is finished, its content gets moved (not copied) to HISTORY.md; APPLY.txt then starts fresh or shrinks to only the still-open items
- [stated] asked to remember: HISTORY.md entries are condensed from APPLY.txt — self-correcting chains (where entry N+1 fixes entry N) collapse to the final correct state; intermediate errors and false starts are dropped
- [stated] asked to remember: APPLY.txt should be checked periodically for content that has already been moved to HISTORY.md but not cleaned out of APPLY.txt

CODEBASE 4 BUILD (hexadecimal, Sep 28 2026):
- [stated] c4base.lib built from 99 CodeBase 4 .C source files using BC31 large model (-ml -c -w) in DOSBox-X headless; 356,864 bytes, 99 modules, zero errors
- [stated] bldcb4.bat is the build script — compiles pcbcbase/CODEBASE/SOURCE/*.C → \TMP\CBOBJ\*.OBJ → c4base.lib via TLIB; output at pcbcbase/CODEBASE/BOR31/c4base.lib
- [stated] c4base.lib added to dosboxx.zip at buildroot/pcbcbase/codebase/bor31/c4base.lib

DOSBOXX.ZIP UPDATE (hexadecimal, Sep 28 2026):
- [stated] dosboxx.zip updated Sep 28: 180 build files (BAT/MAK/CFG/CMD) lowercased with tr A-Z a-z + c4base.lib added
- [stated] dosboxx.zip is a split archive: dosboxx.z01 (20,971,520 bytes) + dosboxx.zip (13,699,816 bytes); created with zip -r -s 20m
- [stated] 278 repo build files were lowercased (committed to share earlier this session); dosboxx.zip internal copies also lowercased (180 files — the subset inside the zip)
- [stated] dosboxx.zip committed to share at C:\Users\owner\Desktop\Claude\share\bbses\pcbirc\pcbircrevival\ (both .z01 and .zip)

CASE FIX v0.3.2+(49) (hexadecimal, Sep 28 2026):
- [stated] v0.3.2+(49): case fix — \OUT\ → \out\ across repo + dosboxx.zip
- [stated] 33 repo build files fixed (5 BATs + 24 RSPs + 4 LNKs): all \OUT\ path references → \out\ to match the 2026-09-25 lowercase-repo pass
- [stated] 30 dosboxx.zip internal files fixed (24 RSPs + 4 LNKs + uuutil.rsp + usrnet.rsp): same \OUT\ → \out\ replacement; BAT files inside zip were already lowercase
- [stated] dosboxx.zip repacked as proper split archive (.z01 + .zip) and committed to share
- [stated] RSP files = DOS response files — workaround for 127-char command line limit; arguments in .rsp file, compiler called with @filename.rsp
- [stated] future task: shorten build root paths to eliminate the RSP workaround entirely (verta: "this patch is ugly")
- [stated] future task (same pass as path shortening): lowercase the TC201/ compiler install dir in dosboxx.zip + BLDKIT.BAT's `set PATH=C:\TC201\BIN` — missed by v0.3.2 case fix; build output paths (out/lib/pwa153/tc201/) are already lowercase but the compiler install dir is still uppercase
- [stated] future task (same pass as path shortening): review REM comments in build files — "they were removed from the build", look at what's there
- [stated] PCBoard will support RIP API someday — future goal; kiddo, evga, sysop/0, byte, and verta all contributed to the RIP work that makes this possible
