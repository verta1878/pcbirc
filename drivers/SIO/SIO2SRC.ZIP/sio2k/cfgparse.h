/* ====================================================================
 * cfgparse.h — SIO2K Configuration File Data Structures
 * ==================================================================== */

#ifndef CFGPARSE_H
#define CFGPARSE_H

#include <stdio.h>
#include "sio2k_idc.h"

#define MAX_CFG_DEVICES 256

/* Hardware detection mode — HW_xxx values now defined in
 * sio2k_idc.h (shared with uart.c via PHYS_CONFIG.hwMode) rather
 * than duplicated here, so the two can't drift out of sync. */

/* Os2Device section */
typedef struct _OS2DEV_CFG {
    char            name[9];            /* Device name (e.g., "com1")   */
    char            altDriverName[9];   /* IDC driver name ("uart$")    */
    unsigned short  altDriverPort;      /* Port index within driver     */
    unsigned long   lockedBaud;         /* Locked baud rate (0=none)    */
    unsigned char   baudLocked;         /* Non-zero if baud locked      */
    unsigned char   os2Shares;          /* Allow DOS access when open   */
} OS2DEV_CFG;

/* BaseUart section */
typedef struct _BASEUART_CFG {
    unsigned char   hwMode;             /* HW_xxx detection mode        */
    unsigned short  ioAddr;             /* I/O address (0=auto)         */
    unsigned char   exclusiveIRQ;       /* Use IRQ exclusively          */
    unsigned char   superIO;            /* Search for enhanced-UART     */
                                         /* (Super I/O chip) features —  */
                                         /* previously entirely missing; */
                                         /* the real SIO2K.SYS SAMPLE.CFG*/
                                         /* documents this as a global,  */
                                         /* bare keyword (like           */
                                         /* ExclusiveIRQ) that enables   */
                                         /* probing motherboard/IDE-card */
                                         /* UARTs for extended features  */
                                         /* (e.g. faster baud rates)     */
                                         /* beyond plain 16550 behavior. */
} BASEUART_CFG;

/* DosDevice section */
typedef struct _DOSDEV_CFG {
    char            os2DevName[9];      /* Links to Os2Device name      */
    unsigned short  virtualIO;          /* Virtual I/O port (FFFFh=BIOS)*/
    unsigned char   virtualIRQ;         /* Virtual IRQ for DOS session  */
    unsigned char   dosShares;          /* OS/2 can access DOS port     */
    unsigned char   virtualUartType;    /* 0=16450, 1=16550 emulation   */
} DOSDEV_CFG;

/* Complete configuration */
typedef struct _SIO2K_CONFIG {
    int             numOs2Dev;
    int             numBaseUart;
    int             numDosDev;
    unsigned char   superIOEnabled;
    OS2DEV_CFG      os2dev[MAX_CFG_DEVICES];
    BASEUART_CFG    baseuart[MAX_CFG_DEVICES];
    DOSDEV_CFG      dosdev[MAX_CFG_DEVICES];
} SIO2K_CONFIG;

/* Parser functions */
int  CfgParse(const char *filename, SIO2K_CONFIG *pCfg);
void CfgDefault(SIO2K_CONFIG *pCfg);

#endif /* CFGPARSE_H */
