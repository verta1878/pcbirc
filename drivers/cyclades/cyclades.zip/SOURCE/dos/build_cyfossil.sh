#!/bin/sh
# ============================================================
#  CYFOSSIL.SYS build — JWasm + Open Watcom wlink (Linux)
#  16-bit real-mode DOS device driver
# ============================================================
#  Requires:
#    - jwasm  (MASM-compatible assembler, already used
#              elsewhere in this overall project — see
#              fossil-vxd-recovery/build/build_jwasm.sh)
#    - wlink  (Open Watcom linker)
#
#  HONESTY NOTE (2026-08): this follows the same two-step
#  assemble-then-link pattern as the proven WinFOSSIL VxD build
#  (build_jwasm.sh), which was actually run and produced
#  hash-verified output. This script has NOT been run against a
#  real toolchain in this environment — none is available (see
#  DOC/CYFOSSIL_REBUILD_PLAN.md Phase 5). The assemble step
#  (-c, object output) mirrors the VxD build's own verified
#  invocation style, so it's on reasonably solid ground. The
#  link step's exact wlink format string for a raw DOS device
#  driver image (as opposed to the VxD build's "windows vxd
#  dynamic" format, which WAS verified) is NOT independently
#  confirmed here — `format dos com` below is JWasm/wlink's
#  documented mechanism for producing a flat, ORG-0 binary from
#  a .MODEL TINY source with no relocations, which matches this
#  source's structure, but treat it as unverified until it's
#  actually run once a real toolchain is available.
# ============================================================
set -e
JWASM="${JWASM:-jwasm}"
WLINK="${WLINK:-wlink}"
SRC="$(dirname "$0")"
OUT="$SRC/../../out"

mkdir -p "$OUT"

echo "[1/2] Assembling CYFOSSIL.ASM (16-bit real-mode)..."
"$JWASM" -c -Fo"$OUT/CYFOSSIL.obj" -Fl"$OUT/CYFOSSIL.lst" \
    -I"$SRC" "$SRC/CYFOSSIL.ASM"

echo "[2/2] Linking CYFOSSIL.SYS (flat binary, ORG 0)..."
cat > "$OUT/cyfossil.lnk" << LNK
format dos com
file $OUT/CYFOSSIL.obj
name $OUT/CYFOSSIL.SYS
LNK
"$WLINK" @"$OUT/cyfossil.lnk"

echo "Done. $OUT/CYFOSSIL.SYS"
echo ""
echo "Verification note: this produces an assembled image, not a"
echo "hardware-tested one. See DOC/CYFOSSIL_REBUILD_PLAN.md Phase 5"
echo "for exactly what has and hasn't been verified — no DOS/CD1400"
echo "hardware or faithful emulator is available in this environment"
echo "to actually run this against. The link step above specifically"
echo "has not been run at all (see the HONESTY NOTE at the top of"
echo "this file) — confirm it actually produces a loadable image"
echo "before trusting CYFOSSIL.SYS on real hardware."
