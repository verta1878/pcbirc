# CYFOSSIL_AUDIT.md — Corrections Found During Phase 2

While building the consolidated register table for Phase 2
(`SOURCE/dos/cyfossil_regs.inc`), every register offset and bit value
the audit's patch code uses was cross-checked against
`SOURCE/inc/cd1400.h` — the project's own already-verified Windows
driver header, not an external or assumed source. Three real
discrepancies turned up. None of these are hypothetical: each would
have produced genuinely broken behavior if the audit's asm code had
been used as-is.

## 1. CySVRR offset is wrong in the audit text

Audit's "ISR Mode Registers" section states:
> `CySVRR (0xC1) Service Vector Request Register (read-only)`

`cd1400.h` line 50: `#define CySVRR (0x67*2)` = **0xCE**, not 0xC1.

(For comparison, `CyEOSRR` — the register the audit is most careful
about — checks out exactly: audit says `0xC0`, header's `(0x60*2)` =
`0xC0`. So this isn't a case of the audit using a different addressing
convention throughout; it's specifically wrong for SVRR.)

## 2. SRER bit-to-name mapping is wrong in the audit text

Audit's "ISR Mode Registers" section states:
> `CySRER ... Bit 0: RxData ... Bit 2: TxRdy ... Bit 4: MdmCh`

`cd1400.h` lines 154-156:
```
CyMdmCh   0x80   (bit 7, not bit 4)
CyRxData  0x10   (bit 4, not bit 0)
CyTxRdy   0x04   (bit 2 — this one the audit got right)
```

Two of the three SRER enable bits the audit describes are wrong. Had
Phase 2 enabled interrupts using the audit's implied bit 0 (`0x01`)
thinking that was RxData, the ISR would either never fire for receive
data at all, or would be enabling whatever undefined behavior bit 0
actually corresponds to on this chip — silently, with no error, just
a receive path that never works.

## 3. DCD check in CY-1/CY-4 is testing the wrong modem-status bit

Audit's CY-1 and CY-4 patch code, twice each:
```asm
in      al, dx
test    al, 80h           ; DCD bit
jz      .rx_no_carrier    ; Carrier lost — stop waiting
```

`cd1400.h` lines 240-243:
```
CyDSR   0x80
CyCTS   0x40
CyRI    0x20
CyDCD   0x10
```

`0x80` is `CyDSR` (Data Set Ready), not `CyDCD` (Data Carrier Detect).
This is the most functionally serious of the three: CY-1 and CY-4
exist specifically to stop a blocking wait when the remote caller
hangs up. DSR often reflects the modem being powered on and ready,
independent of an actual call being connected — so this check could
fail to detect a real disconnect, silently reintroducing the exact
hang the patch was written to fix, while looking fixed in review
because the code visibly *has* a carrier-check branch.

## Also flagged: CyTxMPTY doesn't exist in the verified header

The audit's CY-8 (Fn08 flush) patch checks `CyTxMPTY` for "TX FIFO
completely empty." No such constant exists anywhere in `cd1400.h` —
not under this name or an obvious alias. Real CD1400 datasheets do
define a TX-empty status bit in CCSR, but since it isn't in this
project's own verified header, Phase 2 does not invent a numeric
value for it. `cyfossil_regs.inc` leaves this one as an explicit
open item for Phase 3 rather than guess.

## What this means going forward

`cyfossil_regs.inc` uses the verified `cd1400.h` values throughout,
not the audit prose's values, for every constant where the two
disagree. Phase 3, when it implements the actual FSC-0015 functions
using this table, will therefore differ from the audit's literal
patch code in these three spots — intentionally, and for exactly the
reason documented here. `CYFOSSIL_AUDIT.md` itself is left as-is
(historical record of what was reviewed and why), with a pointer to
this file rather than silently edited to hide that it had errors.
