# CYFOSSIL.ASM — Phase 1 Specification

Companion to `CYFOSSIL_REBUILD_PLAN.md`. This is the spec-extraction
deliverable for Phase 1: the full FSC-0015 function table, the DOS
device-driver binary format this has to conform to, and the toolchain
decision. No code is written yet — this is the design Phase 2 and 3
build against.

---

## 1. FSC-0015 Function Table

**Confidence key:**
- **CONFIRMED** — taken directly from `CYFOSSIL_AUDIT.md`'s own patch
  code or explicit text; not in question.
- **RECONSTRUCTED** — filled in from general historical FOSSIL-spec
  documentation (this is a long-public BBS-era standard), not
  independently verified against a primary FSC-0015 text in this
  session. Flagged, not asserted with confidence equal to the
  confirmed rows — cross-check against a primary spec copy if one is
  available before finalizing Phase 3 implementation of these rows.
- **STUB** — confirmed by the audit as an intentional no-op.

| AH | Function | Status | Notes |
|----|----------|--------|-------|
| 00h | Set baud rate divisor (BX = divisor or DX:BX rate) | RECONSTRUCTED | Not mentioned in the audit at all. Historical spec has this as a separate function from the AH=04h init/detect below. |
| 01h | Transmit character (AL = char), block until sent | CONFIRMED | CY-4: must busy-wait on TX idle *and* check DCD before sending, not fire-and-forget. |
| 02h | Receive character, block until available | CONFIRMED | CY-1: must busy-wait on RX-ready *and* check DCD; pulls from the ring buffer (see section 3). |
| 03h | Get line/RX status (non-blocking check for data ready) | CONFIRMED | Referenced by CY-9 cross-reference; reports ring buffer count, not a raw hardware register peek. |
| 04h | Initialize FOSSIL driver / detect | CONFIRMED | This is both init *and* the detect signature: returns AX=1954h, BX=max baud, if a FOSSIL driver is resident. CY-7: needs a PortActive bounds check and double-init guard (calling Fn04 twice on an already-open port must not clear pending data). |
| 05h | Deinitialize (close) port | CONFIRMED | Mentioned as needing to pair cleanly with Fn04 (undo whatever Fn04 set up). |
| 06h | Set DTR (and related modem control) | CONFIRMED | CY-3: needs its own standalone entry point (not folded into another function), writes both MSVR1 and MSVR2. |
| 07h | Return timer/tick parameters | STUB | Confirmed intentional no-op in the audit. |
| 08h | Flush output buffer | CONFIRMED | CY-8: must busy-wait on genuine TX-idle, not a fixed iteration count that can return before the buffer is actually empty. |
| 09h | Purge output buffer (discard, don't wait) | RECONSTRUCTED | Distinct from Fn08 (flush = wait for drain; purge = discard immediately). Not covered by the audit. |
| 0Ah | Purge input buffer | RECONSTRUCTED | Ring buffer head=tail=0 reset. Not covered by the audit. |
| 0Bh | Get modem status (CD/RI/DSR/CTS bits) | RECONSTRUCTED | Reads MSVR1/MSVR2 equivalent status; not covered by the audit but the register names it needs are already in the audit's own register table. |
| 0Ch | Peek next input character without removing it | CONFIRMED | CY-5: read ring buffer at current head without advancing — genuinely non-destructive, not a side-effecting read mislabeled as peek. |
| 0Dh | Get FOSSIL driver info block (short form) | RECONSTRUCTED | Likely a smaller/older-format sibling of Fn1B below; historical spec has both a short and long info block call. |
| 0Eh | Set flow control mode (XON/XOFF, RTS/CTS, none) | RECONSTRUCTED | Feeds into the COR2 IXM / SCHR1 / SCHR2 setup the audit documents as part of Fn04's init path — this function is the run-time control point for the same underlying hardware setup. |
| 0Fh | Set flow-control watermarks | RECONSTRUCTED | Pairs with 0Eh; sets the ring-buffer high/low water bytes that decide when XOFF/XON gets sent. |
| 10h | Enable/disable Ctrl-C / Ctrl-Break checking | STUB | Confirmed intentional no-op in the audit. |
| 11h | Get/set FOSSIL driver flags | RECONSTRUCTED | General status/behavior-flags accessor; low-priority, not covered by the audit. |
| 12h | (reserved / not widely implemented) | RECONSTRUCTED | Historical spec leaves some slots sparsely used; treat as a stub returning "not supported" rather than guessing at behavior with no textual basis at all. |
| 13h | Generic escape / driver-specific extension | RECONSTRUCTED | Same treatment as 12h — stub with a clean "not supported" return rather than invented behavior. |
| 14h | Install watchdog timer | STUB | Confirmed intentional no-op in the audit. |
| 15h | Remove watchdog timer | STUB | Confirmed intentional no-op in the audit. |
| 16h | Block read (read multiple characters into a buffer) | CONFIRMED | CY-6: needs a **separate register for the chip data offset**, distinct from the caller's DI (destination buffer index) — the bug was aliasing the two, which corrupts either the read offset or the caller's buffer pointer depending on which register got reused. |
| 17h | Block write (write multiple characters from a buffer) | RECONSTRUCTED | Symmetric counterpart to Fn16; same register-aliasing risk applies by construction — Phase 3 must give it its own dedicated offset register from the start rather than risk reintroducing CY-6's exact bug in the write path. |
| 18h | (reserved) | RECONSTRUCTED | Treat as stub/not-supported, same reasoning as 12h/13h. |
| 19h | Get FOSSIL driver info block (long form) | CONFIRMED | CY-9: must report the *real* ring buffer sizes configured for this build, not a fabricated constant (the audit specifically flags a hardcoded "4096" that didn't match the actual buffer). |
| 1Ah | (reserved) | RECONSTRUCTED | Treat as stub/not-supported. |
| 1Bh | Get FOSSIL driver info block (alternate/compat form) | CONFIRMED | Same real-size-reporting requirement as Fn19 — audit references both together. |

**Reconciling the audit's own count:** `CYFOSSIL_AUDIT.md` says "22 of
27 implemented, 4 stubbed." The table above has 28 slots (00h-1Bh) with
4 confirmed stubs (07h, 10h, 14h, 15h) — that leaves 24 non-stub slots
against the audit's "22 implemented" + "27 total," neither of which
matches 28 exactly. Likely explanation: two of the RECONSTRUCTED
"reserved" slots (12h, 13h, 18h, 1Ah — four candidates for two slots)
were never part of the original driver's function table at all, i.e.
this build only ever spans a 26-slot table, not the full 28 the AH
range allows, and 2 of the 4 "reserved" rows above shouldn't exist as
real slots. **This needs a primary FSC-0015 reference to resolve
cleanly** — Phase 3 should either find one or make an explicit,
documented decision to implement all 4 "reserved" candidates as
uniform not-supported stubs (safe regardless of which 2 are "real"),
which is the current recommendation to avoid blocking on an
unresolved historical-count discrepancy.

---

**Cross-check against the Windows driver (2026-08):** `cyioctl.c`
confirms the underlying hardware mechanism for both RECONSTRUCTED flow
control rows above is real and already implemented there — COR2's
IXM bit plus SCHR1/SCHR2 for XON/XOFF characters (Fn0Eh's register
target), and `HandFlow.XonLimit`/`XoffLimit` fields for the watermark
concept (Fn0Fh's equivalent). This doesn't confirm the exact FSC-0015
calling convention for these two functions, but it confirms the
hardware-level behavior they'd need to drive is real and consistent
with the rest of this project, not invented from nothing.

---

## 2. Binary Format — DOS Device Driver Header

`CYFTST.EXE` expects `DEVICE=CYFOSSIL.SYS` in `CONFIG.SYS`, which means
this has to be a real MS-DOS device driver image, not a plain .COM/.EXE
TSR. This format has been stable and publicly documented since DOS 2.0.

**Header (first 18 bytes of the file, at the load segment's offset 0):**

| Offset | Size | Field | Value for CYFOSSIL |
|--------|------|-------|---------------------|
| 00h | DWORD | Next-driver link | Filled in by DOS at load time; the file should set this to `FFFFFFFFh` |
| 04h | WORD | Attribute word | `8000h` — bit 15 set = character device. No IOCTL bit needed (bit 14) since FOSSIL is accessed via INT 14h, not file I/O. |
| 06h | WORD | Strategy routine offset | Offset of `CyStrategy` (below) |
| 08h | WORD | Interrupt routine offset | Offset of `CyDeviceInt` (below) |
| 0Ah | 8 bytes | Device name, space-padded | `"CYFOSSIL"` (exactly 8 chars, no padding needed) |
| 12h | — | (driver code starts here) | |

**Strategy routine** (`CyStrategy`): DOS calls this with `ES:BX`
pointing at a Request Header. The only job here is to save that
far pointer somewhere the Interrupt routine can retrieve it, then
return — no request processing happens in Strategy itself. This is
the standard, universal pattern for every DOS device driver.

**Interrupt routine** (`CyDeviceInt`): reads the command code at
offset 02h of the saved Request Header. Only one command actually
matters for this driver:

- **`00h` (INIT)** — the one substantive thing this driver's device
  interface does. On this call:
  1. Parse `CONFIG.SYS`'s device-load command-line tail (available via
     the Request Header's INIT-specific fields) for the port number,
     if the driver is meant to support a `DEVICE=CYFOSSIL.SYS 0`-style
     argument selecting which Cyclom-Y channel to bind (open question
     for Phase 2 — check whether the original design took a port
     argument or auto-selected).
  2. Hook `INT 14h`: save the old vector, install `CyInt14Handler`
     (see section 3) as the new one. The new handler must chain to the
     old vector for any AH value outside the FOSSIL range this driver
     claims, per CY-11's dispatch-range-check requirement — extending
     that same principle from "return an error" to "don't break
     whatever else was on INT 14h before this driver loaded."
  3. Set the Request Header's "ending address" field to mark how much
     of this file's resident image DOS should keep in memory (segment
     of the first byte *not* needed — i.e., discard any pure
     load-time-only initialization code from residency if there is
     any; if everything here is needed resident, this is just the end
     of the file).
  4. Set the Request Header's status word to indicate success (`0100h`
     — done bit set, no error).

  All other command codes (`01h` MEDIA CHECK, `04h`/`08h` READ/WRITE,
  `0Dh`/`0Eh` OPEN/CLOSE, etc.) should just set the "done, no error"
  status and return — this driver never expects those calls in normal
  use, since all real communication happens through the hooked INT
  14h vector directly, bypassing the device-driver Strategy/Interrupt
  protocol entirely after INIT completes. This matches why `CYFTST.EXE`
  tests "via INT 14h" and not by opening `\DEV\CYFOSSIL` as a file.

---

## 3. Toolchain Decision

**Recommendation: JWasm**, in 16-bit real-mode assembly mode.

Reasoning:
- Already proven to work in this project's own toolchain — used for
  the WinFOSSIL VxD build (`fossil-vxd-recovery/build/build_jwasm.sh`).
  That build targets 32-bit protected-mode COFF output for an LE-format
  VxD (`-coff -DIS_32`), which doesn't directly apply here, but JWasm
  itself is not limited to that mode — it assembles 16-bit real-mode
  segments and can emit flat binary output suitable for a DOS device
  driver image, which is what's needed.
- Avoids introducing a second, unproven assembler into the project
  when one is already confirmed working.
- `SOURCE/build.sh` (already restored in Phase 0) drives OpenWatcom's
  toolchain for the C sources and the DOS *utilities* — it does not
  currently assemble anything, so there's no existing precedent there
  to match or conflict with.

**Not recommended for now:** OpenWatcom's own `wasm`. It's already used
in this project (via `build.sh`, indirectly through `owcc`/`wcc` for C,
not for assembly), but its MASM-dialect compatibility for the specific
constructs this file will likely need has not been checked in this
session. Worth a second look only if JWasm hits a real blocker.

**Build/link approach for Phase 4** (recorded here since the decision
belongs with the toolchain choice): assemble with JWasm to a flat
binary (not COFF/OMF object + link step, unlike the VxD build) — DOS
device drivers are conventionally built as a single assembled image
with the header at offset 0, no separate linker pass required. This
simplifies Phase 4 relative to the VxD build, which did need `wlink`
for LE-format packaging.

---

## 4. Open Questions for Phase 2

1. Does `CYFOSSIL.SYS` take a port-selection argument on its
   `DEVICE=` line, or does it auto-detect/default to a single port?
   `CYFTST.EXE`'s own usage line (`CYFTST [fossil_port]`) implies the
   *test utility* takes a port argument when calling INT 14h with a
   given port number in DX, which is independent of whether the driver
   itself needs a CONFIG.SYS-line argument — likely the driver just
   needs to detect/init all available Cyclom-Y channels at INIT time
   and let the port number in DX (an FSC-0015 convention already
   implied by the AH function table above) select among them at
   call time, rather than the driver needing its own argument. Confirm
   this reading before Phase 2 writes the INIT-time channel-detection
   loop.
2. Resolve the 26-vs-28-slot table discrepancy from section 1 if a
   primary FSC-0015 reference becomes available; otherwise proceed
   with the documented fallback (all 4 "reserved" candidates as
   uniform stubs).
