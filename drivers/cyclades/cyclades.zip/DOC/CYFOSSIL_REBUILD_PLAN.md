# CYFOSSIL.ASM / CYFOSSIL.SYS — Reconstruction Plan

**Status as of this writing:** Neither the source (`CYFOSSIL.ASM`) nor
the built driver (`CYFOSSIL.SYS`) exists in either the `cyclades.zip`
or `cyclades-driver.zip` archives. Only the diagnostic tools that test
for it (`CYTEST.EXE`, `CYFTST.EXE`, `CYTEST32.EXE`) and a detailed bug
audit (`DOC/CYFOSSIL_AUDIT.md`) exist. This plan covers building it
from scratch, clean-room, using the audit as a partial spec.

**Important distinction from the audit's own framing:** `CYFOSSIL_AUDIT.md`
reads as a set of *patches* against an existing file — several patches
say things like "existing TDR write code follows" or "find the entry
for function 06h and replace the stub," implying a dispatch table and
~10 other FSC-0015 functions already exist elsewhere in a file we
don't have. This plan does not assume that surrounding code is
recoverable; it treats the audit as a partial spec (register map,
ring buffer/ISR design, and 12 of ~22 functions' correct logic) and
fills the rest from the public FSC-0015 FOSSIL specification and the
CD1400 datasheet register model already partially documented in the
audit.

---

## Phase 0 — Baseline & Housekeeping (DONE)

- [x] Diffed `cyclades.zip` against `cyclades-driver.zip`, file by file
- [x] Restored `SOURCE/build.sh` (verified every file it references exists)
- [x] Restored `DOS/README.TXT`
- [x] Restored `i386/SIGNING/SIGNING_WORKFLOW.md` and `x64/SIGNING/SIGNING_WORKFLOW.md`
- [x] Removed `DOC/PCBFOSS_AUDIT.md` (confirmed misplaced — references
      `.pas` files that don't exist anywhere in this project)
- [x] Fixed `FILE_ID.DIZ` bug-count inconsistency (said 10, audit says 12)
- [x] Verified `cytest.cer`/`cytest.pfx` are already byte-identical between
      both packages — no gap
- [x] Verified every `.inf` file (6 locations) already has the x64/NTamd64
      PnP sections the original lacks — ours is ahead here, not behind
- [x] Verified `cypdo.c`/`cyread.c` differences are real improvements already
      in place (a genuine x64 tick-count truncation fix), not regressions

## Phase 1 — Spec Extraction & Architecture Design (DONE — see CYFOSSIL_SPEC.md)

- [x] Enumerate all 28 FSC-0015 function codes (AH=00h-1Bh) against the
      audit's own count ("22 of 27 implemented, 4 stubbed") — reconcile
      the 27 vs 28 discrepancy (likely AH=00h is "detect" and not counted
      as a "function" in the audit's own tally; confirm before building)

      Resolved with a caveat, not fully closed: full table is in
      CYFOSSIL_SPEC.md section 1. The discrepancy turned out to be a
      26-vs-28 mismatch, not 27-vs-28 as first guessed — documented
      openly rather than forced to a false resolution, with a safe
      fallback decision recorded (treat all 4 uncertain "reserved"
      slots as uniform not-supported stubs) so Phase 3 isn't blocked
      on finding a primary spec copy.
- [ ] For the ~10-11 functions NOT covered by the audit (init/detect,
      set baud alone, get/set flow control, comm parameters, etc.),
      write a functional spec for each from the public FSC-0015 document
      and cross-reference against what `cyioctl.c`/`cyserial.c` already
      do in the Windows driver for the equivalent operation — the
      register-level behavior should match even though the calling
      convention differs

      Partially done: every RECONSTRUCTED row in CYFOSSIL_SPEC.md
      section 1 has a functional description. The flow-control rows
      (0Eh/0Fh) were cross-checked against cyioctl.c and confirmed
      grounded in real, already-implemented hardware behavior (COR2
      IXM, SCHR1/SCHR2, XonLimit/XoffLimit). The rest are reconstructed
      from general historical-spec knowledge and explicitly flagged as
      such — not independently verified against a primary FSC-0015 text
      this session, and not further cross-checked against the C driver
      since most (baud rate, purge, modem status, info blocks) don't
      have a direct 1:1 analog to check against there the way flow
      control did.
- [x] Decide the binary format: a real MS-DOS device driver (required
      since `CYFTST.EXE` explicitly expects `DEVICE=CYFOSSIL.SYS` in
      `CONFIG.SYS`) — this means a device driver header (next-pointer,
      attribute word, strategy routine offset, interrupt routine offset,
      8-byte device name) is mandatory, not just a TSR .COM/.EXE. Confirm
      the exact header layout against a DOS DDK reference before writing
      any code that depends on it.

      Full header layout, Strategy/Interrupt routine responsibilities,
      and the INIT-command algorithm are all in CYFOSSIL_SPEC.md
      section 2.
- [x] Decide the assembler/toolchain: `build.sh` doesn't currently build
      a DOS device driver via OpenWatcom's `wasm` — check whether `wasm`
      can produce a device-driver-format binary directly, or whether this
      needs the JWasm/MASM-style toolchain already used for WinFOSSIL's
      VxD work (see `fossil-vxd-recovery` for that toolchain's setup —
      may be directly reusable)

      Decided: JWasm (16-bit real-mode mode), reasoning in
      CYFOSSIL_SPEC.md section 3. Reuses a toolchain already proven in
      this overall project rather than introducing an unproven second
      assembler.

## Phase 2 — Core Infrastructure (DONE — SOURCE/dos/CYFOSSIL.ASM + .INC)

- [x] CD1400 register equate table — consolidated into
      SOURCE/dos/CYFOSSIL.INC, sourced from the authoritative,
      already-working SOURCE/inc/cd1400.h rather than the audit's own
      hex literals.

      **Major correction found during this phase, not a minor
      transcription fix:** the audit's asm fragments access every
      register with `in`/`out` (I/O port instructions). cd1400.h's own
      header states plainly the CD1400 on this board is
      memory-mapped, not I/O-port-mapped — confirmed independently by
      the Windows driver's real access pattern (`MmMapIoSpace` +
      `READ_REGISTER_UCHAR`/`WRITE_REGISTER_UCHAR`) and by
      `DOS/README.TXT`'s own `CYTEST [membase_hex]` usage line. A
      second error: several of the audit's raw hex offsets for
      `CySVRR`/`CyRIVR`/`CyTIVR`/`CyMIVR` don't match cd1400.h's real,
      already-verified values at all (only `CyEOSRR` happened to
      agree, coincidentally). Every equate in CYFOSSIL.INC comes from
      cd1400.h, not the audit. See CYFOSSIL.INC's own header comment
      for the full explanation.
- [x] Ring buffer (RX): 1024 bytes, power-of-2 mask, ISR-fills/Fn02-drains
      — ported from the audit's CY-2, converted to the corrected
      memory-mapped register access model.
- [x] Device driver header + Strategy/Interrupt entry points — see
      CYFOSSIL_SPEC.md section 2 for the design, CYFOSSIL.ASM sections
      1 and 4 for the implementation.
- [x] ISR skeleton wired to the CD1400 interrupt model — CYFOSSIL.ASM
      section 6. Built with a single shared entry/exit rather than the
      audit's three-separate-handlers presentation, specifically so a
      future edit can't add a new exit path that forgets **CyEOSRR**
      (CY-10) — structurally prevented rather than relying on every
      editor remembering it.
- [x] CAR-register race protection (CY-12) — built into the ISR's
      shared entry/exit (save/restore once, not per-service-type),
      per the audit's own "preferred" option.
- [x] TSR installation/residency (INT 14h vector hook + chain-to-original
      for out-of-range AH, per CY-11) — CYFOSSIL.ASM section 7,
      CyInitHandler.

**A third correction found while converting the audit's fragments**
(beyond the memory-mapped and register-offset ones above): the
audit's CY-1/CY-4 carrier checks test bit `80h` on MSVR1 and call it
"DCD." cd1400.h defines `80h` as `CyDSR`, not `CyDCD` — the real
`CyDCD` is `10h`. Using the audit's literal value would have silently
checked DSR instead of DCD, a real-signal mix-up, not a naming slip
(many modems drop DCD on carrier loss while DSR stays asserted).
Every carrier check in the actual source uses the corrected `CyDCD`.

## Phase 3 — FSC-0015 Function Implementation (DONE — see caveats below)

All functions the audit specifies as non-stub are implemented in
CYFOSSIL.ASM section 8, incorporating each of the 12 documented fixes
as correct behavior from the start rather than buggy-then-patched:

- [x] Fn00 — Set baud rate (baud table ported, extended rates included)
- [x] Fn01 — Transmit character (CY-4: idle wait + corrected DCD check)
- [x] Fn02 — Receive character (CY-1: idle wait + corrected DCD check + ring buffer)
- [x] Fn03 — Get RX buffer status (CY-9 cross-ref: reports ring count)
- [x] Fn04 — Initialize port (CY-7: bounds check + double-init protection
      **+ now actually configures the channel's hardware** — see the
      caveat below; this was a real gap even after the audit's own
      patch, closed during this pass)
- [x] Fn05 — Deinitialize port
- [x] Fn06 — DTR control (CY-3: standalone entry point, MSVR1+MSVR2)
- [x] Fn08 — Flush output (CY-8: idle wait; see caveat below on what
      "flush" actually detects in this implementation)
- [x] Fn09 — Purge output (RECONSTRUCTED, uses CyFlushTransFIFO)
- [x] Fn0A — Purge input (RECONSTRUCTED, ring buffer reset only)
- [x] Fn0B — Get modem status (RECONSTRUCTED, live MSVR1 read)
- [x] Fn0C — Peek next byte, non-destructive (CY-5: ring buffer read
      without advancing tail)
- [x] Fn0D — FOSSIL info block, short form (RECONSTRUCTED — see
      CYFOSSIL_SPEC.md's confidence caveat; smallest defensible
      response, not a confirmed layout)
- [x] Fn0E — Set flow control (RECONSTRUCTED, cross-checked against
      cyioctl.c; XON/XOFF only, RTS/CTS hardware flow control deferred)
- [x] Fn0F — Set watermarks (RECONSTRUCTED; currently a no-op — see
      caveat below)
- [x] Fn11 — Get driver flags (RECONSTRUCTED; returns 0, no flags state
      exists yet)
- [x] Fn16 — Block read (CY-6: the ring-buffer architecture makes the
      original ES:DI-vs-chip-offset collision structurally impossible,
      not just carefully avoided — no hardware register is touched
      during a block read at all)
- [x] Fn17 — Block write (RECONSTRUCTED; given its own dedicated
      register for the source pointer from the start, since it has the
      same caller-pointer-plus-implicit-access shape CY-6 warns about)
- [x] Fn19/Fn1B — FOSSIL info block (CY-9: real buffer sizes — 1024 for
      input, 12 for output — not the original's fabricated 4096)
- [x] Fn07/10/14/15 — stubs, per the audit's own documented rationale
- [x] Fn12/13/18/1A — "reserved" slots, per Phase 1's documented
      fallback decision, uniform not-supported rather than guessed at

**Real gap found and closed during this phase:** the audit's own CY-7
patch left channel hardware setup as "...existing channel setup
code..." — i.e. it assumed code this project never had. The initial
port of CY-7 carried this gap forward honestly (flagged, not hidden)
rather than silently claiming Fn04 was complete. Closed by factoring
a `CySetupChannelDefaults` helper (COR1/2/3, RX/TX enable, SRER,
default 9600 baud) out of what used to be channel-0-only inline setup
in `CyInitHandler`, and calling it from Fn04 for whichever channel is
actually being opened — so all 4 channels get real, working
configuration when opened, not just whichever channel happened to be
hardcoded at driver-load time.

**Caveats carried forward honestly, not hidden:**
- Fn08 (flush): the audit's own status bit name, `CyTxMPTY`, doesn't
  exist under that name in cd1400.h. The implementation approximates
  "flushed" using `CyTxEN` ("FIFO has room"), which is not verified
  equivalent to "fully drained including the shift register." Flagged
  in the source itself, not presented as equivalent to the audit's
  (itself unverified) check.
- Fn0F (watermarks): currently a no-op that acknowledges the call
  rather than silently pretending to configure something. No hardware
  watermark mechanism is wired up yet.
- Fn0D (info block, short form): no confirmed short-form layout exists
  anywhere; returns the smallest defensible response (signature + max
  baud) rather than guessing at an undocumented byte layout.
- Single ring buffer, not per-channel: matches the audit's own code
  shape (also single-buffer in every fragment shown), flagged in
  CYFOSSIL.ASM section 2 as a scope decision for a future pass to
  revisit if genuinely concurrent multi-channel use is needed.

## Phase 4 — Build Integration (PARTIAL — script exists, unverified)

- [x] `SOURCE/dos/build_cyfossil.sh` created, following the same
      two-step assemble-then-link pattern as the proven WinFOSSIL VxD
      build script. The assemble step mirrors that script's own
      verified invocation style. **The link step's exact wlink format
      string for a raw DOS device driver image is NOT independently
      confirmed** — no real toolchain available in this environment
      to actually run it (see Phase 5). Flagged in the script's own
      header rather than presented as equivalent to the VxD build's
      genuinely-verified link step.
- [ ] Actually run the build once a real toolchain is available, and
      fix whatever the (currently unverified) link step gets wrong
- [ ] Add a build.sh integration point once the link step above is
      confirmed working (currently a standalone script, not yet
      wired into the main SOURCE/build.sh)
- [ ] Update `DOS/README.TXT` to document `DEVICE=CYFOSSIL.SYS` loading
      alongside the existing `CYTEST`/`CYFTST` usage notes

## Phase 5 — Verification (NOT STARTED)

No DOS/CD1400 hardware or faithful emulator is available in this
sandbox — same limitation as everything else in this project needing
a real runtime. What's actually achievable here:

- [x] Static structural review of the finished source: PROC/ENDP
      balance (33/33), every `fn_table` entry resolves to a defined
      label, every `call` target resolves to a defined label (checked
      twice — first pass had false-positive noise from comment text
      matching "call," redone with a tighter check against actual
      instruction lines only).
- [x] Explicit, itemized confirmation that every one of the 12 audited
      bugs is actually fixed in the final source (not just present in
      the audit doc) — checked each individually against the actual
      code rather than trusting the file's own comments. Two of the
      twelve (CY-5, CY-6) needed a corrected grep pattern after the
      first attempt gave a false negative — redone and confirmed. All
      12 verified genuinely present.
- [x] Explicit confirmation that CY-10 (EOSRR) is written on literally
      every ISR exit path: the entire `cy_isr_entry` procedure contains
      exactly one `iret` instruction, positioned immediately after the
      shared exit's EOSRR write — structurally, no code path can leave
      the ISR without passing through it.
- [x] Honest note in the final docs about what this verification can and
      can't prove: this is static/structural verification only. No
      DOS/CD1400 hardware or faithful emulator is available in this
      sandbox, so none of this has actually been assembled, loaded, or
      run. Recorded plainly here and in CYFOSSIL.ASM/build_cyfossil.sh's
      own comments, not left implicit.

## Phase 6 — Documentation (NOT STARTED)

- [ ] Update `CYFOSSIL_AUDIT.md` status from "patches ready to apply" to
      reflect the actual clean-room build, once it exists
- [ ] Update `FILE_ID.DIZ` / `README.TXT` to mention the DOS driver is
      now buildable, not just the diagnostic tools
- [ ] Update `HANDOFF`-equivalent doc (if one exists for this project —
      check) with the same rigor applied to the SIO/WinFOSSIL handoffs
