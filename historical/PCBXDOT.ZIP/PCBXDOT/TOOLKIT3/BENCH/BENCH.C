#include <stdio.h>
#include "pcbtools.h"

#define ITERATIONS 30000
#define BUFSIZE    1024

void test1(void) {
  FILE *f;
  int  X;

  unlink("BENCH.TST");
  if ((f = fopen("BENCH.TST","w+t")) == NULL) {
    puts("error creating file");
    return;
  }

  setvbuf(f,NULL,_IOFBF,BUFSIZE);
  for (X = 0; X < ITERATIONS; X++)
    fputs("This is a test.  This is only a test.  Testing for the next sixty seconds.\n",f);

  fclose(f);
}

void test2(void) {
  FILE *f;
  char Buf[128];

  if ((f = fopen("BENCH.TST","rt")) == NULL) {
    puts("error opening file");
    return;
  }

  setvbuf(f,NULL,_IOFBF,BUFSIZE);
  while (fgets(Buf,sizeof(Buf),f) != NULL);

  fclose(f);
}


void test3(void) {
  DOSFILE f;
  int     X;

  unlink("BENCH.TST");
  if (dosfopen("BENCH.TST",OPEN_RDWR|OPEN_CREATE,&f) == -1) {
    puts("error creating file");
    return;
  }

  dossetbuf(&f,BUFSIZE);
  for (X = 0; X < ITERATIONS; X++)
    dosfputs("This is a test.  This is only a test.  Testing for the next sixty seconds.\r\n",&f);

  dosfclose(&f);
}

void test4(void) {
  DOSFILE f;
  char    Buf[128];

  if (dosfopen("BENCH.TST",OPEN_READ,&f) == -1) {
    puts("error opening file");
    return;
  }

  dossetbuf(&f,BUFSIZE);
  while (dosfgets(Buf,sizeof(Buf),&f) != -1);

  dosfclose(&f);
}


void main(int argc, char **argv) {
  dosinit();
  switch(argv[1][0]) {
    case '1': test1(); break;
    case '2': test2(); break;
    case '3': test3(); break;
    case '4': test4(); break;
    default : puts("usage:  BENCH [1/2/3/4]");
  }
}
