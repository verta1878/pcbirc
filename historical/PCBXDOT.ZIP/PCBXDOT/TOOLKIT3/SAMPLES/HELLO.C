#include <stdio.h>
#include <pcbtools.h>

void main(void) {
  if (initdoor("TestDoor",0,0,WATCHKBD|WATCHSESSION|READUSERSYS|SHOWSTATUSLINE) == -1)
    return;

  println("Hello world");
  closedoor(FALSE);
}
