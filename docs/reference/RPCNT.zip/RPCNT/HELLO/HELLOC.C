/****************************************************************************\
*                                                                            *
* Listing 5-2                                                                *
*                                                                            *
* HELLOC.C - Client side of automatic binding HELLO program                  *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE HELLO                                                     *
*                                                                            *
* Usage:     HELLOC                                                          *
*                                                                            *
* Comments:  This distributed application prints a string such as            *
*            "Hello, RPC!\n" on the server.  The client uses                 *
*            automatic binding to bind to the server.                        *
*                                                                            *
\****************************************************************************/

#include <STDIO.H>
#include <RPC.H>
#include "hello.h"

void _CRTAPI1 main(void)
   {
   RpcTryExcept
      HelloRPC("Hello, RPC!\n");
   RpcExcept(1)
      printf("The RPC runtime module reported an exception.\n");
   RpcEndExcept
   }

