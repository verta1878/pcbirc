/****************************************************************************\
*                                                                            *
* Listing 5-4                                                                *
*                                                                            *
* HELLOS.C - Server side of automatic binding HELLO program                  *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE HELLO                                                     *
*                                                                            *
* Usage:     HELLOS                                                          *
*                                                                            *
* Comments:  This distributed application prints a string such as            *
*            "Hello, RPC!" on the server.  The client uses                   *
*            automatic binding to bind to the server.                        *
*                                                                            *
\****************************************************************************/

#include <STDLIB.H>
#include <STRING.H>
#include <STDIO.H>
#include <RPC.H>
#include "hello.h"

void _CRTAPI1 main(int argc, char *argv[])
   {
   RPC_STATUS status;
   RPC_BINDING_VECTOR *pBindingVector;

   unsigned char *pszAutoEntryName    = "/.:/Autohandle_sample";
   unsigned char *pszEndpoint         = "\\pipe\\auto";
   unsigned char *pszProtocolSequence = "ncacn_np";
   unsigned char *pszSecurity         = NULL;
   unsigned int   cMinCalls           = 1;
   unsigned int   cMaxCalls           = 20;
   unsigned int   fDontWait           = FALSE;
   unsigned int   fNameSyntaxType     = RPC_C_NS_SYNTAX_DEFAULT;

   status = RpcServerUseProtseqEp(pszProtocolSequence,
                                  cMaxCalls,     /* max concurrent calls */
                                  pszEndpoint,
                                  pszSecurity);  /* Security descriptor  */

   printf("RpcServerUseProtseqEp returned 0x%x\n", status);

   if(status)
      exit(status);

   status = RpcServerRegisterIf(
      hello_ServerIfHandle, /* interface to register          */
      NULL,                 /* MgrTypeUuid                    */
      NULL);                /* MgrEpv; null means use default */

   printf("RpcServerRegisterIf returned 0x%x\n", status);

   if(status)
      exit(status);

   status = RpcServerInqBindings(&pBindingVector);

   printf("RpcServerInqBindings returned 0x%x\n", status);

   if(status)
      exit(status);

   status = RpcNsBindingExport(
      fNameSyntaxType,  /* name syntax type     */
      pszAutoEntryName, /* nsi entry name       */
      hello_ServerIfHandle,
      pBindingVector,   /* set in previous call */
      NULL);            /* UUID vector          */

   printf("RpcNsBindingExport returned 0x%x\n", status);

   if(status)
      exit(status);

   printf("Calling RpcServerListen\n");

   status = RpcServerListen(cMinCalls, cMaxCalls, fDontWait); /* wait flag */

   printf("RpcServerListen returned: 0x%x\n", status);

   if(status)
      exit(status);

   if(fDontWait)
      {
      printf("Calling RpcMgmtWaitServerListen\n");

      status = RpcMgmtWaitServerListen(); /* wait operation */

      printf("RpcMgmtWaitServerListen returned: 0x%x\n", status);

      if(status) 
         exit(status);
      }
   }

/* MIDL allocate and free */
void __RPC_FAR *__RPC_API midl_user_allocate(size_t len)
   {
   return(malloc(len));
   }

void __RPC_API midl_user_free(void __RPC_FAR *ptr)
   {
   free(ptr);
   }

