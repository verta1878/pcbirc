/****************************************************************************\
*                                                                            *
* Listing 5-3                                                                *
*                                                                            *
* HELLOP.C - Remote procedures linked with the server                        *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE HELLO                                                     *
*                                                                            *
* Comments:  This version of the distributed application that prints         *
*            "hello, world" (or other string) on the server features         *
*            a client that uses automatic binding.                           *
*                                                                            *
\****************************************************************************/

#include <STDLIB.H>
#include <STDIO.H>
#include <TIME.H>
#include <RPC.H>
#include "hello.h"

void HelloRPC(unsigned char *string)
   {
   printf(string);
   }

