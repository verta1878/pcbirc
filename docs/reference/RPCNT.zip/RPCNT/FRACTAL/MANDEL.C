/****************************************************************************\
*                                                                            *
* Listing 10-1                                                               *
*                                                                            *
* MANDEL.C - Mandelbrot example                                              *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE MANDEL.MAK                                                *
*                                                                            *
* Comments:  Main code for the Windows Mandelbrot Set distributed drawing    *
*            program.                                                        *
*                                                                            *
\****************************************************************************/

#define NCOLORS 11

#include <SYS\TYPES.H>
#include <SYS\STAT.H>
#include <DIRECT.H>
#include <DOS.H>
#include <STRING.H>
#include <CTYPE.H>
#include <MALLOC.H>
#include <STDIO.H>
#include <STDLIB.H>
#include <TIME.H>
#include <WINDOWS.H>
#include <WINDOWSX.H>
#include <RPC.H>

#include "mdlrpc.h"
#include "mandel.h"

#define MAX_THREADS 9

/* An array of binding handles */

handle_t BindingHandle[MAX_THREADS];

/* Previous cordinates from specific server. (To monitor server progress) */

extern UINT prev_coord[];

HWND hWnd;
HWND hWndSecondary;

/* Critical Section for choosing next available number for testing */

CRITICAL_SECTION GlobalCriticalSection;

/* Storage for Computer Name */

char computername[MAX_COMPUTERNAME_LENGTH];
int computerlength = 9;
char szTitle[] = "Mandelbrot";
char szBitmap[] = "Mandel";

CPOINT  cptUL = { (double) -2.05, (double) 1.4 };
double  dPrec = (double) .01;
extern  int ipszNetAdd;
char    iServerUnBound = 0;

/* Display the buffer of colors received from server */

void PaintLine( HWND, svr_table *, HDC, int, long);

/* Map iterations receved from server to colors */

COLORREF MapColor(DWORD, DWORD);

/*  This function draws (or undraws) the zoom rectangle */

void DrawRect(HWND, PRECT, BOOL, HDC);

HANDLE hInst;                
HANDLE GlobalhDlg;

/* Number of active servers */

int ipszNetAdd = 0;

DWORD  lpIDThread[MAX_THREADS];
HANDLE hthread_remote[MAX_THREADS];

/* number of vertical lines (each line is 300 pixel) to send to server */

int iLines = LINES;

/* info about servers */

svr_table SvrTable[20];
int SvrTableSz = 0;
int fContinueZoom = TRUE;
int fZoomIn = TRUE;

/* split current picture into 16 regions */

int Histogram[4][4][NCOLORS+1] = { 0 };

/* zoom on most complex region; region with most colors represented */

int ColorCount[4][4] = { 0 };
int Max[4][4] = { 0 };
int iHistMaxI = 2;
int iHistMaxJ = 3;
RECT rcZoom;
BOOL fRectDefined = FALSE;

/* flag indicates whether bound to svr */

int fBound[MAX_THREADS] = { FALSE };

/* returned by RPC API function */

RPC_STATUS status;

unsigned char * pszUuid             = NULL;
unsigned char * pszProtocolSequence = "ncacn_np";
unsigned char  pszEndpoint[MAX_THREADS][UNCLEN+1] = { "\\pipe\\mandel",
   "\\pipe\\mandel", "\\pipe\\mandel", "\\pipe\\mandel", "\\pipe\\mandel",
   "\\pipe\\mandel", "\\pipe\\mandel", "\\pipe\\mandel", "\\pipe\\mandel" };
unsigned char * pszOptions          = NULL;
unsigned char * pszStringBinding[MAX_THREADS] = { NULL };
unsigned char   szNetworkAddress[MAX_THREADS][UNCLEN+1] = { '\0' };

/* pointer to the dialog box function */

DLGPROC lpProcSecondary;                

int APIENTRY WinMain(HANDLE hInstance, HANDLE hPrevInstance,
   LPSTR lpCmdLine, int nCmdShow)
   {
   MSG msg;                  
   unsigned long ulRpcException;

   RpcTryExcept
      {
      UNREFERENCED_PARAMETER(lpCmdLine);

      if(!hPrevInstance)
         if(!InitApplication(hInstance))
            return(FALSE);

/* Perform initializations that apply to a specific instance */

        if(!InitInstance(hInstance, nCmdShow))
           return (FALSE);

/* Acquire and dispatch messages until a WM_QUIT message is received. */

        while(GetMessage(&msg, (HWND)NULL, 0, 0))
           {
           if(hWndSecondary == 0 || !IsDialogMessage(hWndSecondary,&msg))
              {
              TranslateMessage(&msg);
              DispatchMessage(&msg);
              }
           }
      }
   RpcExcept(1)
      {
      ulRpcException = RpcExceptionCode();
      sprintf(pszFail, "Runtime exception 0x%lx = %ld\n", ulRpcException,
         ulRpcException);
      MessageBox(msg.hwnd, pszFail, "RPC Sample Application",
         MB_ICONINFORMATION | MB_SYSTEMMODAL);
      }
   RpcEndExcept

   return(msg.wParam);
   }

BOOL InitApplication(HANDLE hInstance)
   {
   WNDCLASS wc;

   wc.style = 0;           
   wc.lpfnWndProc = (WNDPROC)MainWndProc;    
   wc.cbClsExtra = 0;                  
   wc.cbWndExtra = 0;                  
   wc.hInstance = hInstance;           
   wc.hIcon = LoadIcon(hInstance, "RPC_ICON");
   wc.hbrBackground = GetStockObject(WHITE_BRUSH);
   wc.lpszMenuName =  MENUNAME;   
   wc.lpszClassName = CLASSNAME; 

   return (RegisterClass(&wc));
   }

BOOL InitInstance(HANDLE hInstance, int nCmdShow)
   {
   RECT  rc;
   HMENU hMenu;

/* Save the instance handle in static variable, which will be used in  
   many subsequence calls from this application to Windows.           */

   hInst = hInstance;

/* Create a main window for this application instance.  */

   hWnd = CreateWindow(
      CLASSNAME,                      
      szTitle,                        
      WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_BORDER | WS_MINIMIZEBOX,
      25,                  
      40,                  
      WIDTH,               
      HEIGHT,              
      (HWND)NULL,          
      (HMENU)NULL,         
      hInstance,           
      (void FAR *)NULL     
      );

   if(!hWnd)
      return(FALSE);

   ShowWindow(hWnd, nCmdShow);  
   UpdateWindow(hWnd);          

   hWndSecondary = CreateDialog(hInst,"Secondary",hWnd,
   lpProcSecondary = MakeProcInstance(Secondary, hInst));

   ShowWindow(hWndSecondary,SW_HIDE);

   rc.top = rc.left = 0;
   rc.bottom = HEIGHT - 1;
   rc.right = WIDTH - 1;

   SetNewCalc(cptUL, dPrec, rc);
   hMenu = GetMenu(hWnd);

   return (TRUE);              
   }

LONG APIENTRY MainWndProc(HWND hWnd, UINT message, UINT wParam, LONG lParam)                              /* additional information      */
   {
/* pointer to the dialog box function */

   DLGPROC lpProc;

   PAINTSTRUCT  ps;
   HDC hdc;
   static HDC   hdcMem;
   static HBITMAP hbmMem;
   static int   width;
   static int   height;
   RECT         rc;
   static BOOL  fButtonDown = FALSE;
   static POINT pSelected;
   POINT        pMove;
   int          iWidthNew;
   int          iHeightNew;
   static int   miOldLines;
   double       scaling;

   switch(message)
      {
      case WM_CREATE:

         /* bind to server */

         PostMessage(hWnd, WM_COMMAND, IDM_SERVER, 0L);  
         InitializeCriticalSection(&GlobalCriticalSection);

         InitHistogram();

         hdc = GetDC(hWnd);
         hdcMem = CreateCompatibleDC(hdc);
         GetWindowRect(hWnd, &rc);
         width = rc.right - rc.left;
         height = rc.bottom - rc.top;
         hbmMem = CreateCompatibleBitmap(hdc, width, height);
         SelectObject(hdcMem, hbmMem);

         ReleaseDC(hWnd,hdc);

         rc.left = rc.top = 0;
         rc.right = width + 1;
         rc.bottom = height + 1;
         FillRect(hdcMem, &rc, GetStockObject(WHITE_BRUSH));

         CheckMenuItem(GetMenu(hWnd), IDM_4LINES, MF_CHECKED);
         CheckMenuItem(GetMenu(hWnd), IDM_CONTINUOUS, MF_CHECKED);

          /* save to uncheck  */

         miOldLines = IDM_4LINES; 

         break;

      case WM_PAINT:

         hdc = BeginPaint(hWnd, &ps);

         BitBlt(hdc, ps.rcPaint.left,
         ps.rcPaint.top,
         ps.rcPaint.right - ps.rcPaint.left,
         ps.rcPaint.bottom - ps.rcPaint.top,
         hdcMem, ps.rcPaint.left, ps.rcPaint.top, SRCCOPY);
         EndPaint(hWnd, &ps);
         break;

      case WM_COMMAND:           
         switch(wParam)
           {
           case IDM_BIND:
              if(Bind(hWnd,TRUE))
                 PostMessage(hWnd, WM_DESTROY, 0, 0L);
              break;

           case IDM_ABOUT:
              lpProc = MakeProcInstance(About, hInst);
              DialogBox(hInst, ABOUTBOX, hWnd, lpProc);             
              FreeProcInstance(lpProc);
              break;

           case IDM_SECONDARY:
              ShowWindow(hWndSecondary, SW_RESTORE);
              break;

           case IDM_ZOOMOUT:

              /* don't allow the zoom out */

              if(dPrec > (double)MAXPREC)  
                 break;

              /* center square */

              rcZoom.left = WIDTH/4 + (WIDTH/8);      
              rcZoom.top   = HEIGHT/4 + (HEIGHT/8);
              rcZoom.right = rcZoom.left + (WIDTH/4);
              rcZoom.bottom = rcZoom.top + (HEIGHT/4);

               /* inverse of zoom in */

              cptUL.real -= (rcZoom.left * dPrec); 
              cptUL.imag += (rcZoom.top * dPrec);
              iWidthNew = (rcZoom.right - rcZoom.left + 1);
              iHeightNew = (rcZoom.bottom - rcZoom.top + 1);
              scaling =
                 ((double)((iWidthNew > iHeightNew) ? iWidthNew : iHeightNew)
                 / (double)width);
              dPrec /= scaling;

              rc.left = rc.top = 0;
              rc.bottom = height - 1;
              rc.right = width - 1;

              SetNewCalc(cptUL, dPrec, rc);
              fRectDefined = FALSE;
              break;

              /* zoom in on selected rectangle */

           case IDM_ZOOMIN:

              /* if no rectangle, don't zoom in  */

              if(!fRectDefined)
                 break;
              if(dPrec < (double)MINPREC)  // don't allow zoom in
                 break;

              DrawRect(hWnd, &rcZoom, TRUE, hdcMem);  // draw new rect

              // calculate new upper-left
              cptUL.real += (rcZoom.left * dPrec);
              cptUL.imag -= (rcZoom.top * dPrec);

              iWidthNew = (rcZoom.right - rcZoom.left + 1);
              iHeightNew = (rcZoom.bottom - rcZoom.top + 1);
              scaling =
                 ((double)((iWidthNew > iHeightNew) ? iWidthNew : iHeightNew)
                 / (double)width);

              dPrec *= scaling;

              rc.left = rc.top = 0;
              rc.bottom = height - 1;
              rc.right = width - 1;

              SetNewCalc(cptUL, dPrec, rc);
              IncPictureID();

              fRectDefined = FALSE;
              break;

              /*  continuous zoom in  */

           case IDM_CONTINUOUS: 
              if(fContinueZoom == TRUE)
                 {
                 CheckMenuItem(GetMenu(hWnd), IDM_CONTINUOUS, MF_UNCHECKED);
                 fContinueZoom = FALSE;
                 }
              else
                 {
                 CheckMenuItem(GetMenu(hWnd), IDM_CONTINUOUS, MF_CHECKED);
                 fContinueZoom = TRUE;
                 }
              break;

           case IDM_REDRAW:
              if(fContinueZoom == TRUE)
                 InitHistogram();
              rc.left = rc.top = 0;
              rc.right = width+1;
              rc.bottom = height + 1;
              FillRect(hdcMem, &rc, GetStockObject(WHITE_BRUSH));
              InvalidateRect(hWnd, NULL, TRUE);

              rc.left = rc.top = 0;
              rc.bottom = height - 1;
              rc.right = width - 1;
              SetNewCalc( cptUL, dPrec, rc);

              fRectDefined = FALSE;
              break;

           case IDM_EXIT:
              DestroyWindow(hWnd);
              break;

           case IDM_TOP:
              cptUL.real = (double) -2.05;
              cptUL.imag = (double) 1.4;
              dPrec = .01;

              rc.left = rc.top = 0;
              rc.bottom = height - 1;
              rc.right = width - 1;
              SetNewCalc( cptUL, dPrec, rc);
              cPictureID = 0; 

              fRectDefined = FALSE;
              break;

           case IDM_1LINE:
           case IDM_2LINES:
           case IDM_4LINES:
           case IDM_8LINES:
           case IDM_16LINES:

              CheckMenuItem(GetMenu(hWnd), miOldLines, MF_UNCHECKED);
              miOldLines = wParam;
              switch(wParam)
                 {
                 case IDM_1LINE:
                    iLines = 1;
                    break;
                 case IDM_2LINES:
                    iLines = 2;
                    break;
                 case IDM_4LINES:
                    iLines = 4;
                    break;
                 case IDM_8LINES:
                    iLines = 8;
                    break;
                 case IDM_16LINES:
                    iLines = 16;
                    break;
                 }

              CheckMenuItem(GetMenu(hWnd), miOldLines, MF_CHECKED);
              break;

           case IDM_SERVER:
              lpProc = MakeProcInstance(Server, hInst);
              DialogBox(hInst, "ServerBox", hWnd, lpProc);  
              FreeProcInstance(lpProc);
              break;

              /* Lets Windows process it */

           default:                      
              return (DefWindowProc(hWnd, message, wParam, lParam));
           }
           break;

        case WM_DESTROY:             
           PostQuitMessage(0);
           DeleteDC(hdcMem);
           DeleteObject(hbmMem);
           DestroyWindow(GlobalhDlg);
           hWndSecondary = 0;

           {
           RPC_STATUS status;
           int i;

           for(i = 0; i < ipszNetAdd; i++)
              {
              /* remote calls done; unbind */

              status = RpcBindingFree(&BindingHandle[i]);  

              sprintf(pszFail, "RpcBindingFree returned 0x%x", status);
              MessageBox(hWnd, pszFail, "RPC Sample Application",
                 MB_ICONINFORMATION);
              }
           }
           break;

        case WM_PAINTLINE:

           /* The shared buffer contains a line of data; draw it */

           PaintLine(hWnd, (svr_table *)&SvrTable[(signed int)wParam],
           hdcMem, height, lParam);
           break;

        case WM_LBUTTONDOWN:

           /* left button down; start to define a zoom rectangle */
           /* undraw old rectangle */

           if(fRectDefined)
              DrawRect(hWnd, &rcZoom, FALSE, hdcMem);

           /* initialize rectangle */

           rcZoom.left = rcZoom.right = pSelected.x = LOWORD(lParam);
           rcZoom.top = rcZoom.bottom = pSelected.y = HIWORD(lParam);

           /* draw the new rectangle */

           DrawRect(hWnd, &rcZoom, TRUE, hdcMem);

           fRectDefined = TRUE;
           fButtonDown = TRUE;
           SetCapture(hWnd);       // capture all mouse events
           break;

        case WM_MOUSEMOVE:

           /* mouse move -- if the button is down, change the rect */

           if(!fButtonDown)
              break;

           /* undraw old rect */

           DrawRect(hWnd, &rcZoom, FALSE, hdcMem); 

           pMove.x = LOWORD(lParam);
           pMove.y = HIWORD(lParam);

           /* update the selection rectangle */

           if(pMove.x <= pSelected.x)
              rcZoom.left = pMove.x;
           if(pMove.x >= pSelected.x)
              rcZoom.right = pMove.x;
           if(pMove.y <= pSelected.y)
              rcZoom.top = pMove.y;
           if(pMove.y >= pSelected.y)
              rcZoom.bottom = pMove.y;

           /* draw new rect */

           DrawRect(hWnd, &rcZoom, TRUE, hdcMem);  
           break;

        case WM_LBUTTONUP:

           /* button up; end selection */

           fButtonDown = FALSE;
           ReleaseCapture();
           break;

           /* Passes it on if unproccessed    */

        default: 
            return (DefWindowProc(hWnd, message, wParam, lParam));
        }

   return (0L);
   }

BOOL APIENTRY About(HWND hDlg, UINT message, UINT wParam, LONG lParam)
   {
   UNREFERENCED_PARAMETER(lParam);

   switch(message)
      {

      /* message: initialize dialog box */

      case WM_INITDIALOG:             
         return (TRUE);

      /* message: received a command */

      case WM_COMMAND:

         /* "OK" box selected?  or  System menu close command? */

         if(wParam == IDOK || wParam == IDCANCEL)        
            {

            /* Exits the dialog box      */

            EndDialog(hDlg, TRUE);       
            return (TRUE);
            }
            break;
      }

   /* Didn't process a message    */

   return (FALSE);                         
   }

/* DrawRect -- This function draws (or undraws) the zoom rectangle. */

void DrawRect(HWND hwnd, PRECT prc, BOOL fDrawIt, HDC hdcBM)
   {
   HDC   hdc;
   DWORD dwRop;

   hdc = GetDC(hwnd);

   if(fDrawIt)
      dwRop = NOTSRCCOPY;
   else
      dwRop = SRCCOPY;

   /* top side */

   BitBlt(hdc, prc->left, prc->top, (prc->right - prc->left) + 1,
      1, hdcBM, prc->left, prc->top, dwRop);

   /* bottom side */

   BitBlt(hdc, prc->left, prc->bottom, (prc->right - prc->left) + 1,
      1, hdcBM, prc->left, prc->bottom, dwRop);

   /* left side */

   BitBlt(hdc,prc->left, prc->top, 1, (prc->bottom - prc->top) + 1,
      hdcBM, prc->left, prc->top, dwRop);

   /* right side */

   BitBlt(hdc,prc->right, prc->top, 1, (prc->bottom - prc->top) + 1,
      hdcBM, prc->right, prc->top, dwRop);

   ReleaseDC(hwnd, hdc);
   }

/* PaintLine -- This function paints a buffer of data into the bitmap. */

void PaintLine(HWND hwnd, svr_table * pst, HDC hdcBM, int cHeight,
   long iServer)
   {
   PWORD   pwDrawData;
   int     y;
   int     x;
   DWORD   dwThreshold;
   RECT    rc;
   WORD    lines;
   WORD    calc_left;
   WORD    calc_right;

   /* picture ID had better match, or else we skip it */

   if(CheckDrawingID(pst->cPicture))
      {

      /* figure out our threshold */

      dwThreshold = QueryThreshold();

      /* get a pointer to the draw buffer */

      pwDrawData = (PWORD)GetDrawBuffer(iServer);
      calc_left = *pwDrawData;
      pwDrawData+=2;
      calc_right = *pwDrawData;
      pwDrawData+=2;
      lines = calc_right-calc_left + 1;
      if(pwDrawData == NULL)
         {
         ReturnDrawBuffer(iServer);
         return;
         }

   if(fBound[iServer] == FALSE)
      {
      ReturnDrawBuffer(iServer);
      return;
      }

   /* starting x coordinate */

   x = (int)calc_left + 1;

   /* now loop through the rectangle */

   while(lines-- > 0)
      {

      /* bottom to top, since that's the order of the data in the buffer */
      y = (int) cHeight-1;
         
      while(y >= 0)
         {
         /* draw a pixel */

         SetPixel(hdcBM, x,y, MapColor((DWORD)*pwDrawData, dwThreshold));
         if(fContinueZoom == TRUE)
            CalcHistogram(x, y, (DWORD)*pwDrawData, dwThreshold);

         /* now increment buffer pointer and y coord */

         y--;
         pwDrawData++;
         }

      /* increment X coordinate */

      x++;  
      }

      /* figure out the rectangle to invalidate */

      rc.top = 0;
      rc.bottom = cHeight;
      rc.left = (int)calc_left;   
      rc.right = (int)calc_right+2;      

      FreeDrawBuffer(iServer);

      /* and invalidate it on the screen so we redraw it  */

      InvalidateRect(hwnd, &rc, FALSE);
      }

   /* free this for someone else to use */

   ReturnDrawBuffer(iServer);

   /* and change the pipe state, if necessary */

   if(pst->iStatus == SS_PAINTING)
      pst->iStatus = SS_IDLE;
   }

#define CLR_BLACK       RGB(0,0,0)
#define CLR_DARKBLUE    RGB(0,0,127)
#define CLR_BLUE        RGB(0,0,255)
#define CLR_CYAN        RGB(0,255,255)
#define CLR_DARKGREEN   RGB(0,127,0)
#define CLR_GREEN       RGB(0,255,0)
#define CLR_YELLOW      RGB(255,255,0)
#define CLR_RED         RGB(255,0,0)
#define CLR_DARKRED     RGB(127,0,0)
#define CLR_WHITE       RGB(255,255,255)
#define CLR_PALEGRAY    RGB(194,194,194)
#define CLR_DARKGRAY    RGB(127,127,127)

static COLORREF ColorMapTable[] =
   {
   CLR_DARKBLUE,
   CLR_BLUE,
   CLR_CYAN,
   CLR_DARKGREEN,
   CLR_GREEN,
   CLR_YELLOW,
   CLR_RED,
   CLR_DARKRED,
   CLR_WHITE,
   CLR_PALEGRAY,
   CLR_DARKGRAY
   };

/* MapColor --
   This function maps an iteration count into a corresponding RGB color. */

COLORREF MapColor(DWORD  dwIter, DWORD  dwThreshold)
   {
   /* if it's beyond the threshold, call it black */

   if(dwIter >= dwThreshold)
      {
      return CLR_BLACK;
      }

   /* get a modulus based on the number of colors */

   dwIter = (dwIter / 3) % NCOLORS; 

   /* and return the appropriate color */
   return ColorMapTable[dwIter];
   }

/* CalcHistogram
 This function is used to select the region that is the
 most complex and will be used to zoom in for the next picture;
 it contains the most colors.  The number of colors are counted.
*/

void CalcHistogram(int x, int y, DWORD  dwIter, DWORD  dwThreshold)
   {
   /* if it's beyond the threshold, call it black */

   if (dwIter >= dwThreshold)
      {
      Histogram[x/(WIDTH/4)][y/(HEIGHT/4)][NCOLORS]++;
      return;
      }

   /* get a modulus based on the number of colors */

   dwIter = (dwIter / 3) % NCOLORS; 

   /* and bump the count for the appropriate color */

   Histogram[x/(WIDTH/4)][y/(HEIGHT/4)][dwIter]++;

   return;
   }

/* InitHistogram -
   This function initializes the histogram data structures. */

void InitHistogram(void)
   {
   int i, j, k;

   for(i = 0; i < 4; i++)
      for(j = 0; j < 4; j++)
         for(k = 0; k <= NCOLORS; k++)

            /* count of colors */

            Histogram[i][j][k] = 0; 
   }

/* CountHistogram
   This function determines the number of colors represented
   within a region.  The region with the most colors is
   selected using the maxi and maxj values.  X and Y coordinates
   corresponding to these regions are stored in the HistRegion
   table and are used for the next picture.
*/

void CountHistogram(void)
   {
   int i, j, k;

   /* count the number of colors in each region 
      find the color that dominates each region */

   for(i = 0; i < 4; i++)
      {
      for (j = 0; j < 4; j++)
         {
         ColorCount[i][j] = 0;
         Max[i][j] = 0;
         for(k = 0; k <= NCOLORS; k++)
            {
            if(Histogram[i][j][k] > Max[i][j])
               Max[i][j] = Histogram[i][j][k];

            /* count of colors */

            if(Histogram[i][j][k] != 0)  
               ColorCount[i][j]++;
            }
         }
      }

   iHistMaxI = 0;
   iHistMaxJ = 0;

   /* if several regions have the same number of colors, 
      select the region with the most variety:  the smallest max */

   for(i = 0; i < 4; i++)
      {
      for(j = 0; j < 4; j++)
         {
         if((ColorCount[i][j] >= ColorCount[iHistMaxI][iHistMaxJ])
            && (Max[i][j] < Max[iHistMaxI][iHistMaxJ]))
            {
            iHistMaxI = i;
            iHistMaxJ = j;
            }
         }
      }

   /* initialize for next time */

   InitHistogram(); 
   }

/* need this function to link properly; ndrlib needs it */

/* MIDL allocate and free */
void __RPC_FAR *__RPC_API midl_user_allocate(size_t len)
   {
   UNREFERENCED_PARAMETER(len);
   return(NULL);
   }

BOOL APIENTRY Server(HWND hDlg, UINT message, UINT wParam, LONG lParam)
   {
   UNREFERENCED_PARAMETER(lParam);

   switch(message)
      {

      /* message: initialize dialog box */

      case WM_INITDIALOG:               
         SetDlgItemText(hDlg, IDD_SERVERNAME, szNetworkAddress[ipszNetAdd]);
         SetDlgItemText(hDlg, IDD_ENDPOINT, pszEndpoint[ipszNetAdd]);
         return (TRUE);

      /* message: received a command */

      case WM_COMMAND:
         switch(wParam)
            {

            /* System menu close command? */

            case IDCANCEL:               
               EndDialog(hDlg, FALSE);
               return(TRUE);

               /* "OK" box selected?   */

            case IDOK:                   
               GetDlgItemText(hDlg, IDD_SERVERNAME,
                  szNetworkAddress[ipszNetAdd], UNCLEN);
               GetDlgItemText(hDlg, IDD_ENDPOINT, pszEndpoint[ipszNetAdd],
                  UNCLEN);

               if(szNetworkAddress[ipszNetAdd][0] != '\\')  
                  {
                  computername[0] = computername[1] = '\\';
                  GetComputerName(&computername[2], &computerlength);
                  GetComputerName(&computername[2], &computerlength);
                  strcpy(szNetworkAddress[ipszNetAdd],computername);
                  }

               if(Bind(hDlg,TRUE) != RPC_S_OK)
                  {
                  EndDialog(hDlg, FALSE);
                  return(FALSE);
                  }
               EndDialog(hDlg, TRUE);
               return(TRUE);
            }
       }

   /* Didn't process a message    */

   return (FALSE);             
   }

UINT prev_coord[MAX_THREADS];

/*
FUNCTION: Bind(HWND)

PURPOSE:  Make RPC API calls to bind to the server application

COMMENTS:
   The binding calls are made from InitInstance() and whenever
   the user changes the server name or endpoint. If the bind
   operation is successful, the global flag fBound is set to TRUE.

   The global flag fBound is used to determine whether to call
   the RPC API function RpcBindingFree.
*/

RPC_STATUS Bind(HWND hWnd,char flag)
   {
   RPC_STATUS status[MAX_THREADS];
   if(!flag)
      {
      if(fBound[iServerUnBound] == TRUE)
         {  
         fBound[iServerUnBound] = FALSE;
         iServerUnBound = 0;
         return(status[iServerUnBound]);
         }
      return 0;
      }

   if(!InitRemote(hWnd,ipszNetAdd))
      return FALSE;

   status[ipszNetAdd] = RpcStringBindingCompose(pszUuid, pszProtocolSequence,
      szNetworkAddress[ipszNetAdd], pszEndpoint[ipszNetAdd], pszOptions,
      &pszStringBinding[ipszNetAdd]);

   if(!status[ipszNetAdd])
      {
      status[ipszNetAdd] = RpcBindingFromStringBinding(
         pszStringBinding[ipszNetAdd], &BindingHandle[ipszNetAdd]);
      }

   if(!status[ipszNetAdd])
      {
      /* bind successful; reset flag */

      fBound[ipszNetAdd] = TRUE;  
      hthread_remote[ipszNetAdd] = CreateThread(NULL, 0,
         (LPTHREAD_START_ROUTINE)CheckDrawStatus, ipszNetAdd,
         CREATE_SUSPENDED, &lpIDThread[ipszNetAdd]);
      SetThreadPriority(hthread_remote[ipszNetAdd], THREAD_PRIORITY_LOWEST);
      ResumeThread(hthread_remote[ipszNetAdd]);
      if(hWndSecondary)
         {
         char Buffer[MAX_COMPUTERNAME_LENGTH];

         memset(Buffer, '\0', MAX_COMPUTERNAME_LENGTH);
         GetComputerName(Buffer, &computerlength);

         if(strlen(szNetworkAddress[ipszNetAdd]) <= 3)
            {
            memset(Buffer, '\0', MAX_COMPUTERNAME_LENGTH);
            GetComputerName(Buffer, &computerlength);
            }
         else
            {
            memset(Buffer, '\0', MAX_COMPUTERNAME_LENGTH);
            lstrcpy(Buffer, &szNetworkAddress[ipszNetAdd][2]);
            Buffer[computerlength] = 0;
            lstrcat(Buffer, "  ");
            lstrcat(Buffer, &pszEndpoint[ipszNetAdd][6]);
            lstrcat(Buffer, " bound.");
            }

         SendMessage(GetDlgItem(GlobalhDlg, SERVER_LB), LB_ADDSTRING, 0,
            (LPARAM)(LPCSTR)Buffer);
         }
      ipszNetAdd++;
      }
   else
      {
      fBound[ipszNetAdd] = FALSE;
      }
   return(0);
   }

BOOL APIENTRY Secondary(HWND hDlg, UINT message, UINT wParam, LONG lParam)                              /* additional information      */
   {
   char Buffer[300];

   switch(message)
      {
      case WM_INITDIALOG:
         GlobalhDlg = hDlg;
         return TRUE; 

      case WM_PAINTDLG:
         memset(Buffer, '\0', 300);
         strcpy(Buffer, &szNetworkAddress[lParam][2]);
         sprintf(Buffer, "%d.  %-10s %-10s  %d-%d ",
            lParam + 1,&szNetworkAddress[lParam][2],
            &pszEndpoint[lParam][6], wParam, wParam + iLines - 1);

         if(prev_coord[lParam] == wParam)
            Buffer[2] = '*';
         else
            prev_coord[lParam] = wParam;

         SendMessage(GetDlgItem(hDlg, SERVER_LB), WM_SETREDRAW,FALSE,0L);
         SendMessage(GetDlgItem(hDlg, SERVER_LB), LB_DELETESTRING,
            lParam, 0L);
         SendMessage(GetDlgItem(hDlg, SERVER_LB), LB_INSERTSTRING,
            lParam, (LPARAM)(LPCSTR)Buffer);
         SendMessage(GetDlgItem(hDlg, SERVER_LB), WM_SETREDRAW,TRUE,0L);

         return FALSE;

      case WM_COMMAND:
         switch(wParam)
            {
            case WM_DESTROY:
            case 3:
               ShowWindow(hWndSecondary, SW_HIDE);
               return TRUE;
            }
         return FALSE;
      }
   return FALSE;
   }

