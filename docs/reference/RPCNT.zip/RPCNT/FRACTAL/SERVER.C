/****************************************************************************\
*                                                                            *
* Listing 10-2                                                               *
*                                                                            *
* SERVER.C - Mandelbrot example                                              *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE                                                           *
*                                                                            *
\****************************************************************************/

#include <STDLIB.H>   
#include <WINDOWS.H>  
#include <STDIO.H>    
#include <CTYPE.H>
#include <RPC.H>      

#include "mdlrpc.h"   
#include "mandel.h"

HANDLE hSharedBuf = NULL;

/* Displays command line options */

void Usage(char * pszProgramName)
   {
   fprintf(stderr, "Usage:  %s\n", pszProgramName);
   fprintf(stderr, " -p protocol_sequence\n");
   fprintf(stderr, " -e endpoint\n");
   fprintf(stderr, " -m maxcalls\n");
   fprintf(stderr, " -n mincalls\n");
   fprintf(stderr, " -f flag_wait_op\n");
   fprintf(stderr, " -s security_descriptor\n");
   exit(1);
   }

void _CRTAPI1 main(int argc, char *argv[])
   {
   RPC_STATUS status;
   unsigned char * pszProtocolSequence = "ncacn_np";
   unsigned char * pszSecurity    = NULL;
   unsigned char * pszEndpoint    = "\\pipe\\mandel";
   unsigned int    cMinCalls      = 1;
   unsigned int    cMaxCalls      = 20;
   unsigned int    fDontWait      = FALSE;
   int i;

   /* allow the user to override settings with command line switches */

   for(i = 1; i < argc; i++)
      {
      if((*argv[i] == '-') || (*argv[i] == '/'))
         {
         switch(tolower(*(argv[i]+1)))
            {
            case 'p':  
               pszProtocolSequence = argv[++i];
               break;
            case 'e':
               pszEndpoint = argv[++i];
               break;
            case 'm':
               cMaxCalls = (unsigned int)atoi(argv[++i]);
               break;
            case 'n':
               cMinCalls = (unsigned int)atoi(argv[++i]);
               break;
            case 'f':
               fDontWait = (unsigned int)atoi(argv[++i]);
               break;
            case 's':
               pszSecurity = argv[++i];
               break;
            case 'h':
            case '?':
            default:
               Usage(argv[0]);
            }
         }
      else
         Usage(argv[0]);
      }

   hSharedBuf = GlobalAlloc(GMEM_FIXED, MAX_BUFSIZE);

/*
   Tells the RPC runtime to use the specified protocol sequence combined
   with the specified endpoint for receiving remote procedure calls
*/

   status = RpcServerUseProtseqEp(pszProtocolSequence,
      cMaxCalls, pszEndpoint, pszSecurity);  
   printf("RpcServerUseProtseqEp returned 0x%x\n", status);
   if(status)
      {
      exit(status);
      }

   /* Registers an interface with RPC runtime */

   status = RpcServerRegisterIf(mdlrpc_ServerIfHandle, NULL, NULL);  
   printf("RpcServerRegisterIf returned 0x%x\n", status);
   if(status)
      {
      exit(status);
      }

   printf("Calling RpcServerListen\n");

   /* Tells the RPC runtime to listen for remote procedure calls */

   status = RpcServerListen(cMinCalls, cMaxCalls, fDontWait);
   printf("RpcServerListen returned: 0x%x\n", status);
   if(status)
      {
      exit(status);
      }

   if(fDontWait)
      {
      printf("Calling RpcMgmtWaitServerListen\n");
      status = RpcMgmtWaitServerListen();  //  wait operation
      printf("RpcMgmtWaitServerListen returned: 0x%x\n", status);
      if(status)
         {
         exit(status);
         }
      }
   }

/* Memory allocation and deallocation  for RPC runtime */

static HANDLE hMidlUserFunc;

/* MIDL allocate and free */
void __RPC_FAR *__RPC_API midl_user_allocate(size_t len)
   {
   hMidlUserFunc = GlobalAlloc(GMEM_FIXED, len);
   return(PDWORD)(GlobalLock(hMidlUserFunc));
   }

void __RPC_API midl_user_free(void __RPC_FAR *ptr)
   {
   GlobalUnlock(hMidlUserFunc);
   GlobalFree(hMidlUserFunc);
   }

