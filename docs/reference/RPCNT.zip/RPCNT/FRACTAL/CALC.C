/****************************************************************************\
*                                                                            *
* Listing 10-4                                                               *
*                                                                            *
* CALC.C   - Mandelbrot example                                              *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE MANDEL.MAK                                                *
*                                                                            *
* Comments:  Code to do the calculations for the Windows Mandelbrot Set      *
*            distributed drawing program.                                    *
*                                                                            *
\****************************************************************************/

#include <WINDOWS.H>
#include <MALLOC.H>  
#include <STRING.H>
#include <STDIO.H>
#include <RPC.H>

#include "mdlrpc.h"
#include "mandel.h"

/*
   h1      - explicit binding handle
   pcptLL  - pointer to complex number
   prcDraw - drawing rectangle
   pbBuf   - number of iterations are stuff here
*/

void MandelCalc(handle_t h1, PCPOINT pcptLL, PLONGRECT  prcDraw,
   double precision, DWORD  ulThreshold, PLINEBUF pbBuf)
   {
   char Buffer[300];

   DWORD  h, height;
   DWORD  width;
   PWORD  pbPtr;
   double dreal, dimag, dimag2;
   short  maxit = 0;

/* Show what the server is computing */

   sprintf(Buffer,"%3ld  %3ld  %f  %ld \n", prcDraw->xLeft,
      prcDraw->xRight, precision, ulThreshold);
   printf(Buffer);

/* PLINEBUF points to the struct LINEBUF, LINEBUF is an array of WORDS */

   pbPtr = (PWORD)pbBuf; 

   dreal = pcptLL->real + ((double)prcDraw->xLeft * precision);
   dimag = pcptLL->imag + ((double)prcDraw->yBottom * precision);

   maxit = (short)ulThreshold;

   height = (prcDraw->yTop - prcDraw->yBottom) + 1;
   width = (prcDraw->xRight - prcDraw->xLeft) + 1;

   for(; width > 0; --width, dreal += precision)
      {
      for(dimag2 = dimag, h = height; h > 0; --h, dimag2 += precision)
         {
         if((dreal > 4.0) || (dreal < -4.0) ||
            (dimag2 > 4.0) || (dimag2 < -4.0))
            *(pbPtr++) = 0L;
         else
            *(pbPtr++) = (WORD)(calcmand(dreal, dimag2, maxit));
         }
      }

   return;
   }

/* The actual calculations are done here */

short calcmand(double dreal, double dimag, short maxit)
   {
   double x, y, xsq, ysq;
   short k;

   k = (short)maxit;
   x = dreal;
   y = dimag;

   while(1)
      {
      xsq = x * x;
      ysq = y * y;
      y = 2.0 * x * y + dimag;
      x = (xsq - ysq) + dreal;
      if(--k == 0)
         return((short)(maxit - k));
      if((xsq + ysq) > 4.0)
         return((short)(maxit - k));
      }
   }

