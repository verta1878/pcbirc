/****************************************************************************\
*                                                                            *
* Listing 10-3                                                               *
*                                                                            *
* REMOTE.C - Mandelbrot example                                              *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE                                                           *
*                                                                            *
* Comments:                                                                  *
*   Code to do the remote calculations for the Windows Mandelbrot Set        *
*   distributed drawing program.                                             *
*                                                                            *
*   Information coming into this module (via API calls) is based on          *
*   upper-left being (0,0) (the Windows standard). We translate that         *
*   to lower-left is (0,0) before we ship it out onto                        *
*   the net, and we do reverse translations accordingly.                     *
*                                                                            *
*   The iteration data is passed back to the main window procedure           *
*   (by means of a WM_PAINTLINE message) which draws the picture.            *
*            program.                                                        *
*                                                                            *
\****************************************************************************/

#include <STRING.H>
#include <STDIO.H>
#include <FCNTL.H>
#include <SYS\TYPES.H>
#include <SYS\STAT.H>
#include <SHARE.H>
#include <IO.H>
#include <MALLOC.H>
#include <WINDOWS.H>
#include <RPC.H>

#include "mdlrpc.h"
#include "mandel.h"

#define SVR_TABLE_SZ 20

/* errno from c runtime */

extern int errno;

/* Main window handle.  */

extern HWND hWnd;

/* Dialog Box window handle.  */

extern HWND hWndSecondary;

extern char     iServerUnBound;
extern handle_t BindingHandle[];
extern int      ipszNetAdd;

/* Data structures */

extern svr_table    SvrTable[]; 
extern int          SvrTableSz; 
char pszFail[255];

BOOL fRemoteWork = FALSE;

/* picture id, in case we reset in the middle */

int cPictureID = 0;

/* upper-left */

static CPOINT cptLL;

/* precision of draw */

static double dPrecision;

/* rectangle defining client window */

static LONGRECT rclPicture;

/* next line to be drawn */

static DWORD dwCurrentLine;

/* threshold for iterations */

static DWORD dwThreshold;       

extern CRITICAL_SECTION GlobalCriticalSection;
 
static char szLocal[] = "Local machine";

/* returned by RPC API function */

RPC_STATUS status;         

/* function prototypes for local procs */

DWORD CalcThreshold(double);

extern UINT prev_coord[];

/* InitRemote --
 
   This function initializes everything for our remote connections.
   It gets the local wksta name (making sure the wksta is started)
   and it creates the mailslot with which to collect replies to our poll.
 
   RETURNS
 
       TRUE        - initialization succeeded
       FALSE       - initialization failed, can't go on
*/

BOOL InitRemote( HWND hWnd,int iServer )
   {
   UNREFERENCED_PARAMETER(hWnd);

   SvrTableSz++;
   strcpy(SvrTable[iServer].name, szLocal);
   SvrTable[iServer].iStatus = SS_LOCAL;

   /* value out of range */

   prev_coord[iServer]= 30000; 

   /* good, we succeeded */

   return TRUE;
   }
/*
   CheckDrawStatus --
 
   This function does a check of all buffers being drawn.
 
   If it finds an idle pipe, and there is work to be done, it assigns
       a line, and writes out the request.
   If it finds a read-pending pipe, it checks if the read has completed.
       If it has, it is read and a message is sent so the read data can
       be processed.
 
   RETURNS
       TRUE        - we did a piece of work
       FALSE       - we could not find any work to do.
*/

static int  iThreadWork = 0;
void CheckDrawStatus(int iServer)
   {
   int     iWork = iServer;
   int     iLast;
   CALCBUF cb;
   PDWORD  pbBuf;

   char flag = 0;
   DWORD dwCurtLine;
   dwCurtLine = dwCurrentLine;

   while(1)
      {
      WORD wIteration = 0;

      iLast = iWork;

      while(TRUE)
         {
         /* Check the status */

         switch(SvrTable[iWork].iStatus)
            {
            case SS_PAINTING:
               break;

            case SS_IDLE:
               if((long)dwCurtLine > rclPicture.xRight)
                  break;

               if(!fRemoteWork)
                  break;
               if(!flag)
                  {
                  EnterCriticalSection(&GlobalCriticalSection);
                  dwCurtLine = dwCurrentLine;
                  dwCurrentLine += iLines;
                  LeaveCriticalSection(&GlobalCriticalSection);
                  flag = 1;
                  }

               /*
                  cb is of type CALCBUF
                  rectangle, precision, threshold and complex point
               */

               cb.rclDraw.xLeft = dwCurtLine;
               cb.rclDraw.xRight = dwCurtLine + iLines - 1;
               cb.rclDraw.yTop = rclPicture.yTop;
               cb.rclDraw.yBottom = rclPicture.yBottom;
               cb.dblPrecision = dPrecision;
               cb.dwThreshold = dwThreshold;
               cb.cptLL = cptLL;
               SvrTable[iWork].dwLine = dwCurtLine;
               SvrTable[iWork].iStatus = SS_READPENDING;
               SvrTable[iWork].cPicture = cPictureID;
               SvrTable[iWork].cLines = iLines;
               break;

            case SS_LOCAL:
               if(!flag)
                  {
                  EnterCriticalSection(&GlobalCriticalSection);
                  dwCurtLine = dwCurrentLine;
                  dwCurrentLine += iLines;
                  LeaveCriticalSection(&GlobalCriticalSection);
                  flag = 1;
                  }

               if(fBound[iServer] == FALSE)
                  {
                  Sleep(400);
                  fBound[iServer] = TRUE;
                  }

               if((long)dwCurtLine > rclPicture.xRight)
                  {
                  if(fContinueZoom == TRUE)
                     {
                     if((fZoomIn == TRUE) && (dPrec < (double)MINPREC))
                        fZoomIn = FALSE;
                     if((fZoomIn == FALSE) && (dPrec > (double)MAXPREC))
                        fZoomIn = TRUE;
                     if(fZoomIn)
                        {
                        CountHistogram();
                        rcZoom.top    = iHistMaxJ * (WIDTH/4);
                        rcZoom.bottom = rcZoom.top + (WIDTH/4) - 1;
                        rcZoom.left   = iHistMaxI * (HEIGHT/4);
                        rcZoom.right  = rcZoom.left + (HEIGHT/4) - 1;
                        fRectDefined  = TRUE;
                        PostMessage(hWnd, WM_COMMAND, IDM_ZOOMIN, 0L);
                        }
                     else
                        PostMessage(hWnd, WM_COMMAND, IDM_ZOOMOUT, 0L);
                     }
                  dwCurtLine = 0;
                  break;
                  }

               if(!TakeDrawBuffer(iServer))
                  break;

               if(!flag)
                  {
                  EnterCriticalSection(&GlobalCriticalSection);
                  dwCurtLine = dwCurrentLine;
                  dwCurrentLine += iLines;
                  LeaveCriticalSection(&GlobalCriticalSection);
                  flag = 1;
                  }

               pbBuf = GetDrawBuffer(iServer);

               cb.rclDraw.xLeft  = dwCurtLine;
               cb.rclDraw.xRight = dwCurtLine+ iLines-1;
               cb.rclDraw.yTop = rclPicture.yTop;
               cb.rclDraw.yBottom = rclPicture.yBottom;
               *pbBuf++ = dwCurtLine;
               *pbBuf++ = dwCurtLine +iLines - 1;

               RpcTryExcept
                  {
                  MandelCalc(BindingHandle[iServer], &cptLL, &(cb.rclDraw),
                     dPrecision, dwThreshold, (PLINEBUF)pbBuf);
                  flag = 0;
                  }
               RpcExcept(1)
                  {
                  iServerUnBound = iServer;
                  fBound[iServer] = FALSE;
                  }
               RpcEndExcept

               if(hWndSecondary)
                  PostMessage(hWndSecondary, WM_PAINTDLG,
                     (UINT)(cb.rclDraw.xLeft), iServer);

               FreeDrawBuffer(iServer);

               SvrTable[iWork].cPicture = cPictureID;
               SvrTable[iWork].dwLine = dwCurtLine;
               SvrTable[iWork].cLines = iLines;

               PostMessage(hWnd, WM_PAINTLINE, (UINT)iWork, iServer);
               }
            }
         }
   }

/*
   SetNewCalc --
 
   This sets up new information for a drawing and
   updates the drawing ID so any calculations in progress will not
   be mixed in.
*/

void SetNewCalc(CPOINT cptUL, double dPrec, RECT rc)
   {
   /* First, the base point. We need to translate from upper left to
      lower left.                                                    */

   cptLL.real = cptUL.real;
   cptLL.imag = cptUL.imag - (dPrec * (rc.bottom - rc.top));

   dPrecision = dPrec;

   rclPicture.xLeft = (long)rc.left;
   rclPicture.xRight = (long)rc.right;
   rclPicture.yBottom = (long)rc.top;
   rclPicture.yTop = (long)rc.bottom;

   dwCurrentLine = rclPicture.xLeft;

   dwThreshold = CalcThreshold(dPrecision);
   }

void IncPictureID(void)
   {
   cPictureID++;
   }

/*
   CheckDrawing --
   Just a sanity check here -- a function to check to make sure that we're
   on the right drawing
*/

BOOL CheckDrawingID(int id)
   {
   return (id == cPictureID) ? TRUE : FALSE;
   }

/*
   TakeDrawBuffer / GetDrawBuffer / FreeDrawBuffer / ReturnDrawBuffer
 
   These functions hide a handle to a buffer of memory.
 
   TakeDrawBuffer ensures only one pipe read at a time.
   GetDrawBuffer locks the handle and returns a pointer.
   FreeDrawBuffer unlocks the handle.
   ReturnDrawBuffer unlocks the handle and lets another pipe read go.
*/

#define MAX_THREADS 9

static BOOL fBufferTaken[MAX_THREADS] = { FALSE };
static HANDLE hSharedBuf[MAX_THREADS] = { (HANDLE)NULL };

BOOL TakeDrawBuffer(int pipe)
   {
   if(fBufferTaken[pipe])
      {
      return FALSE;
      }

   if(hSharedBuf[pipe] == NULL)
      {
      hSharedBuf[pipe] = GlobalAlloc(GMEM_MOVEABLE, MAX_BUFSIZE);
      if(hSharedBuf[pipe] == NULL)
         return FALSE;
      }
   fBufferTaken[pipe] = TRUE;
   return TRUE;
   }

PDWORD GetDrawBuffer(int pipe)
   {
   if(hSharedBuf[pipe] == NULL)
      return NULL;

   return (PDWORD)GlobalLock(hSharedBuf[pipe]);
   }

void FreeDrawBuffer(int pipe)
   {
   GlobalUnlock(hSharedBuf[pipe]);
   }

void ReturnDrawBuffer(int pipe)
   {
   fBufferTaken[pipe] = FALSE;
   }

/*
   CalcThreshold --
 
   We need an iteration threshold beyond which we give up. We want it to
   increase the farther we zoom in. This code generates a threshold value
   based on the precision of drawing.
 
   RETURNS
       threshold calculated based on precision
*/

DWORD CalcThreshold(double precision)
   {
   DWORD  thres = 25;
   double multiplier = (double)100.0;

   /* for every 100, multiply by 2 */

   while((precision *= multiplier) < (double)1.0)
      thres *= 2;

   return thres;
   }

/*
   QueryThreshold --
   Callback for finding out what the current drawing's threshold is.
*/

DWORD QueryThreshold(void)
   {
   return dwThreshold;
   }

/* GetServerCount -- Returns the number of servers in the table. */

int GetServerCount(void)
   {
   return (int)SvrTableSz - 1;
   }

