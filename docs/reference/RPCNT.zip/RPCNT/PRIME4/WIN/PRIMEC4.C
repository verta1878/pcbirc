/****************************************************************************\
*                                                                            *
* Listing 8-19                                                               *
*                                                                            *
* PRIMEC4.C  -  PRIMEC4 client for Windows 3.1                               *
*               (c) Guy Eddon, 1993                                          *
*                                                                            *
\****************************************************************************/

#include <WINDOWS.H>
#include <STDIO.H>
#include <STRING.H>
#include <RPC.H>
#include <RPCNDR.H>
#include <STDLIB.H>
#include <MATH.H>
#include <LIMITS.H>
#include <TIME.H>

#define ERROR_EXIT      2
#define SUCCESS_EXIT    0
#define STRING_LENGTH 256
#define PRIME           1
#define NOT_PRIME       0

static cxChar, cyChar;

#include "prime4.h"                 /* the RPC interface definitions       */
#include "primec4.h"                /* client-specific header file         */

HANDLE hInst;                       /* current instance                    */
HCURSOR hHourGlass, hOld;           /* during calls to RPC API functions   */
char pszFail[MSGLEN];               /* RPC API failure message             */

RPC_STATUS status;                  /* returned by RPC API function        */

unsigned char *pszUuid                    = NULL;
unsigned char *pszProtocolSequence        = "ncacn_np";
unsigned char  szNetworkAddress[UNCLEN+1] = "\\\\servername";
unsigned char  szEndpoint[PATHLEN+1]      = "\\pipe\\prime";
unsigned char *pszOptions                 = NULL;
unsigned char *pszStringBinding           = NULL;

/* Prototypes of functions used in this application */  

void  next_prime(void);
extern void LocalComputer(void);
extern void RemoteComputer(void);
unsigned char IsPrime(unsigned long TestNumber);
unsigned long PrimeServerHandle;
void InitializeApplication(void);
extern void statistics(void);
extern void NotifyServer(void);
extern char ServerStatus(void);

/*
NextNumber    - Next available number to test
StartTime     - Time that we start to compute primes
CurrTime      - Current Computer time
NoPrimeLocal  - Number of primes computed locally
NoPrimeRemote - Number of primes computed on the remote computer
StartNumber   - The starting number for testing primes
*/

unsigned long NextNumber = 1,  NoPrimeLocal, NoPrimeRemote, StartNumber = 1;
clock_t StartTime, CurrTime, sleepTime;
char computer_name_buffer[255] = "WIN31";
unsigned choice;
char rpc_on = FALSE;
char remote_only = FALSE;
PCONTEXT_HANDLE_TYPE phContext = NULL;
char szString[MSGLEN + 1];

TEXTMETRIC tm;
HWND hWnd, hWndTest, hWndPrime, hWndStat;    /* Main window handle.    */

int APIENTRY WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
   HANDLE hInstance;                            /* current instance       */
   HANDLE hPrevInstance;                        /* previous instance      */
   LPSTR lpCmdLine;                             /* command line           */
   int nCmdShow;                                /* show-window type       */
   {
   MSG msg;
   UNREFERENCED_PARAMETER(lpCmdLine);

   if(!hPrevInstance)
      if(!InitApplication(hInstance))
         return(FALSE);

   if(!InitInstance(hInstance, nCmdShow))
      return(FALSE);

   StartTime = clock();

   while(TRUE)
      {
      if(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
         {
         if(msg.message == WM_QUIT)
            break;
         TranslateMessage(&msg);
         DispatchMessage(&msg);
         }
      else
         {
         next_prime();
         }
      }

   NotifyServer();
   DestroyWindow(hWnd);

   return(msg.wParam);
   }

BOOL InitApplication(hInstance)
HANDLE hInstance;
   {
   WNDCLASS  wc;

   /* Fill in window class structure with parameters that describe the */
   /* main window.                                                     */

   wc.style = NULL;            
   wc.lpfnWndProc = (WNDPROC)MainWndProc; 
   wc.cbClsExtra = 0;                  
   wc.cbWndExtra = 0;                  
   wc.hInstance = hInstance;           
   wc.hIcon = LoadIcon(hInstance, "PrimeIcon");   
   wc.hCursor = LoadCursor(NULL, IDC_ARROW);
   wc.hbrBackground = GetStockObject(WHITE_BRUSH);
   wc.lpszMenuName =  "PrimeMenu";  
   wc.lpszClassName = "PrimeWClass";

   /* Register the window class and return success/failure code. */

   return (RegisterClass(&wc));
   }

HDC hDC;

BOOL InitInstance(hInstance, nCmdShow)
HANDLE          hInstance;          
int             nCmdShow;           
   {
   hInst = hInstance;

   hDC = GetDC(hWnd);
   GetTextMetrics(hDC,&tm);
   cxChar = tm.tmAveCharWidth;
   cyChar = tm.tmHeight + tm.tmExternalLeading;
   ReleaseDC(hWnd,hDC);

   hHourGlass = LoadCursor(NULL, IDC_WAIT);
   /* Create a main window for this application instance.  */

   hWnd = CreateWindow(
      "PrimeWClass",                
      "PRIMEC4 Windows Client",     
      WS_MINIMIZEBOX|WS_SYSMENU|WS_CLIPCHILDREN|WS_BORDER,          
      cxChar*5,                
      cyChar*5,                
      cxChar*66,               
      cyChar*25,               
      NULL,                    
      NULL,                    
      hInstance,               
      NULL                     
      );

   /* If window could not be created, return "failure" */

   if(!hWnd)
      return (FALSE);
   ShowWindow(hWnd, nCmdShow); 

   hWndTest = CreateWindow(
      "PrimeWClass",           
      "Testing...", 
      WS_CHILD|WS_VISIBLE|WS_BORDER,     
      cxChar*2,                
      cyChar*2,                
      cxChar*20,               
      cyChar*18,               
      hWnd,                    
      NULL,                    
      hInstance,               
      NULL                     
      );

   /* If window could not be created, return "failure" */

   if(!hWndTest)
      return (FALSE);
   ShowWindow(hWndTest, SW_SHOW);

   hWndPrime = CreateWindow(
      "PrimeWClass",                
      "PRIME...",    
      WS_CHILD|WS_VISIBLE|WS_BORDER,      
      cxChar*(60-2-2-30),                 
      cyChar*2,                
      cxChar*20,               
      cyChar*18,               
      hWnd,                    
      NULL,                    
      hInstance,               
      NULL                     
      );

   /* If window could not be created, return "failure" */

   if(!hWndPrime)
      return (FALSE);
   ShowWindow(hWndPrime, SW_SHOW); 

   hWndStat = CreateWindow(
      "PrimeWClass",              
      "STATS...",    
      WS_CHILD|WS_VISIBLE|WS_BORDER,  
      cxChar*(48),        
      cyChar*2,                 
      cxChar*17,                
      cyChar*7,                 
      hWnd,                     
      NULL,                     
      hInstance,                
      NULL                      
      );

   /* If window could not be created, return "failure" */

   if(!hWndPrime)
      return(FALSE);

   ShowWindow(hWndPrime, SW_SHOW);
   UpdateWindow(hWndPrime);       

   UpdateWindow(hWnd);        
   UpdateWindow(hWndTest);    
   UpdateWindow(hWndPrime);   

   rpc_on = FALSE;

      {
      FARPROC lpProc;        
      lpProc = MakeProcInstance((FARPROC)Server, hInst);
      DialogBox(hInst,     
         "ServerBox",     
         hWnd,            
         lpProc);         
      FreeProcInstance(lpProc);
      }

/* Make the window visible; update its client area; and return "success" */

   return(TRUE);               /* Returns the value from PostQuitMessage */
   }

long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
UINT message;
WPARAM wParam;
LPARAM lParam;
   {
   char Buffer[STRING_LENGTH];
   FARPROC lpProc;               /* pointer to the dialog box function */
   PAINTSTRUCT ps;
   RECT rc;
   HBRUSH hBrush;

   switch(message)
      {
      case WM_PAINT:
         hDC = BeginPaint(hWnd, &ps);
         GetClientRect(hWnd, &rc);
         hBrush = CreateSolidBrush(RGB(255, 255, 255));
         FillRect(hDC, &rc, hBrush);
         DeleteObject(hBrush);
         EndPaint(hWnd, &ps);
         InitializeApplication();
         ValidateRect(hWnd, NULL);
         break;

      case WM_COMMAND:   /* message: command from application menu */
         switch (wParam)
            {
            case IDM_ABOUT:
               lpProc = MakeProcInstance((FARPROC)About, hInst);
               DialogBox(hInst,     /* current instance         */
                  "AboutBox",       /* resource to use          */
                  hWnd,             /* parent handle            */
                  lpProc);          /* About() instance address */
                  FreeProcInstance(lpProc);
               break;

            case IDM_SERVER:
               lpProc = MakeProcInstance((FARPROC)Server, hInst);
               DialogBox(hInst,     /* current instance         */
                  "ServerBox",      /* resource to use          */
                  hWnd,             /* parent handle            */
                  lpProc);          /* Server  instance address */
               FreeProcInstance(lpProc);
               InvalidateRect(hWndStat,0,FALSE);
               break;

            case IDM_ENDPOINT:
               lpProc = MakeProcInstance((FARPROC)Endpoint, hInst);
               DialogBox(hInst,     /* current instance         */
                  "EndpointBox",    /* resource to use          */
                  hWnd,             /* parent handle            */
                  lpProc);          /* Server  instance address */
               FreeProcInstance(lpProc);
               break;

            case IDM_FIRST:
               _ltoa(StartNumber, szString, 10);
               lpProc = MakeProcInstance((FARPROC)First, hInst);
               DialogBox(hInst,     /* current instance         */
                  "FirstBox",       /* resource to use          */
                  hWnd,             /* parent handle            */
                  lpProc);          /* Server  instance address */
               FreeProcInstance(lpProc);
               NextNumber = StartNumber = strtoul(szString, NULL, 10);
               InvalidateRect(hWndTest, 0, FALSE);
               InvalidateRect(hWndPrime, 0, FALSE);
               InvalidateRect(hWndStat, 0, FALSE);
               break;

            case IDM_REMOTE:
               {
               HMENU hmenu;
               BOOL fOwnerDraw;

               hmenu = GetMenu(hWnd);
               fOwnerDraw = GetMenuState(hmenu, IDM_REMOTE, MF_BYCOMMAND)
                  & MF_CHECKED;
               if(fOwnerDraw)
                  remote_only = FALSE;
               else
                  remote_only = TRUE;
               CheckMenuItem(hmenu, IDM_REMOTE, MF_BYCOMMAND |
                  (fOwnerDraw ? MF_UNCHECKED : MF_CHECKED));
               }
               break;

            case IDM_LOCAL:
               strcpy(szString,computer_name_buffer);
               lpProc = MakeProcInstance((FARPROC)Local, hInst);
               DialogBox(hInst,     /* current instance         */
                  "LocalBox",       /* resource to use          */
                  hWnd,             /* parent handle            */
                  lpProc);          /* Server  instance address */
               FreeProcInstance(lpProc);
               strcpy(computer_name_buffer, szString);
               InvalidateRect(hWndStat, 0, FALSE);
               break;

            case IDM_EXIT:
               NotifyServer();
               DestroyWindow(hWnd);
               break;

            default:                /* Lets Windows process it         */
               return(DefWindowProc(hWnd, message, wParam, lParam));
            }
            break;

      case WM_DESTROY:              /* message: window being destroyed */
         PostQuitMessage(0);
         break;

      default:                      /* Passes it on if unprocessed     */
         return (DefWindowProc(hWnd, message, wParam, lParam));
      }
   return (NULL);
   }

BOOL APIENTRY Server(
   HWND hDlg,                         /* window handle of the dialog box */
   UINT message,                      /* type of message                 */
   UINT wParam,                       /* message-specific information    */
   LONG lParam)
   {
   UNREFERENCED_PARAMETER(lParam);

   switch(message)
      {
      case WM_INITDIALOG:             /* message: initialize dialog box  */
         SetDlgItemText(hDlg, IDD_SERVERNAME, szNetworkAddress);
         return (TRUE);

      case WM_COMMAND:                    /* message: received a command */
         switch(wParam)
            {
            case IDCANCEL:                /* System menu close command?  */
               EndDialog(hDlg, FALSE);
               return(TRUE);
            case IDOK:                    /* "OK" box selected?          */
               GetDlgItemText(hDlg, IDD_SERVERNAME, szNetworkAddress,
                  UNCLEN);
               hOld = SetCursor(hHourGlass);
               if (Bind(hDlg) != 0)
                  {
                  EndDialog(hDlg, FALSE);
                  return(FALSE);
                  }
               SetCursor(hOld);
               EndDialog(hDlg, TRUE);
               return(TRUE);
            } 
      }
   return (FALSE);              /* Didn't process a message    */
   }

BOOL APIENTRY About(
   HWND hDlg,                         /* window handle of the dialog box */
   UINT message,                      /* type of message                 */
   UINT wParam,                       /* message-specific information    */
   LONG lParam)
   {
   UNREFERENCED_PARAMETER(lParam);

   switch(message)
      {
      case WM_INITDIALOG:            /* message: initialize dialog box */
         return (TRUE);

      case WM_COMMAND:               /* message: received a command    */
         if(wParam == IDOK           /* "OK" box selected?             */
            || wParam == IDCANCEL)
            {      /* System menu close command? */
            EndDialog(hDlg, TRUE);   /* Exits the dialog box           */
            return (TRUE);
            }
         break;
      }
   return (FALSE);                   /* Didn't process a message       */
   }

BOOL APIENTRY Endpoint(
   HWND hDlg,                        /* window handle of the dialog box */
   UINT message,                     /* type of message                 */
   UINT wParam,                      /* message-specific information    */
   LONG lParam)
   {
   UNREFERENCED_PARAMETER(lParam);

   switch(message)
      {
      case WM_INITDIALOG:            /* message: initialize dialog box */
         SetDlgItemText(hDlg, IDD_ENDPOINTNAME, szEndpoint);
         return (TRUE);

      case WM_COMMAND:               /* message: received a command    */
      switch(wParam)
         {
         case IDCANCEL:              /* System menu close command?     */
            EndDialog(hDlg, FALSE);
            return(TRUE);

         case IDOK:                  /* "OK" box selected?             */
            GetDlgItemText(hDlg, IDD_ENDPOINTNAME, szEndpoint, PATHLEN);
            hOld = SetCursor(hHourGlass);
            if(Bind(hDlg) != 0)
               {
               EndDialog(hDlg, FALSE);
               return(FALSE);
               }
            SetCursor(hOld);
            EndDialog(hDlg, TRUE);
            return(TRUE);
         }
      } 
   return (FALSE);                   /* Didn't process a message       */
   }

BOOL APIENTRY First(
   HWND hDlg,                         /* window handle of the dialog box */
   UINT message,                      /* type of message                 */
   UINT wParam,                       /* message-specific information    */
   LONG lParam)
   {
   UNREFERENCED_PARAMETER(lParam);

   switch(message)
      {
      case WM_INITDIALOG:             /* message: initialize dialog box */
         SetDlgItemText(hDlg, IDD_MESSAGE, szString);
         return (TRUE);

      case WM_COMMAND:                /* message: received a command    */
         switch(wParam)
            {
            case IDCANCEL:            /* System menu close command?     */
               EndDialog(hDlg, FALSE);
               return(TRUE);

            case IDOK:                /* "OK" box selected?             */
               GetDlgItemText(hDlg, IDD_MESSAGE, szString, MSGLEN);
               RpcTryExcept
                  {
                  }
               RpcExcept(1)
                  {
                  MessageBox(hDlg,
                     EXCEPT_MSG,
                     "Remote Procedure Call",
                     MB_ICONINFORMATION);
                  }
               RpcEndExcept
               EndDialog(hDlg, TRUE);
               return(TRUE);
            }                         /* end switch wParam              */
      }                               /* end switch message             */
   return(FALSE);                     /* Didn't process a message       */
   }

BOOL APIENTRY Local(
   HWND hDlg,                         /* window handle of the dialog box */
   UINT message,                      /* type of message                 */
   UINT wParam,                       /* message-specific information    */
   LONG lParam)
   {
   UNREFERENCED_PARAMETER(lParam);
   switch(message)
      {
      case WM_INITDIALOG:             /* message: initialize dialog box  */
         SetDlgItemText(hDlg, IDD_MESSAGE, szString);
         return(TRUE);

      case WM_COMMAND:                /* message: received a command     */
         switch(wParam)
            {
            case IDCANCEL:            /* System &menu close command?     */
               EndDialog(hDlg, FALSE);
               return(TRUE);

            case IDOK:                /* "OK" box selected?              */
               GetDlgItemText(hDlg, IDD_MESSAGE, szString, MSGLEN);

            RpcTryExcept
               {
               }
            RpcExcept(1)
               {
               MessageBox(hDlg,
                  EXCEPT_MSG,
                  "Remote Procedure Call",
                  MB_ICONINFORMATION);
               }
            RpcEndExcept
            EndDialog(hDlg, TRUE);
            return(TRUE);
            }                         /* end switch wParam               */
      }                               /* end switch message              */
   return (FALSE);                    /* Didn't process a message        */
   }

RPC_STATUS Bind(HWND hWnd)
   {
   RPC_STATUS status;

   if(rpc_on == TRUE)
      {                               /* unbind only if bound        */
      NotifyServer();
      status = RpcBindingFree(&prime_IfHandle);
      if(status)
         {
         MessageBox(hWnd, "RpcBindingFree failed", "RPC Error",
            MB_ICONSTOP);
         return(status);
         }
      else
         rpc_on = FALSE;   /* unbind successful; reset flag */
      }

   status = RpcStringBindingCompose(
      pszUuid,
      pszProtocolSequence,
      szNetworkAddress,
      szEndpoint,
      pszOptions,
      &pszStringBinding);

   if(status)
      {
      wsprintf(pszFail,
         "RpcStringBindingCompose failed: (0x%x)\nNetwork Address = %s\n",
         status, szNetworkAddress);
      MessageBox(hWnd, pszFail, "RPC Runtime Error", MB_ICONEXCLAMATION);
      return(status);
      }
   status = RpcBindingFromStringBinding(pszStringBinding,
      &prime_IfHandle);

   if(status)
      {
      wsprintf(pszFail,
         "RpcBindingFromStringBinding failed:(0x%x)\nString = %s\n",
         status, pszStringBinding);
      MessageBox(hWnd, pszFail, "RPC Runtime Error", MB_ICONEXCLAMATION);
      if(status == 6)
         {
         wsprintf(pszFail,"Please load RPC runtime support!!");
         MessageBox(hWnd, pszFail, "RPC Runtime Error",
            MB_ICONEXCLAMATION);
         }
      return(status);
      }

   rpc_on = TRUE;                      /* bind successful; reset flag */
   ServerStatus();
   return(status);
   }

void next_prime(void)
   {
   HDC hDC;
   char Buffer[STRING_LENGTH];

   memset(Buffer, ' ', STRING_LENGTH);
   hDC = GetDC(hWnd);
   if(!(rpc_on == 1 && remote_only == 1))
      {
      ++NextNumber;
      if((NextNumber - 1) / 2 * 2 == NextNumber - 1)
         ++NextNumber;
      LocalComputer();
      }

   if(rpc_on)
      {
      ++NextNumber;
      if((NextNumber - 1) / 2 * 2 == NextNumber - 1)
         ++NextNumber;
      RemoteComputer();

      TextOut(hDC,6 * cxChar, 21 * cyChar, Buffer, 16),
         TextOut(hDC, 15 * cxChar, 21 * cyChar,
         "Prime number server is ", 23);
      TextOut(hDC, 35 * cxChar, 21 * cyChar, &szNetworkAddress[2],
         strlen(&szNetworkAddress[2]));
      wsprintf(Buffer, " (%lu)", PrimeServerHandle);
      TextOut(hDC, 45 * cxChar, 21 * cyChar, Buffer, strlen(Buffer));
         {
         unsigned char len = strlen(Buffer);
         memset(Buffer, ' ', STRING_LENGTH);
         TextOut(hDC, (44 + len) * cxChar, 21 * cyChar, Buffer, 33);
         }
      }
   else
      if(++choice > 100)
         {
         choice =0;
         ServerStatus();
         if(rpc_on)
            {
            ++NextNumber;
            if((NextNumber - 1) / 2 * 2 == NextNumber - 1)
               ++NextNumber;
            RemoteComputer();
            TextOut(hDC, 6 * cxChar, 21 * cyChar, Buffer, 16),
               TextOut(hDC, 15 * cxChar, 21 * cyChar,
               "Prime number server is ", 23);
            TextOut(hDC, 35 * cxChar, 21 * cyChar, &szNetworkAddress[2],
               strlen(&szNetworkAddress[2]));
            wsprintf(Buffer, " (%lu)", PrimeServerHandle);
            TextOut(hDC, 45 * cxChar, 21 * cyChar, Buffer, strlen(Buffer));
               {
               unsigned char len = strlen(Buffer);
               memset(Buffer, ' ', STRING_LENGTH);
               TextOut(hDC, (44 + len) * cxChar, 21 * cyChar, Buffer, 33);
               }
            }
         }
      else
         {
         TextOut(hDC, 6 * cxChar, 21 * cyChar, "Prime number server ", 20);
         strcpy(Buffer, szNetworkAddress);
         Buffer[12] = 0;
         TextOut(hDC, 26 * cxChar, 21 * cyChar, Buffer, strlen(Buffer));
         TextOut(hDC, (27 + strlen(Buffer)) * cxChar, 21 * cyChar,
            " is off-line.  Please restart it.", 33);
         }
   ReleaseDC(hWnd,hDC);
   }

char nlineP = -1, nlineT = -1;

void LocalComputer(void)
   {
   RECT rUpdate;
   char Buffer[STRING_LENGTH];
   HDC hDCT,hDCP;

   if(NextNumber <= ULONG_MAX)
      {
      if(nlineT == 18)
         {
         ScrollWindow(hWndTest, 0, -cyChar, 0, 0);
         }
      else
         nlineT++;

      hDCT = GetDC(hWndTest);
      SetTextColor(hDCT, RGB(0, 0, 255));
      wsprintf(Buffer, "%lu", NextNumber - 1);
      TextOut(hDCT, cxChar, (nlineT - 1) * cyChar, Buffer, strlen(Buffer));
      TextOut(hDCT, 11 * cxChar, (nlineT - 1) * cyChar, "LOCAL    ", 9);
      GetUpdateRect(hWndTest, &rUpdate, FALSE);
      ValidateRect(hWndTest, &rUpdate);

      ReleaseDC(hWndTest, hDCT);

      if(IsPrime(NextNumber - 1) != 0)
         {
         if(nlineP == 18)
            {
            ScrollWindow(hWndPrime, 0, -cyChar, 0, 0);
            }
         else
            nlineP++;

         hDCP = GetDC(hWndPrime);
         SetTextColor(hDCP, RGB(0, 0, 255));
         wsprintf(Buffer, "%lu", NextNumber - 1);
         TextOut(hDCP, cxChar, (nlineP - 1) * cyChar, Buffer,
            strlen(Buffer));
         TextOut(hDCP, 11 * cxChar, (nlineP - 1) * cyChar, "LOCAL    ", 9);

         GetUpdateRect(hWndPrime, &rUpdate, FALSE);
         ValidateRect(hWndPrime, &rUpdate);
         ReleaseDC(hWndPrime, hDCP);

         NoPrimeLocal++;
         }
      statistics();

      return;
      }
   }

unsigned char IsPrime(unsigned long TestNumber)
   {
   unsigned long count;
   unsigned long HalfNumber = TestNumber / 2 + 1;

   for(count = 2; count < HalfNumber; count++)
      if(TestNumber % count == 0)
         return NOT_PRIME;

   return PRIME;
   }

void InitializeApplication(void)
   {
   HDC hDC,hDCS;
   char Buffer[STRING_LENGTH];

   wsprintf(Buffer, "First= %lu", StartNumber);
   hDCS = GetDC(hWndStat);
   SetTextColor(hDCS, RGB(0, 0, 255));
   TextOut(hDCS, cxChar, 5 * cyChar, Buffer, strlen(Buffer));
   wsprintf(Buffer, "%s", computer_name_buffer);
   TextOut(hDCS, cxChar, 6 * cyChar, Buffer, strlen(Buffer));
   ReleaseDC(hWndStat, hDCS);

   hDC = GetDC(hWnd);
   TextOut(hDC, 2 * cxChar, 1 * cyChar, "Prime...", 8);
   TextOut(hDC, 26 * cxChar, 1 * cyChar, "Testing...", 10);
   ReleaseDC(hWnd, hDC);
   }

void RemoteComputer(void)
   {
   RECT rUpdate;
   HDC hDCT,hDCP;
   char Buffer[STRING_LENGTH];

   if(NextNumber <= ULONG_MAX)
      {
      if(nlineT == 18)
         {
         ScrollWindow(hWndTest, 0, -cyChar, 0, 0);
         }
      else
         nlineT++;

      wsprintf(Buffer, "%lu", NextNumber - 1);
      hDCT = GetDC(hWndTest);
      SetTextColor(hDCT, RGB(255, 0, 0));
      TextOut(hDCT, cxChar, (nlineT - 1) * cyChar, Buffer, strlen(Buffer));
      TextOut(hDCT, 11 * cxChar, (nlineT - 1) * cyChar, "REMOTE", 6);
      GetUpdateRect(hWndTest, &rUpdate,FALSE);
      ValidateRect(hWndTest, &rUpdate);
      ReleaseDC(hWndTest, hDCT);
      RpcTryExcept
         {
         if(RemoteIsPrime(PrimeServerHandle, NextNumber - 1) != 0)
            {
            if(nlineP == 18)
               {
               ScrollWindow(hWndPrime, 0, -cyChar, 0, 0);
               }
            else
               nlineP++;

            hDCP = GetDC(hWndPrime);
            SetTextColor(hDCP, RGB(255, 0, 0));
            wsprintf(Buffer, "%lu", NextNumber - 1);
            TextOut(hDCP, cxChar, (nlineP - 1) * cyChar, Buffer,
               strlen(Buffer));
            TextOut(hDCP, 11 * cxChar, (nlineP - 1) * cyChar, "REMOTE", 6);
            GetUpdateRect(hWndPrime, &rUpdate, FALSE);
            ValidateRect(hWndPrime, &rUpdate);

            ReleaseDC(hWndPrime,hDCP);
            NoPrimeRemote++;
            }
         statistics();
         }
      RpcExcept(1)
         {
         rpc_on = FALSE;
         return;
         }
      RpcEndExcept

      return;
      }
   }

void NotifyServer(void)
   {
   RpcTryExcept
      {
      TerminatePrimeServer(PrimeServerHandle);
      }
   RpcExcept(1)
      {
      return;
      }
   RpcEndExcept
   }

char ServerStatus(void)
   {
   char value = FALSE;

   RpcTryExcept
      {
      PrimeServerHandle = InitializePrimeServer(&phContext,
         computer_name_buffer);
      }
   RpcExcept(1)
      {
      value = TRUE;
      }
   RpcEndExcept
   rpc_on = !value;
   return value;
   }

void statistics(void)
   {
   HDC hDCS;
   char Buffer[STRING_LENGTH];

   CurrTime = (clock() - StartTime) / CLK_TCK;
   wsprintf(Buffer, "Primes = %lu", NoPrimeLocal + NoPrimeRemote);
   hDCS = GetDC(hWndStat);
   SetTextColor(hDCS, RGB(0, 0, 255));
   TextOut(hDCS, cxChar, 3 * cyChar, Buffer, strlen(Buffer));
   wsprintf(Buffer, "Time = %ld.%02d min.", CurrTime/60, CurrTime%60);

   TextOut(hDCS, cxChar, 4 * cyChar, Buffer, strlen(Buffer));

   wsprintf(Buffer, "%s:%5lu", "LOCAL   ", NoPrimeLocal);
   TextOut(hDCS, cxChar, 0, Buffer, strlen(Buffer));
   wsprintf(Buffer, "%s:%5lu", "REMOTE", NoPrimeRemote);
   SetTextColor(hDCS, RGB(255, 0, 0));
   TextOut(hDCS, cxChar, cyChar, Buffer, strlen(Buffer));

   ReleaseDC(hWndStat, hDCS);
   }

void __RPC_FAR *__RPC_API MIDL_user_allocate(size_t len)
   {
   return(malloc(len));
   }

void __RPC_API MIDL_user_free(void __RPC_FAR *ptr)
   {
   free(ptr);
   }

