/****************************************************************************\
*                                                                            *
* Listing 8-7 
*                                                                            *
* PRIMEC4.C - Distributed prime number example                               *
*             (c) Guy Eddon, 1993                                            *
*                                                                            *
* To build:   NMAKE PRIME3.MAK                                               *
*                                                                            *
* Usage:      PRIMEC4                                                        *
*                                                                            *
* Comments:   This is the client side prime number program.                  *
*                                                                            *
\****************************************************************************/

#include <STDIO.H>
#include <STRING.H>
#include <STDLIB.H>
#include <STDARG.H>
#include <LIMITS.H>
#include <CTYPE.H>
#include <WINDOWS.H>
#include <RPC.H>
#include "prime4.h"
#include "directio.h"

/* Coordinates for displaying numbers to be tested */

#define TESTING_X1      3
#define TESTING_Y1      3
#define TESTING_X2     23
#define TESTING_Y2     18

/* Coordinates for displaying prime numbers */

#define PRIME_X1       30
#define PRIME_Y1        3
#define PRIME_X2       50
#define PRIME_Y2       18

/* If we found a prime then return PRIME, otherwise return NOT_PRIME */

#define PRIME           1
#define NOT_PRIME       0

/* Max number of threads for this application */

#define MAX_THREADS    10

#define ERROR_EXIT      2
#define SUCCESS_EXIT    0

/* Delay time in microseconds */

#define STRING_LENGTH 256
#define WAIT          350

/* Colors used in this application */

#define WHITE_ON_BLUE FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_BLUE
#define WHITE_ON_CYAN FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_CYAN
#define RED_ON_BLUE   FOREGROUND_RED|FOREGROUND_INTENSITY|BACKGROUND_BLUE

/* Prototypes of functions used in this application */

unsigned char IsPrime(unsigned long TestNumber);
extern char ServerStatus(void);
extern void thread_local(void);
extern void thread_remote(void);
extern void Usage(void);
extern void InitializeApplication(void);
extern void statistics(void);
extern void NotifyServer(void);

/* Critical Section for choosing next available number for testing */

CRITICAL_SECTION GlobalCriticalSection;

/* Storage for Computer Name */

char computer_name_buffer[MAX_COMPUTERNAME_LENGTH];

/* Unique number returned by the server */

unsigned long PrimeServerHandle;

/*
NextNumber    - Next available number to test
StartTime     - Time that we start to compute primes
CurrTime      - Current Computer time
NoPrimeLocal  - Number of primes computed locally
NoPrimeRemote - Number of primes computed on the remote computer
StartNumber   - The starting number for testing primes
*/

unsigned long NextNumber = 1, StartTime, CurrTime, NoPrimeLocal,
   NoPrimeRemote, StartNumber = 1;

/*
   Context Handle - Contains binding information and information about
   the state of the processing task on the server. State information is not
   available to the client, it can be only accesses by the server
*/

PCONTEXT_HANDLE_TYPE phContext = NULL;

void _CRTAPI1 main(int argc, char **argv)
   {
   RPC_STATUS status; /* returned by RPC API function */

   unsigned char *pszUuid             = NULL;
   unsigned char *pszProtocolSequence = "ncacn_np";
   unsigned char *pszNetworkAddress   = NULL;
   unsigned char *pszEndpoint         = "\\pipe\\prime";
   unsigned char *pszOptions          = NULL;
   unsigned char *pszStringBinding    = NULL;

   DWORD  Max_ComputerName_Length = MAX_COMPUTERNAME_LENGTH;
   DWORD  lpIDThread;
   HANDLE hthread_remote;

   int count;

/* Allow the user to override settings with command line switches */

   for(count = 1; count < argc; count++)
      {
      if((*argv[count] == '-') || (*argv[count] == '/'))
         {
         switch(tolower(*(argv[count]+1)))
            {
            case 'p': /* protocol sequence */
               pszProtocolSequence = argv[++count];
               break;

            case 'n': /* network address   */
               pszNetworkAddress = argv[++count];
               break;

            case 'e':
               pszEndpoint = argv[++count];
               break;

            case 'o':
               pszOptions = argv[++count];
               break;

            case 'f': /* first number */
               NextNumber = StartNumber = atol(argv[++count]);
               break;

            case 'h':
            case '?':
            default:
               Usage();
            }
         }
      else
         Usage();
      }

/*
   Use a convenience function to concatenate the elements of
   the string binding into the proper sequence
*/

   status = RpcStringBindingCompose(
      pszUuid,
      pszProtocolSequence,
      pszNetworkAddress,
      pszEndpoint,
      pszOptions,
      &pszStringBinding);

   if(status)
      exit(ERROR_EXIT);

/* Set the binding handle that will be used to bind to the server */

   status = RpcBindingFromStringBinding(pszStringBinding, &prime_IfHandle);

   if(status)
      exit(ERROR_EXIT);

   GetComputerName(computer_name_buffer, &Max_ComputerName_Length);
   ServerStatus();
   InitializeApplication();

   InitializeCriticalSection(&GlobalCriticalSection);

/*
   Create thread with normal priority, the name of the thread routine is
   thread_remote
*/

   hthread_remote = CreateThread(NULL, 0,
      (LPTHREAD_START_ROUTINE)thread_remote, NULL, 0, &lpIDThread);

/* function to compute primes */

   thread_local();

   DeleteCriticalSection(&GlobalCriticalSection);

/*
   The calls to the remote procedures are complete
   Free the string and the binding handle
*/

   /* remote calls done - unbind */

   status = RpcStringFree(&pszStringBinding);

   if(status)
      exit(ERROR_EXIT);

   /* remote calls done - unbind */

   status = RpcBindingFree(&prime_IfHandle);

   printf("Unbinding from the prime number server.\n", status);

   if(status)
      exit(ERROR_EXIT);

   exit(SUCCESS_EXIT);
   }

void thread_local(void)
   {
   unsigned long temp;
   char Buffer[STRING_LENGTH];
   int loop;

   SMALL_RECT psrctScrollRectTesting, psrctScrollRectPrime;
   COORD coordDestOriginTesting, coordDestOriginPrime;
   CHAR_INFO pchiFill;
   WORD Color[TESTING_X2-TESTING_X1-3], Normal[TESTING_X2-TESTING_X1-3];

   COORD ComputTestCoord;
   COORD ComputPrimeCoord;

   DWORD dummy;
   COORD PrimeCoord;

   psrctScrollRectTesting.Left   = TESTING_X1+1;
   psrctScrollRectTesting.Top    = TESTING_Y1+2;
   psrctScrollRectTesting.Right  = TESTING_X2-1;
   psrctScrollRectTesting.Bottom = TESTING_Y2-1;

   coordDestOriginTesting.X = TESTING_X1+1;
   coordDestOriginTesting.Y = TESTING_Y1+1;

   psrctScrollRectPrime.Left   = PRIME_X1+1;
   psrctScrollRectPrime.Top    = PRIME_Y1+2;
   psrctScrollRectPrime.Right  = PRIME_X2-1;
   psrctScrollRectPrime.Bottom = PRIME_Y2-1;

   coordDestOriginPrime.X = PRIME_X1+1;
   coordDestOriginPrime.Y = PRIME_Y1+1;

   pchiFill.Char.AsciiChar = (char)32;
   pchiFill.Attributes = WHITE_ON_BLUE;

   ComputTestCoord.X  = TESTING_X2-7;
   ComputTestCoord.Y  = TESTING_Y2-1;
   ComputPrimeCoord.X = PRIME_X2-7;
   ComputPrimeCoord.Y = PRIME_Y2-1;

   for(loop = 0; loop < TESTING_X2-TESTING_X1-3; loop++)
      {
      Color[loop]  = RED_ON_BLUE;
      Normal[loop] = WHITE_ON_BLUE;
      }

   while(1)
      {

      /* If the user pressed ESC then notify the server and the exit */

      if(VK_ESCAPE == get_character_no_wait())
         {
         EnterCriticalSection(&GlobalCriticalSection);
         Sleep(WAIT);
         NotifyServer();
         clearscreen(0);
         exit(0);
         LeaveCriticalSection(&GlobalCriticalSection);
         }

      /* To make sure that we won't test the same number twice */

      EnterCriticalSection(&GlobalCriticalSection);
      if((temp = ++NextNumber) >= ULONG_MAX)
         break;
      LeaveCriticalSection(&GlobalCriticalSection);

      EnterCriticalSection(&GlobalCriticalSection);
      ScrollConsoleScreenBuffer(hStdOut, &psrctScrollRectTesting, NULL,
         coordDestOriginTesting, &pchiFill);
      sprintf(Buffer, "%d", temp - 1);
      mxyputs((unsigned char)TESTING_X1+2, (unsigned char)(TESTING_Y2-1),
         Buffer, WHITE_ON_BLUE);
      WriteConsoleOutputAttribute(hStdOut, Normal, 7, ComputTestCoord,
         &dummy);
      mxyputs((unsigned char)(TESTING_X2-7), (unsigned char)TESTING_Y2-1,
         "LOCAL ", WHITE_ON_BLUE);
      LeaveCriticalSection(&GlobalCriticalSection);

      if(IsPrime(temp - 1) != 0)
         {
         PrimeCoord.X = PRIME_X1 + 2;
         PrimeCoord.Y = PRIME_Y2 - 1;

         EnterCriticalSection(&GlobalCriticalSection);
         ScrollConsoleScreenBuffer(hStdOut, &psrctScrollRectPrime, NULL,
            coordDestOriginPrime, &pchiFill);
         sprintf(Buffer, "%-17d", temp - 1);
         mxyputs((unsigned char)(PRIME_X1+2), (unsigned char)PRIME_Y2-1,
            Buffer, WHITE_ON_BLUE);
         WriteConsoleOutputAttribute(hStdOut, Normal, 7, ComputPrimeCoord,
            &dummy);
         mxyputs((unsigned char)(PRIME_X2-7), (unsigned char)PRIME_Y2-1,
            "LOCAL ", WHITE_ON_BLUE);
         LeaveCriticalSection(&GlobalCriticalSection);
         NoPrimeLocal++;
         }

      statistics();
      }
   }

void thread_remote(void)
   {
   unsigned long temp;
   char Buffer[STRING_LENGTH];
   int loop;

   SMALL_RECT psrctScrollRectTesting, psrctScrollRectPrime;
   COORD coordDestOriginTesting, coordDestOriginPrime;
   CHAR_INFO pchiFill;
   WORD Color[TESTING_X2-TESTING_X1-3], Normal[TESTING_X2-TESTING_X1-3];

   COORD ComputTestCoord;
   COORD ComputPrimeCoord;

   DWORD dummy;
   COORD PrimeCoord;

   psrctScrollRectTesting.Left   = TESTING_X1+1;
   psrctScrollRectTesting.Top    = TESTING_Y1+2;
   psrctScrollRectTesting.Right  = TESTING_X2-1;
   psrctScrollRectTesting.Bottom = TESTING_Y2-1;

   coordDestOriginTesting.X = TESTING_X1+1;
   coordDestOriginTesting.Y = TESTING_Y1+1;

   psrctScrollRectPrime.Left   = PRIME_X1+1;
   psrctScrollRectPrime.Top    = PRIME_Y1+2;
   psrctScrollRectPrime.Right  = PRIME_X2-1;
   psrctScrollRectPrime.Bottom = PRIME_Y2-1;

   coordDestOriginPrime.X = PRIME_X1+1;
   coordDestOriginPrime.Y = PRIME_Y1+1;

   pchiFill.Char.AsciiChar = (char)32;
   pchiFill.Attributes = WHITE_ON_BLUE;

   ComputTestCoord.X  = TESTING_X2-7;
   ComputTestCoord.Y  = TESTING_Y2-1;
   ComputPrimeCoord.X = PRIME_X2-7;
   ComputPrimeCoord.Y = PRIME_Y2-1;

   for(loop = 0; loop < TESTING_X2-TESTING_X1-3; loop++)
      {
      Color[loop]  = RED_ON_BLUE;
      Normal[loop] = WHITE_ON_BLUE;
      }

   while(1)
      {

/* If the user pressed ESC then notify the server and the exit */

      if(VK_ESCAPE == get_character_no_wait())
         {
         EnterCriticalSection(&GlobalCriticalSection);
         Sleep(WAIT);
         NotifyServer();
         clearscreen(0);
         exit(0);
         LeaveCriticalSection(&GlobalCriticalSection);
         }

      EnterCriticalSection(&GlobalCriticalSection);
      if((temp = ++NextNumber) >= ULONG_MAX)
         break;
      LeaveCriticalSection(&GlobalCriticalSection);


/* To make sure that we won't test the same number twice */

      EnterCriticalSection(&GlobalCriticalSection);
      ScrollConsoleScreenBuffer(hStdOut, &psrctScrollRectTesting, NULL,
         coordDestOriginTesting, &pchiFill);
      sprintf(Buffer, " %-17d", temp - 1);
      mxyputs((unsigned char)TESTING_X1+1, (unsigned char)(TESTING_Y2-1),
         Buffer, RED_ON_BLUE);
      WriteConsoleOutputAttribute(hStdOut, Color, 7, ComputTestCoord,
         &dummy);
      mxyputs((unsigned char)(TESTING_X2-7), (unsigned char)TESTING_Y2-1,
         "REMOTE ", RED_ON_BLUE);
      LeaveCriticalSection(&GlobalCriticalSection);

TryAgain:
      RpcTryExcept
         {
         if(RemoteIsPrime(PrimeServerHandle, temp - 1) != 0)
            {
            EnterCriticalSection(&GlobalCriticalSection);
            PrimeCoord.X = TESTING_X1 + 2;
            LeaveCriticalSection(&GlobalCriticalSection);

            PrimeCoord.X = PRIME_X1 + 2;
            PrimeCoord.Y = PRIME_Y2 - 1;

            EnterCriticalSection(&GlobalCriticalSection);
            ScrollConsoleScreenBuffer(hStdOut, &psrctScrollRectPrime, NULL,
               coordDestOriginPrime, &pchiFill);
            sprintf(Buffer, " %-17d", temp - 1);
            mxyputs((unsigned char)(PRIME_X1+1), (unsigned char)PRIME_Y2-1,
               Buffer, RED_ON_BLUE);
            WriteConsoleOutputAttribute(hStdOut, Color, 7, ComputPrimeCoord,
               &dummy);
            mxyputs((unsigned char)(PRIME_X2-7), (unsigned char)PRIME_Y2-1,
               "REMOTE ", RED_ON_BLUE);
            LeaveCriticalSection(&GlobalCriticalSection);

            NoPrimeRemote++;
            }

         statistics();
         }

      RpcExcept(1)
         {

/* if exceptions occur */

         while(ServerStatus())
            {
            for(loop = 0; loop < 5; loop++)
               {
               mxyputs((unsigned char)15, (unsigned char)21,
                  "Prime number server is off-line.  Please restart it.", 
                   WHITE_ON_CYAN);
               Sleep(WAIT);
               mxyputc((unsigned char)15, (unsigned char)21, (char)32, 52,
                  FOREGROUND_CYAN|FOREGROUND_INTENSITY|BACKGROUND_CYAN);
               Sleep(WAIT);
               }
            }

         goto TryAgain;
         }
      RpcEndExcept
      }
   }

/* Tests for prime number on the local computer */

unsigned char IsPrime(unsigned long TestNumber)
   {
   unsigned long count;
   unsigned long HalfNumber = TestNumber / 2 + 1;

   for(count = 2; count < HalfNumber; count++)
      if(TestNumber % count == 0)
         return NOT_PRIME;

   return PRIME;
   }


/* Displays command line options */

void Usage(void)
   {
   printf("\nContext Handle prime number example.\n\n");
   printf("Usage: PRIMEC4\n");
   printf(" -p protocol_sequence\n");
   printf(" -n network_address\n");
   printf(" -e endpoint\n");
   printf(" -o options\n");
   printf(" -f first number\n");
   exit(1);
   }


/* Screen Initialization and colors and title lines */

void InitializeApplication(void)
   {
   char Buffer[STRING_LENGTH];
   set_vid_mem();

   clearscreen(BACKGROUND_CYAN);
   StartTime = GetTickCount();

   box(0, 0, 79, 24,DOUBLE);
   mxyputs(37, 0, " PRIMEC4 ", WHITE_ON_CYAN);

   mxyputs(TESTING_X1, 2, "Testing...", WHITE_ON_CYAN);
   box(TESTING_X1, TESTING_Y1, TESTING_X2, TESTING_Y2, SINGLE);

   mxyputs(PRIME_X1, 2, "Prime!",WHITE_ON_CYAN);
   box(PRIME_X1, PRIME_Y1, PRIME_X2, PRIME_Y2, SINGLE);

   mxyputs(58, 2, "Number of Primes", WHITE_ON_CYAN);
   box(58, 3, 73, (unsigned char)(1+5), SINGLE);

   sprintf(Buffer,"First = %d", StartNumber);
   mxyputs(58,(unsigned char)(1+5+3), Buffer, WHITE_ON_CYAN);

   mxyputs(32, 23, "Press Esc to exit", WHITE_ON_CYAN);
   }

/*
   Check the Server status if it is of line, then try to connect, return
   server status
*/

char ServerStatus(void)
   {
   char value = FALSE;

   RpcTryExcept
      {
      PrimeServerHandle = InitializePrimeServer(&phContext,
         computer_name_buffer);
      }
   RpcExcept(1)
      {
      value = TRUE;
      }
   RpcEndExcept

   return value;
   }


/* Dislay information about the progress of computing prime numbers */

void statistics(void)
   {
   char Buffer[STRING_LENGTH];

   CurrTime = (GetTickCount() - StartTime)/1000;
   sprintf(Buffer, "Primes = %d", NoPrimeLocal+NoPrimeRemote);
   mxyputs(58, (unsigned char)(7), Buffer, WHITE_ON_CYAN);
   sprintf(Buffer, "Time = %d.%02d min.", CurrTime/60, CurrTime%60);
   mxyputs(58, (unsigned char)(8), Buffer, WHITE_ON_CYAN);
   sprintf(Buffer, "%s:%5d", "LOCAL ", NoPrimeLocal);
   mxyputs((unsigned char)(60), (unsigned char)(4), Buffer, WHITE_ON_BLUE);
   sprintf(Buffer, "%s:%5d", "REMOTE", NoPrimeRemote);
   mxyputs((unsigned char)(60), (unsigned char)(5), Buffer, RED_ON_BLUE);
   }

/* Let the Server know that we are about to exit */

void NotifyServer(void)
   {
   RpcTryExcept
      {
      TerminatePrimeServer(PrimeServerHandle);
      }      
   RpcExcept(1)
      {
      return;
      }
   RpcEndExcept
   }

