/****************************************************************************\
*                                                                            *
* Listing 8-15                                                               *
*                                                                            *
* PRIME4.C - Prime number example,  This example is for DOS                  *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE PRIME4.DOS                                                *
*                                                                            *
* Usage:     PRIME4                                                          *
*                                                                            *
* Comments:  This example computes prime numbers.                            *
*                                                                            *
\****************************************************************************/

#include <STDIO.H>
#include <STRING.H>
#include <STDLIB.H>
#include <STDARG.H>
#include <LIMITS.H>
#include <WINDOWS.H>
#include <GRAPH.H>
#include <RPC.H>
#include <TIME.H>
#include "directio.h"
#include "prime4.h"

/* If we found a prime then return PRIME, otherwise return NOT_PRIME */

#define PRIME           1
#define NOT_PRIME       0

/* Coordinates for displaying numbers to be tested */

#define TESTING_X1     10
#define TESTING_Y1      3
#define TESTING_X2     30
#define TESTING_Y2     18

/* Coordinates for displaying prime numbers */

#define PRIME_X1       50
#define PRIME_Y1        3
#define PRIME_X2       70
#define PRIME_Y2       18

#define ERROR_EXIT      2
#define SUCCESS_EXIT    0
#define STRING_LENGTH 256

/* Colors used in this application */

#define WHITE_ON_BLUE FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_BLUE
#define WHITE_ON_CYAN FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_CYAN
#define RED_ON_BLUE   FOREGROUND_RED|FOREGROUND_INTENSITY|BACKGROUND_BLUE

/* Prototypes of functions used in this application */

extern void LocalComputer(void);
extern void RemoteComputer(void);
unsigned char IsPrime(unsigned long TestNumber);
unsigned long PrimeServerHandle;
void InitializeApplication(void);
void Usage(void);
extern void statistics(void);
extern void NotifyServer(void);
extern char ServerStatus(void);

/*
NextNumber    - Next available number to test
StartTime     - Time that we start to compute primes
CurrTime      - Current Computer time
NoPrimeLocal  - Number of primes computed locally
NoPrimeRemote - Number of primes computed on the remote computer
StartNumber   - The starting number for testing primes
*/

unsigned long NextNumber = 1,  NoPrimeLocal, NoPrimeRemote, StartNumber = 1;
clock_t StartTime, CurrTime, sleepTime;

char computer_name_buffer[255] = "MSDOS";
char Buffer[STRING_LENGTH];
unsigned  choice;
char rpc_on=FALSE;
char remote_only = FALSE;
PCONTEXT_HANDLE_TYPE	phContext = NULL;

void main(int argc, char **argv)
   {
   RPC_STATUS status;
   DWORD Max_ComputerName_Length = 255;

   unsigned char * pszUuid             = NULL;
   unsigned char * pszProtocolSequence = "ncacn_np";
   unsigned char * pszNetworkAddress   = NULL;
   unsigned char * pszEndpoint         = "\\pipe\\prime";
   unsigned char * pszOptions          = NULL;
   unsigned char * pszStringBinding    = NULL;

   int count;

   /* Allow the user to override settings with command line switches */
   /* Default name MSDOS  ovrrride with C option*/ 

   for(count = 1; count < argc; count++)
      {
      if((*argv[count] == '-') || (*argv[count] == '/'))
         {
         switch(tolower(*(argv[count]+1)))
            {
            case 'p': // protocol sequence
               pszProtocolSequence = argv[++count];
               break;

            case 'n': // network address
               pszNetworkAddress = argv[++count];
               break;

            case 'e':
               pszEndpoint = argv[++count];
               break;

            case 'o':
               pszOptions = argv[++count];
               break;

            case 'u':
               pszUuid = argv[++count];
               break;

            /* Default name MSDOS ovrrride with C option*/ 

            case 'c':
               strcpy(computer_name_buffer, argv[++count]);
               break;

            case 'f': /* first number */
               NextNumber = StartNumber = atol(argv[++count]);
               break;

            case 'r': /* remote_only */
               remote_only = atoi(argv[++count]);
               break;

            case 'h':
            case '?':
            default:
               Usage();
            }
         }
      else
         Usage();
      }

   /*
   Use a convenience function to concatenate the elements of
   the string binding into the proper sequence
   */

   status = RpcStringBindingCompose(pszUuid,
   pszProtocolSequence,
   pszNetworkAddress,
   pszEndpoint,
   pszOptions,
   &pszStringBinding);

   if(status)
       exit(ERROR_EXIT);

   /* Set the binding handle that will be used to bind to the server */

   status = RpcBindingFromStringBinding(pszStringBinding, &prime_IfHandle);

   if(status)
      {
      printf("RpcBindingFromStringBinding  exit");
      printf("  %d",status);
      if(status == 6)
         printf("\n\n\t\tPlease load RPC runtime support!!");
      printf("\n\n\tPress any key");
      keyboard();
      exit(ERROR_EXIT);
      }

   InitializeApplication();
   ServerStatus();

   while(1)
      {
      if(!(rpc_on==1 && remote_only ==1))
         {
         ++NextNumber;
         if((NextNumber-1)/2*2 == NextNumber - 1)
            ++NextNumber;
      LocalComputer();
      }

#define VID_BLINK 0x87

      if(rpc_on)
         {
         ++NextNumber;
         if((NextNumber - 1) / 2 * 2 == NextNumber - 1)
            ++NextNumber;
         RemoteComputer();
         mxyputc((unsigned char)10, (unsigned char)21, (char)32, 65,
            FOREGROUND_CYAN|FOREGROUND_INTENSITY|BACKGROUND_CYAN);
         mxyputs((unsigned char)15, (unsigned char)21,
            "Prime number server is ",WHITE_ON_CYAN);
         mxyputs((unsigned char)35, (unsigned char)21,
            &pszNetworkAddress[2],WHITE_ON_CYAN);
         sprintf( Buffer, "(%ld)", PrimeServerHandle);
         mxyputs((unsigned char)(46),  21, Buffer, WHITE_ON_CYAN);
         }
      else
         if(++choice > 100)
            {
            choice = 0;
            ServerStatus();
            if(rpc_on)
               {
               ++NextNumber;
               if((NextNumber - 1) / 2 * 2 == NextNumber - 1)
                  ++NextNumber;
               RemoteComputer();
               mxyputc((unsigned char)10, (unsigned char)21, (char)32, 65,
                  FOREGROUND_CYAN|FOREGROUND_INTENSITY|BACKGROUND_CYAN);
               mxyputs((unsigned char)15, (unsigned char)21,
                  "Prime number server is .", WHITE_ON_CYAN);
               mxyputs((unsigned char)15, (unsigned char)46,
                  &pszNetworkAddress[2],WHITE_ON_CYAN);
               sprintf(Buffer, "(%ld)", PrimeServerHandle);
               mxyputs((unsigned char)(46),  21, Buffer, WHITE_ON_CYAN);
               }
            }
         else
            {
            if(strlen(pszNetworkAddress) < 3)
               mxyputs((unsigned char)15, (unsigned char)21,
                  "Prime number server is off-line.  Please restart it.",
                   WHITE_ON_CYAN|VID_BLINK);
            else
               {
               mxyputs((unsigned char)10, (unsigned char)21,
                  "Prime number server ",WHITE_ON_CYAN|VID_BLINK);
               strcpy(Buffer,&pszNetworkAddress[2]);
               Buffer[10] = 0;
               mxyputs((unsigned char)30, (unsigned char)21,
               strupr(Buffer),WHITE_ON_CYAN|VID_BLINK);
               mxyputs((unsigned char)(30+strlen(Buffer)), (unsigned char)21,
                  " is off-line.  Please restart it.",
                  WHITE_ON_CYAN|VID_BLINK);
               }
            }

         if(kbhit())
            if(ESC == keyboard())
               {
               NotifyServer();
               clearscreen(0);
               exit(0);
               }
         }
   }

void LocalComputer(void)
   {
   while(NextNumber <= ULONG_MAX)
      {
      if(kbhit())
         if(ESC == keyboard())
            {
            NotifyServer();
            clearscreen(0);
            exit(0);
            }

      _settextwindow(5, 5, 18, 23);

      _settextcolor(1);
      _settextposition(14, 19);
      _outtext(" ");

      _settextcolor(LWHITE);

      sprintf(Buffer, "%ld", NextNumber - 1);
      _settextposition(14, 2);
      _setbkcolor(1);
      _outtext(Buffer);
      _settextposition(14, 13);
      _settextcolor(LWHITE);

      _outtext("LOCAL");

      if(IsPrime(NextNumber - 1) != 0)
         {
         _settextposition(14, 18);
         _settextcolor(LRED);
         _outtext("*");

         _settextwindow(5, 32, 18, 50);

         _settextcolor(1);
         _settextposition(14, 19);
         _outtext(" ");

         _setbkcolor(1);

         sprintf(Buffer, "%ld", NextNumber - 1);
         _settextcolor(LWHITE);
         _settextposition(14, 2);
         _outtext(Buffer);
         _settextposition(14, 13);
         _outtext("LOCAL ");

         NoPrimeLocal++;
         }
      statistics();
      return;
      }

   clearscreen(0);
   }

/* Test for prime numbers on the local computer */

unsigned char IsPrime(unsigned long TestNumber)
   {
   unsigned long count;
   unsigned long HalfNumber = TestNumber / 2 + 1;

   for(count = 2; count < HalfNumber; count++)
      if(TestNumber % count == 0)
         return NOT_PRIME;

   return PRIME;
   }

/* Allow the user to override settings with command line switches */

void Usage(void)
   {
   printf("\nSimple prime number example.\n\n");
   printf("Usage: PRIME4\n");
   printf(" -p protocol_sequence\n");
   printf(" -n network_address\n");
   printf(" -e endpoint\n");
   printf(" -o options\n");
   printf(" -u uuid\n");
   printf(" -f first number\n");
   printf(" -c Local Computer Name (Default: MSDOS)\n");
   printf(" -r 1 don't compute locally when the server is on\n");
   exit(SUCCESS_EXIT);
   }

void InitializeApplication(void)
   {
   set_vid_mem();

   _clearscreen(_GCLEARSCREEN);
   _settextwindow(1, 1, 25, 80);
   _setbkcolor(3);
   _clearscreen(_GWINDOW);
   _settextwindow(5, 5, 18, 23);

   _setbkcolor(1);

   _clearscreen(_GWINDOW);

   _settextwindow(5, 32, 18, 50);
   _setbkcolor(1);

   _clearscreen(_GWINDOW);

   StartTime = clock();
   box(0, 0, 79, 24, DOUBLE);
   mxyputs(37, 0, " PRIME4 ", WHITE_ON_CYAN);

   mxyputs(3, 2, "Testing...", WHITE_ON_CYAN);
   box(3, 3, 23, 18, SINGLE);

   mxyputs(30, 2, "Prime!", WHITE_ON_CYAN);
   box(30, 3, 50, 18, SINGLE);

   box(59, 3, 72, 6, SINGLE);

   sprintf(Buffer,"First= %lu",StartNumber);
   mxyputs(59, 9, Buffer, WHITE_ON_CYAN);
   sprintf(Buffer,": (%s)",computer_name_buffer);
   mxyputs(45, 0, Buffer, WHITE_ON_CYAN);

   mxyputs(32, 23, "Press Esc to exit", WHITE_ON_CYAN);
   }

void RemoteComputer(void)
   {
   char Buffer[STRING_LENGTH];
   int loop;

   while(1)
      {
      if(kbhit())
         if(ESC == keyboard())
            {
            NotifyServer();
            clearscreen(0);
            exit(0);
            }
      if(NextNumber >= ULONG_MAX)
         break;
      sprintf(Buffer, "%ld", NextNumber - 1);
      _settextwindow(5, 5, 18, 23);

      _settextcolor(1);
      _settextposition(14, 19);
      _outtext(" ");

      _settextcolor(LWHITE);
      _settextposition(14, 2);
      _outtext(Buffer);
      _settextposition(14, 13);
      _settextcolor(LRED);
      _outtext("REMOTE");

      RpcTryExcept
         {
         if(RemoteIsPrime(PrimeServerHandle, NextNumber - 1) != 0)
            {
            _settextwindow(5, 32, 18, 50);

            _settextcolor(1);
            _settextposition(14, 19);
            _outtext(" ");

            sprintf(Buffer, "%ld", NextNumber - 1);

            _settextcolor(LWHITE);

            _settextposition(14, 2);
            _outtext(Buffer);
            _settextposition(14, 13);

            _settextcolor(LRED);
            _outtext("REMOTE");

            NoPrimeRemote++;
            }

         statistics();
         }
      RpcExcept(1)
         {
         /* if exceptions occur */

         rpc_on = FALSE;
         return;

         }
      RpcEndExcept
      return;
      }
   }

void statistics(void)
   {
   char Buffer[STRING_LENGTH];

   CurrTime = (clock() - StartTime) / CLK_TCK;
   sprintf(Buffer, "Primes = %d", NoPrimeLocal + NoPrimeRemote);
   mxyputs(59, (unsigned char)(7), Buffer, WHITE_ON_CYAN);
   sprintf(Buffer, "Time = %ld.%02d min.", CurrTime/60, CurrTime%60);

   mxyputs(59, (unsigned char)(8), Buffer, WHITE_ON_CYAN);
   sprintf(Buffer, "%s:%5d", "LOCAL ", NoPrimeLocal);
   mxyputs((unsigned char)(60), (unsigned char)(4), Buffer, WHITE_ON_BLUE);
   sprintf(Buffer, "%s:%5d", "REMOTE", NoPrimeRemote);
   mxyputs((unsigned char)(60), (unsigned char)(5), Buffer, RED_ON_BLUE);
   }

/* Let the Server know that we are about to exit */

void NotifyServer(void)
   {
   RpcTryExcept
      {
      TerminatePrimeServer(PrimeServerHandle);
      }
   RpcExcept(1)
      {
      return;
      }
   RpcEndExcept
   }

/* Check the Server status if it is off line, then try to connect to it,
   returns Server status */

char ServerStatus(void)
   {
   char value = FALSE;

   RpcTryExcept
      {
      PrimeServerHandle = InitializePrimeServer(&phContext,
         computer_name_buffer);
      }
   RpcExcept(1)
      {
      value = TRUE;
      }
   RpcEndExcept
   rpc_on = !value;
   return value;
   }

void __RPC_FAR *__RPC_API MIDL_user_allocate(size_t len)
   {
   return(malloc(len));
   }

void __RPC_API MIDL_user_free(void __RPC_FAR *ptr)
   {
   free(ptr);
   }

