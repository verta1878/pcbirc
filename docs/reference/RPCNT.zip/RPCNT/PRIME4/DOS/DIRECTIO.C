/****************************************************************************\
*                                                                            *
* Listing 8-13                                                               *
*                                                                            *
* DIRECTIO.C Direct screen access functions for MS-DOS                       *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
\****************************************************************************/

#include <DOS.H>
#include <BIOS.H>
#include <GRAPH.H>
#include "directio.h"

#define MK_FP(seg,ofs) ((void far *) \
        (((unsigned long)(seg) << 16) | (unsigned)(ofs)))

static char far *vid_mem_one, far *vid_mem_two;

void set_vid_mem(void)
   {
   union REGS r;
   int vmode;

   r.h.ah = 15;
   vmode = int86(0x10, &r, &r) & 255;

   if(vmode == 7)
      {
      vid_mem_one = (char*)MK_FP(0xB000,0000);
      vid_mem_two = (char*)MK_FP(0xB800,0000);
      }
   else
      {
      vid_mem_two = (char*)MK_FP(0xB000,0000);
      vid_mem_one = (char*)MK_FP(0xB800,0000);
      }
   }

void mxyputs(unsigned char x, unsigned char y, char far *str,
   unsigned char attr)
   {
   while(*str)
      moutchar(x++, y, *str++, attr);
   }

void far mxyputc(unsigned char x, unsigned char y, char ch,
   unsigned char num, unsigned char attr)
   {
   unsigned char i;
   for(i = 0; i < num; i++)
      moutchar(x++, y, ch, attr);
   }

void far moutchar(unsigned char x, unsigned char y, char ch,
   unsigned char attr)
   {
   char far *v =  vid_mem_one;
   v += y * 160 + x * 2;
   *v++ = ch, *v = attr;
   }

void far box(unsigned char x1, unsigned char y1, unsigned char x2,
   unsigned char y2,char S_D)
   {
   register int i;
   char far *v, far *t;
   char chr;

   t = v = vid_mem_one;
   chr = S_D ? 186 : 179;
   for(i = y1 + 1; i < y2; i++)
      {
      v += i * 160 + x1 * 2;
      *v++ = chr;
      *v = WHITE_ON_CYAN;
      v = t;
      v += i * 160 + x2 * 2;
      *v++ = chr;
      *v = WHITE_ON_CYAN;
      v = t;
      }
   chr = S_D ? 205 : 196;
   for(i = x1 + 1; i < x2; i++)
      {
      v += y1 * 160 + i * 2;
      *v++ = chr;
      *v = WHITE_ON_CYAN;
      v = t;
      v += y2 * 160 + i * 2;
      *v++ = chr;
      *v = WHITE_ON_CYAN;
      v = t;
      }
   chr = S_D ? 201 : 218;
   moutchar(x1, y1, chr, WHITE_ON_CYAN);
   chr = S_D ? 200 : 192;
   moutchar(x1, y2, chr, WHITE_ON_CYAN);
   chr = S_D ? 187 : 191;
   moutchar(x2, y1, chr, WHITE_ON_CYAN);
   chr = S_D ? 188 : 217;
   moutchar(x2, y2, chr, WHITE_ON_CYAN);
   }

void unsg_to_str(unsigned i, char far f[], unsigned char l)
   {
   int k = l - 1, h;
   for(h = 0; h < l; h++)
      {
      f[k--] = i % 10 + 0x30;
      i /= 10;
      }
   f[l] = 0;
   }

void read_field(unsigned char x1, unsigned char x2, unsigned char y,
   char *buffer)
   {
   unsigned char col = x1, row, count;
   gotoxy(x1, y);
   for(count = x1; count <= x2; count++)
      moutchar(count, y, (char)32, VID_REVERSE);
   for(count = x1; ; count++)
      {
      buffer[count - x1] = toupper(keyboard());
      if(buffer[count - x1] == '\r')
         break;
      if(buffer[count - x1] == '\b')
         {
         count--;
         if(col != x1)
            {
            moutchar(--col, y, (char)32, VID_REVERSE);
            count--;
            }
         }
      else
         moutchar(col++, y, buffer[count - x1], VID_REVERSE);
      if(col < x1)
         col = x1;
      else
         if(col > x2 + 1)
            {
            count--;
            col = x2 + 1;
            moutchar(col, y, (char)32, VID_NORMAL);
            }
      gotoxy(col, y);
      }
   buffer[count - x1] = 0;
   }

void clear(unsigned char x1, unsigned char y1, unsigned char x2, unsigned char y2,
   unsigned char attr)
   {
   register unsigned char col, row;

   for(row = y1; row < y2; row++)
      for(col = x1; col < x2; col++)
         moutchar(col, row, (char)32, attr);
   }

void clearscreen(char attr)
   {
   clear(0, 0, 80, 25, attr);
   if(!attr)
      _setvideomode(_DEFAULTMODE);
   }

void gotoxy(unsigned char x, unsigned char y)
   {
   union REGS i;
   i.h.dh = y;    
   i.h.dl = x;
   i.h.ah = 2;
   i.h.bh = 0;
   (void)int86(16, &i, &i);                
   }

space getxy(void)
   {
   space cursor;
   union REGS i, o;
   i.h.bh = 0;
   i.h.ah = 3;
   (void)int86(16, &i, &o);
   cursor.x = o.h.dh;
   cursor.y = o.h.dl;
   return cursor;
   }

unsigned far keyboard(void)
   {
   unsigned ret_val = _bios_keybrd(_KEYBRD_READ);
   ret_val = (ret_val & 0x00ff) ? (ret_val & 0x00ff) :
      ((ret_val & 0xff00) / 0xff);

   return(ret_val);
   }

