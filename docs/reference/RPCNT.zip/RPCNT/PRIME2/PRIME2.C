/****************************************************************************\
*                                                                            *
* Listing 7-5                                                                *
*                                                                            *
* PRIME2.C - Multithreaded prime number example                              *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE PRIME2.MAK                                                *
*                                                                            *
* Usage:     PRIME2                                                          *
*                                                                            *
* Comments:  This example uses multiple threads to compute prime numbers.    *
*                                                                            *
\****************************************************************************/

#include <STDIO.H>
#include <STRING.H>
#include <STDLIB.H>
#include <STDARG.H>
#include <LIMITS.H>
#include <WINDOWS.H>
#include "directio.h"

#define PRIME           1
#define NOT_PRIME       0
#define MAX_THREADS     9

/* Coordinates for displaying numbers to be tested */

#define TESTING_X1      3
#define TESTING_Y1      3
#define TESTING_X2     23
#define TESTING_Y2     18

/* Coordinates for displaying prime numbers */

#define PRIME_X1       30
#define PRIME_Y1        3
#define PRIME_X2       50
#define PRIME_Y2       18

#define ERROR_EXIT      2
#define SUCCESS_EXIT    0
#define STRING_LENGTH 256
#define WAIT          350

#define WHITE_ON_BLUE FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_BLUE
#define WHITE_ON_CYAN FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_CYAN
#define RED_ON_BLUE   FOREGROUND_RED|FOREGROUND_INTENSITY|BACKGROUND_BLUE

unsigned char IsPrime(unsigned long TestNumber);
void thread(int count);
void Usage(void);
void InitializeApplication(void);

/* Number of threads available to the application */

int NumThreads;

CRITICAL_SECTION GlobalCriticalSection;
char HighLight[MAX_THREADS+1];
unsigned long NextNumber = 1, StartTime, CurrTime, NoPrime[MAX_THREADS+1],
   StartNumber = 1;

void main(int argc, char **argv)
   {
   DWORD  lpIDThread[MAX_THREADS];
   HANDLE hthread[MAX_THREADS];
   int count;

   /* Allow the user to override settings with command line switches */

   for(count = 1; count < argc; count++)
      {
      if((*argv[count] == '-') || (*argv[count] == '/'))
         {
         switch(tolower(*(argv[count]+1)))
            {
            case 'f': /* first number */
               NextNumber = StartNumber = atol(argv[++count]);
               break;

            case 't': /* number of threads */
               NumThreads = atoi(argv[++count]);
               if(NumThreads > MAX_THREADS)
                  NumThreads = MAX_THREADS;
               break;

            case 'h':
            case '?':
            default:
               Usage();
            }
         }
      else
         Usage();
      }

   InitializeApplication();

   InitializeCriticalSection(&GlobalCriticalSection);

   for(count = 1; count <= NumThreads; count++)
       hthread[count-1] = CreateThread(NULL, 0,
          (LPTHREAD_START_ROUTINE)thread, count, 0, &lpIDThread[count-1]);

   thread(0);

   DeleteCriticalSection(&GlobalCriticalSection);

   clearscreen(BACKGROUND_CYAN);
   }

void thread(int count)
   {
   char Buffer[STRING_LENGTH];
   unsigned long temp;
   int loop;

   SMALL_RECT psrctScrollRectTesting, psrctScrollRectPrime;
   COORD coordDestOriginTesting, coordDestOriginPrime;
   CHAR_INFO pchiFill;
   WORD Color[TESTING_X2-TESTING_X1-3], Normal[TESTING_X2-TESTING_X1-3];
   DWORD dummy;
   COORD PrimeCoord;

   psrctScrollRectTesting.Left   = TESTING_X1+1;
   psrctScrollRectTesting.Top    = TESTING_Y1+2;
   psrctScrollRectTesting.Right  = TESTING_X2-1;
   psrctScrollRectTesting.Bottom = TESTING_Y2-1;

   coordDestOriginTesting.X = TESTING_X1+1;
   coordDestOriginTesting.Y = TESTING_Y1+1;

   psrctScrollRectPrime.Left   = PRIME_X1+1;
   psrctScrollRectPrime.Top    = PRIME_Y1+2;
   psrctScrollRectPrime.Right  = PRIME_X2-1;
   psrctScrollRectPrime.Bottom = PRIME_Y2-1;

   coordDestOriginPrime.X = PRIME_X1+1;
   coordDestOriginPrime.Y = PRIME_Y1+1;

   pchiFill.Char.AsciiChar = ' ';
   pchiFill.Attributes = WHITE_ON_BLUE;

   for(loop = 0; loop < TESTING_X2 - TESTING_X1 - 3; loop++)
       Color[loop] = RED_ON_BLUE;

   for(loop = 0; loop < TESTING_X2 - TESTING_X1 - 3; loop++)
       Normal[loop] = WHITE_ON_BLUE;

   while(1)
      {
      if(VK_ESCAPE == get_character_no_wait())
         {
         EnterCriticalSection(&GlobalCriticalSection);
         Sleep(WAIT);
         clearscreen(0);
         exit(SUCCESS_EXIT);
         LeaveCriticalSection(&GlobalCriticalSection);
         }

      EnterCriticalSection(&GlobalCriticalSection);
      if((temp = ++NextNumber) >= ULONG_MAX)
          break;
      LeaveCriticalSection(&GlobalCriticalSection);

      EnterCriticalSection(&GlobalCriticalSection);
      ScrollConsoleScreenBuffer(hStdOut, &psrctScrollRectTesting, NULL,
         coordDestOriginTesting, &pchiFill);
      sprintf(Buffer, " %-17d", temp - 1);
      mxyputs((unsigned char)TESTING_X1+2, (unsigned char)(TESTING_Y2-1),
         Buffer, WHITE_ON_BLUE);
      sprintf(Buffer, "%d",  count);
      mxyputs((unsigned char)TESTING_X2-4, (unsigned char)(TESTING_Y2-1),
         Buffer, WHITE_ON_BLUE);
      for(loop = 0; loop <= NumThreads; loop++)
         HighLight[loop]++;
      HighLight[count] = 0;
      LeaveCriticalSection(&GlobalCriticalSection);

      if(IsPrime(temp - 1) != 0)
         {
         EnterCriticalSection(&GlobalCriticalSection);
         PrimeCoord.X = TESTING_X1 + 2;
         PrimeCoord.Y = TESTING_Y2 - 1 - HighLight[count];
         if(PrimeCoord.Y > TESTING_Y1)
            {
            WriteConsoleOutputAttribute(hStdOut, Color,
            TESTING_X2-TESTING_X1-3, PrimeCoord, &dummy);
            mxyputs((unsigned char)TESTING_X2-2,
               (unsigned char)(PrimeCoord.Y), "*", RED_ON_BLUE);
            }
         LeaveCriticalSection(&GlobalCriticalSection);

         PrimeCoord.X = PRIME_X1 + 2;
         PrimeCoord.Y = PRIME_Y2 - 1;

         EnterCriticalSection(&GlobalCriticalSection);
         WriteConsoleOutputAttribute(hStdOut, Normal, PRIME_X2-PRIME_X1-3,
            PrimeCoord, &dummy);
         ScrollConsoleScreenBuffer(hStdOut, &psrctScrollRectPrime, NULL,
            coordDestOriginPrime, &pchiFill);
         WriteConsoleOutputAttribute(hStdOut, Color, PRIME_X2-PRIME_X1-3,
            PrimeCoord, &dummy);
         sprintf(Buffer, "%-18d", temp - 1);
         mxyputs((unsigned char)(PRIME_X1+2), (unsigned char)PRIME_Y2-1,
            Buffer, RED_ON_BLUE);
         sprintf(Buffer, "%d", count);
         mxyputs((unsigned char)(PRIME_X2-4), (unsigned char)PRIME_Y2-1,
            Buffer, RED_ON_BLUE);
         LeaveCriticalSection(&GlobalCriticalSection);
         NoPrime[count]++;
         }
      CurrTime = (GetTickCount() - StartTime)/1000;

         {
         long unsigned TotalNoPrime;

         TotalNoPrime = 0;

         for(loop = 0; loop <= NumThreads; loop++)
            TotalNoPrime += NoPrime[loop];

         sprintf(Buffer, "Primes = %d", TotalNoPrime);
         mxyputs(60, (unsigned char)(NumThreads+5+1), Buffer, WHITE_ON_CYAN);

         sprintf(Buffer, "Time = %d.%02d min.", CurrTime/60, CurrTime%60);

         mxyputs(60, (unsigned char)(NumThreads+5+2), Buffer, WHITE_ON_CYAN);

         if(NumThreads)
            for(loop = 0;loop <= NumThreads; loop++)
               {
               sprintf(Buffer,"%d-%5d", loop,NoPrime[loop]);
               mxyputs((unsigned char)(62), (unsigned char)(loop+4),
                  Buffer, WHITE_ON_CYAN);
               }
         }
      }
   }

/* Tests for prime numbers. */

unsigned char IsPrime(unsigned long TestNumber)
   {
   unsigned long count;
   unsigned long HalfNumber = TestNumber / 2 + 1;

   for(count = 2; count < HalfNumber; count++)
       if(TestNumber % count == 0)
           return NOT_PRIME;

   return PRIME;
   }

/* Displays command line options   */

void Usage(void)
   {
   printf("\nMultithreaded prime number example.\n\n");
   printf("Usage: PRIME2\n");
   printf(" -f first number\n");
   printf(" -t number of threads (0 - 9)\n");
   exit(SUCCESS_EXIT);
   }

/* Screen initialization and colors and title lines */

void InitializeApplication(void)
   {
   char Buffer[20];

   set_vid_mem();

   clearscreen(BACKGROUND_CYAN);
   StartTime = GetTickCount();

   box(0, 0, 79, 24, DOUBLE);
   mxyputs(37, 0, " PRIME2 ", WHITE_ON_CYAN);
   sprintf(Buffer, "%d", NumThreads);

   mxyputs(3, 2, "Testing...  Thread( )", WHITE_ON_CYAN);
   mxyputs(22, 2, Buffer, WHITE_ON_CYAN);
   box(TESTING_X1, TESTING_Y1, TESTING_X2, TESTING_Y2, SINGLE);

   mxyputs(30, 2, "Prime!      Thread( )", WHITE_ON_CYAN);
   mxyputs(49, 2, Buffer, WHITE_ON_CYAN);
   box(PRIME_X1, PRIME_Y1, PRIME_X2, PRIME_Y2, SINGLE);

   if(NumThreads)
      {
      mxyputs(60, 2, "Thread/Prime", WHITE_ON_CYAN);
      box(60, 3, 70, (unsigned char)(NumThreads+5), SINGLE);
      }

   sprintf(Buffer, "First = %d", StartNumber);
   mxyputs(60, (unsigned char)(NumThreads+5+3), Buffer, WHITE_ON_CYAN);

   mxyputs(32, 23, "Press Esc to exit", WHITE_ON_CYAN);
   }

