/****************************************************************************\
*                                                                            *
* Listing 7-3                                                                *
*                                                                            *
* PRIME1.C - Prime number example                                            *
*            (c) Guy Eddon, 1993                                             *
*                                                                            *
* To build:  NMAKE PRIME1.MAK                                                *
*                                                                            *
* Usage:     PRIME1                                                          *
*                                                                            *
* Comments:  This example computes prime numbers.                            *
*                                                                            *
\****************************************************************************/

#include <STDIO.H>
#include <STRING.H>
#include <STDLIB.H>
#include <STDARG.H>
#include <LIMITS.H>
#include <WINDOWS.H>
#include "directio.h"

/* Coordinates for displaying numbers to be tested */

#define TESTING_X1     10
#define TESTING_Y1      3
#define TESTING_X2     30
#define TESTING_Y2     18

/* Coordinates for displaying prime numbers */

#define PRIME_X1       50
#define PRIME_Y1        3
#define PRIME_X2       70
#define PRIME_Y2       18


#define PRIME           1
#define NOT_PRIME       0
#define ERROR_EXIT      2
#define SUCCESS_EXIT    0
#define STRING_LENGTH 256

#define WHITE_ON_BLUE FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_BLUE
#define WHITE_ON_CYAN FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_CYAN
#define RED_ON_BLUE   FOREGROUND_RED|FOREGROUND_INTENSITY|BACKGROUND_BLUE

unsigned char IsPrime(unsigned long TestNumber);
void InitializeApplication(void);
void Usage(void);

unsigned long NextNumber = 1, StartTime, CurrTime, NoPrime, StartNumber = 1;

void main(int argc, char **argv)
   {
   int count;
   char Buffer[STRING_LENGTH];
   SMALL_RECT psrctScrollRectTesting, psrctScrollRectPrime;
   COORD coordDestOriginTesting, coordDestOriginPrime;
   CHAR_INFO pchiFill;
   WORD Color[TESTING_X2-TESTING_X1-3], Normal[TESTING_X2-TESTING_X1-3];
   DWORD dummy;
   COORD PrimeCoord;

   psrctScrollRectTesting.Left   = TESTING_X1+1;
   psrctScrollRectTesting.Top    = TESTING_Y1+2;
   psrctScrollRectTesting.Right  = TESTING_X2-1;
   psrctScrollRectTesting.Bottom = TESTING_Y2-1;

   coordDestOriginTesting.X = TESTING_X1+1;
   coordDestOriginTesting.Y = TESTING_Y1+1;

   psrctScrollRectPrime.Left   = PRIME_X1+1;
   psrctScrollRectPrime.Top    = PRIME_Y1+2;
   psrctScrollRectPrime.Right  = PRIME_X2-1;
   psrctScrollRectPrime.Bottom = PRIME_Y2-1;

   coordDestOriginPrime.X = PRIME_X1+1;
   coordDestOriginPrime.Y = PRIME_Y1+1;

   /* Allow the user to override settings with command line switches */

   for(count = 1; count < argc; count++)
      {
      if((*argv[count] == '-') || (*argv[count] == '/'))
         {
         switch(tolower(*(argv[count]+1)))
            {
            case 'f': /* first number */
               NextNumber = StartNumber = atol(argv[++count]);
               break;

            case 'h':
            case '?':
            default:
               Usage();
            }
         }
      else
         Usage();
      }

   InitializeApplication();

   pchiFill.Char.AsciiChar = (char)32;
   pchiFill.Attributes =  RED_ON_BLUE;

   for(count = 0; count < TESTING_X2-TESTING_X1-3; count++)
       Color[count] = RED_ON_BLUE;

   for(count = 0; count < TESTING_X2-TESTING_X1-3; count++)
       Normal[count] = WHITE_ON_BLUE;

   while(NextNumber <= ULONG_MAX)
      {
      if(VK_ESCAPE == get_character_no_wait())
          break;

      NextNumber++;

      ScrollConsoleScreenBuffer(hStdOut, &psrctScrollRectTesting, NULL,
         coordDestOriginTesting, &pchiFill);
      sprintf(Buffer, " %-18d", NextNumber - 1);
      mxyputs((unsigned char)TESTING_X1+1, (unsigned char)TESTING_Y2-1,
         Buffer, WHITE_ON_BLUE);

      if(IsPrime(NextNumber - 1) != 0)
         {
         PrimeCoord.X = TESTING_X1 + 2;
         PrimeCoord.Y = TESTING_Y2 - 1;

         WriteConsoleOutputAttribute(hStdOut, Color, 
            TESTING_X2-TESTING_X1-3, PrimeCoord, &dummy);
         mxyputs((unsigned char)TESTING_X2-2, 
            (unsigned char)(TESTING_Y2-1), "*", RED_ON_BLUE);

         PrimeCoord.X = PRIME_X1 + 2;
         PrimeCoord.Y = PRIME_Y2 - 1;

         WriteConsoleOutputAttribute(hStdOut, Normal, PRIME_X2-PRIME_X1-3,
            PrimeCoord, &dummy);
         ScrollConsoleScreenBuffer(hStdOut, &psrctScrollRectPrime, NULL,
            coordDestOriginPrime, &pchiFill);
         WriteConsoleOutputAttribute(hStdOut, Color, PRIME_X2-PRIME_X1-3,
            PrimeCoord, &dummy);

         sprintf(Buffer, " %-18d", NextNumber - 1);
         mxyputs((unsigned char)(PRIME_X1+1), (unsigned char)PRIME_Y2-1,
            Buffer, RED_ON_BLUE);
         NoPrime++;
         }

      CurrTime = (GetTickCount() - StartTime)/1000;
      sprintf(Buffer,"Time = %d.%02d min.  Primes = %d   (Start= %d)",
         CurrTime/60, CurrTime%60, NoPrime, StartNumber);
      mxyputs(27, 20, Buffer, WHITE_ON_CYAN);
      }

   clearscreen(0);
   }

/* Tests for prime numbers */

unsigned char IsPrime(unsigned long TestNumber)
   {
   unsigned long count;
   unsigned long HalfNumber = TestNumber / 2 + 1;

   for(count = 2; count < HalfNumber; count++)
       if(TestNumber % count == 0)
           return NOT_PRIME;

   return PRIME;
   }

/* Displays command line options */

void Usage(void)
   {
   printf("\nSimple prime number example.\n\n");
   printf("Usage: PRIME1\n");
   printf(" -f first number\n");
   exit(SUCCESS_EXIT);
   }

/* Screen initialization and colors and title lines */

void InitializeApplication(void)
   {
   set_vid_mem();

   clearscreen(BACKGROUND_CYAN);
   StartTime = GetTickCount();
   box(0, 0, 79, 24,DOUBLE);
   mxyputs(37, 0, " PRIME1 ", WHITE_ON_CYAN);

   mxyputs(10, 2, "Testing...", WHITE_ON_CYAN);
   box(TESTING_X1, TESTING_Y1, TESTING_X2, TESTING_Y2,SINGLE);

   mxyputs(50, 2, "Prime!", WHITE_ON_CYAN);
   box(PRIME_X1, PRIME_Y1, PRIME_X2, PRIME_Y2,SINGLE);

   mxyputs(32, 23, "Press Esc to exit", WHITE_ON_CYAN);
   }

