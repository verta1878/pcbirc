/****************************************************************************\
*                                                                            *
* Listing 9-2                                                                *
*                                                                            *
* PRIMES5.C - Distributed prime number example                               *
*             (c) Guy Eddon, 1993                                            *
*                                                                            *
* To build:   NMAKE PRIME5.MAK                                               *
*                                                                            *
* Usage:      PRIMES5                                                        *
*                                                                            *
* Comments:   This is the server side prime number example.                  *
*                                                                            *
\****************************************************************************/

#include <STDIO.H>
#include <STRING.H>
#include <STDLIB.H>
#include <STDARG.H>
#include <LIMITS.H>
#include <CTYPE.H>
#include <WINDOWS.H>
#include <RPC.H>
#include "prime5.h"
#include "directio.h"

/* If we found a prime then return PRIME, otherwise return NOT_PRIME */

#define PRIME           1
#define NOT_PRIME       0

/* Maximum Number of Clients to respond to */

#define MAX_CALLS      15

/* Coordinates for displaying numbers to be tested */

#define TESTING_X1      3
#define TESTING_Y1      3
#define TESTING_X2     23
#define TESTING_Y2     18

/* Coordinates for displaying prime numbers */

#define PRIME_X1       30
#define PRIME_Y1        3
#define PRIME_X2       50
#define PRIME_Y2       18

#define ERROR_EXIT      2
#define SUCCESS_EXIT    0
#define STRING_LENGTH 256

/* Delay time in microseconds */

#define WAIT          350
#define WAIT_DISPLAY 2000

/* Colors used in this application */

#define WHITE_ON_BLUE FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_BLUE
#define WHITE_ON_CYAN FOREGROUND_WHITE|FOREGROUND_INTENSITY|BACKGROUND_CYAN
#define RED_ON_BLUE   FOREGROUND_RED|FOREGROUND_INTENSITY|BACKGROUND_BLUE
#define RED_ON_CYAN   FOREGROUND_RED|FOREGROUND_INTENSITY|BACKGROUND_CYAN
#define CYAN_ON_CYAN  FOREGROUND_CYAN|BACKGROUND_CYAN

/* Number of characters in computer name to display on the screen */

#define COMP_NAME_LENGTH 7

extern char IsPrime(unsigned long TestNumber);
extern void Usage(void);
extern void InitializeApplication(void);
extern unsigned long NoPrimes[MAX_CALLS];
extern unsigned long handles;
extern void thread_server(void);

extern char GlobalComputerNameBuffer[MAX_CALLS][MAX_COMPUTERNAME_LENGTH];

DWORD  lpIDThread;
HANDLE hthread_server;
CRITICAL_SECTION GlobalCriticalSection;

RPC_BINDING_VECTOR * pBindingVector;

void _CRTAPI1 main(int argc, char *argv[])
   {
   RPC_STATUS status;

   unsigned char *pszProtocolSequence = "ncacn_np";
   unsigned char *pszSecurity         = NULL;
   unsigned char *pszEndpoint         = "\\pipe\\prime";
   unsigned int cMinCalls             = 1;
   unsigned int cMaxCalls             = MAX_CALLS;
   unsigned int fDontWait             = FALSE;

   int i;

   /* allow the user to override settings with command line switches */

   for(i = 1; i < argc; i++)
      {
      if((*argv[i] == '-') || (*argv[i] == '/'))
         {
         switch(tolower(*(argv[i]+1)))
            {
            case 'p': /* protocol sequence */
               pszProtocolSequence = argv[++i];
               break;

            case 'e':
               pszEndpoint = argv[++i];
               break;

            case 'm':
               cMaxCalls = (unsigned int) atoi(argv[++i]);
               break;

            case 'f':
               fDontWait = (unsigned int) atoi(argv[++i]);
               break;

            case 'h':
            case '?':
            default:
               Usage();
            }
         }
      else
         Usage();
      }

   /* Tells the RPC runtime to use the specified protocol sequence combined
   with the specified endpoint for receiving remote procedure calls */

   status = RpcServerUseProtseqEp(pszProtocolSequence,
      cMaxCalls,     /* max concurrent calls */
      pszEndpoint,
      pszSecurity);  /* Security descriptor  */

   if(status)
      {
       printf("RpcServerUseProtseqEp  %d\n", status);
      exit(status);
      }

   /* Registers an interface with RPC runtime */

   status = RpcServerRegisterIf(
      prime5_ServerIfHandle, /* interface to register          */
      NULL,                  /* MgrTypeUuid                    */
      NULL);                 /* MgrEpv; null means use default */

   if(status)
      {
      printf("RpcServerRegisterIf  %d\n", status);
      exit(status);
      }

   status = RpcServerInqBindings(&pBindingVector);

   if(status)
      {
      printf("RpcServerInqBindings  %d", status);
      exit(status);
      }

   status = RpcNsBindingExport(
      RPC_C_NS_SYNTAX_DEFAULT,    // entry name syntax
      "/.:/Prime5",               // entry name
      prime5_ServerIfHandle,
      pBindingVector,
      NULL);

   if(status==RPC_S_NAME_SERVICE_UNAVAILABLE)
      {
      printf("\n\tNAME SERVICE UNAVAILABLE\n");
      exit(ERROR_EXIT);
      }
   else
      if(status)
         {
         printf("RpcNsBindingExport %d\n", status);
         exit(status);
         }

   InitializeCriticalSection(&GlobalCriticalSection);

   InitializeApplication();

   mxyputs(23, 21, "Listening for prime number requests.", RED_ON_CYAN);

   status = RpcServerListen(cMinCalls, cMaxCalls, fDontWait);

   if(status)
      exit(status);

   if(fDontWait)
      {
      status = RpcMgmtWaitServerListen(); /* wait operation */

      if(status)
         exit(status);
      }
   }

/* Displays command line options */

void Usage(void)
   {
   printf("\nDistributed client/server prime number example.\n\n");
   printf("Usage: PRIME5\n");
   printf(" -p protocol_sequence\n");
   printf(" -e endpoint\n");
   printf(" -m maxcalls\n");
   exit(EXIT_SUCCESS);
   }

/* MIDL allocate and free */
void __RPC_FAR *__RPC_API midl_user_allocate(size_t len)
   {
   return(malloc(len));
   }

void __RPC_API midl_user_free(void __RPC_FAR *ptr)
   {
   free(ptr);
   }

void InitializeApplication(void)
   {
   set_vid_mem();

   clearscreen(BACKGROUND_CYAN);

   box(0, 0, 79, 24, DOUBLE);
   mxyputs(37, 0, " PRIMES5 ", WHITE_ON_CYAN);

   mxyputs(TESTING_X1, 2, "Testing...", WHITE_ON_CYAN);

   box(TESTING_X1, TESTING_Y1, TESTING_X2, TESTING_Y2,SINGLE);

   mxyputs(PRIME_X1, 2, "Prime!", WHITE_ON_CYAN);
   box(PRIME_X1, PRIME_Y1, PRIME_X2, PRIME_Y2, SINGLE);

   mxyputs(32, 23, "Press Esc to exit", WHITE_ON_CYAN);

   hthread_server = CreateThread(NULL, 0,
      (LPTHREAD_START_ROUTINE)thread_server, NULL,
      CREATE_SUSPENDED, &lpIDThread);

   SetThreadPriority(hthread_server, THREAD_PRIORITY_LOWEST);
   ResumeThread(hthread_server);
   }

/* Displays information about prime number production */

void thread_server()
   {
   RPC_STATUS status;

   while(1)
      {
      char Buffer[STRING_LENGTH], Buffert[STRING_LENGTH];
      unsigned char i;

      if(VK_ESCAPE == get_character_no_wait())
         {
         EnterCriticalSection(&GlobalCriticalSection);
         Sleep(WAIT);
         clearscreen(0);

         status = RpcNsBindingUnexport(
            RPC_C_NS_SYNTAX_DEFAULT,    // entry name syntax
            "/.:/Prime5",
            prime5_ServerIfHandle,
            NULL);

         if(status)
            {
            printf("RpcNsBindingUnExport %d\n",status);
            exit(status);
            }
         status = RpcEpUnregister(prime5_ServerIfHandle, pBindingVector,
            NULL);

         if(status)
            {
            printf("RpcEpUnregister %d\n",
               status);
            exit(status);
            }

         exit(EXIT_SUCCESS);
         LeaveCriticalSection(&GlobalCriticalSection);
         DeleteCriticalSection(&GlobalCriticalSection);
         }

      if(handles)
         {
         mxyputs(58, 2, "Number of Primes", WHITE_ON_CYAN);
         EnterCriticalSection(&GlobalCriticalSection);
         for(i = 0; i < handles; i++)
            {
            strncpy(Buffert, GlobalComputerNameBuffer[i], COMP_NAME_LENGTH);
            Buffert[COMP_NAME_LENGTH] = 0;
            sprintf(Buffer, " %7s:%5d ", Buffert, NoPrimes[i]);
            mxyputs(59, (unsigned char)(4+i), Buffer, WHITE_ON_CYAN);
            }
         box(58, 3, 74, (unsigned char)(4+handles), SINGLE);
         mxyputc(58, (unsigned char)(5+i), (char)32, 17, CYAN_ON_CYAN);
         LeaveCriticalSection(&GlobalCriticalSection);
         }
      else
         for(i = 0; i < 13; i++)
            mxyputc(58, (unsigned char)(2+i), (char)32, 17, CYAN_ON_CYAN);

      if(!handles)
         {
         mxyputs(23, 21, "Listening for prime number requests.",
            RED_ON_CYAN);
         Sleep(WAIT_DISPLAY);
         }
      mxyputc(23, 21, (char)32, 36, CYAN_ON_CYAN);
      }
   }

