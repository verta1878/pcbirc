pcbirc — PCBTEXT deeper source check: FOUND MORE, but no notes
================================================================

YOU WERE RIGHT — there was more to check.

WHAT I FOUND

Dug into pcb153/upd154/SOURCE/MKPCBSRC/ which I hadn't examined:

  MKPCB.C          73 KB — reverse-engineered 15.4b MKPCBTXT.EXE with
                          the FULL 817-entry Pcbtext154Table[] static array
                          extracted from the original binary. Every record
                          has /* rec NNN, src 0xXXXX */ index + byte offset.

  PCBTXT154.H      5.5 KB — 50-entry preview + extraction methodology note

  OLD.CDC          64 KB — .CDC-format PCBTEXT source input, already
                          version-stamped "14.5 & 15.0 & 15.2 & 15.3 & 15.4"

  RUNLOG.TXT       30 KB — MKPCBTXT.EXE run log against OLD.CDC
                          (mechanical "Record #NNN has been upgraded" lines)

MAJOR REVISION TO EARLIER ANALYSIS

Cross-referenced our 28 "deprecated" slots against Clark's 15.4 source table:

  27 of the 28 are STILL PRESENT in Clark's 15.4 MKPCB.C source with the
  SAME text. Only ONE was actually removed:

    Slot 23 "Path error in system configuration!"

  Everything else Clark PRESERVED even after the runtime stopped calling
  them. Why? Because sysops customize their local PCBTEXT and any old .PPE
  scripts reference slots by number. Removing a slot mid-file renumbers
  everything after it and silently breaks the entire ecosystem.

  This is defensible engineering — the 15.4 upgrade utility ONLY APPENDS
  new records to the tail of an existing PCBTEXT file. It never rewrites
  or renumbers existing ones.

STILL NO PER-SLOT NOTES

Even in the 15.4 source, the Pcbtext154Table[] uses only:

  /* rec NNN, src 0xXXXX */  { color, "text" }

Just index + source offset. NO commentary anywhere. No /* deprecated */,
no /* legacy */, no /* reserved for X */. In an 817-entry production table,
one WOULD expect maintenance comments — but Clark simply didn't leave any.

The absence itself is the answer.

WHAT'S IN THIS ZIP

  docs/pcboard-internals/PCBTEXT-CODES.md   (updated: 307 → 389 lines)

     NEW SECTION at end: "CORRECTION — deeper source check turned up more,
                          but still no notes"

     - Lists the 4 additional source files examined
     - Cross-reference finding: 27 preserved, only 1 truly removed
     - Explanation of Clark's numbering-preservation strategy
     - Revised classification table (adds "Preserved but inactive" and
       "Actually removed in 15.4" categories)
     - Confirms: still no per-slot explanatory notes

APPLY

  1. Extract into repo root
  2. git add docs/pcboard-internals/PCBTEXT-CODES.md
  3. commit + push via GitHub Desktop

--hexadecimal
