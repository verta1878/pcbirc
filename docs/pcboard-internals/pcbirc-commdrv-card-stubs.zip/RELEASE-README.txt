pcbirc — COMMDRV/pcbdcom multiport card stubs analysis
=========================================================

You were right: decompiling COMMDRV.EXE + DRVSETUP.EXE + the 9 COMMDV*.DRV
backends reveals 3 planned-but-never-shipped card types plus a hidden
Windows VxD backend and 3 TSR-only sub-variants.

HEADLINE FINDINGS

1. 9 backend modules ship, 3 UI stubs never shipped.
2. TSR knows 3 additional cards the UI doesn't expose.
3. A 9th backend is a hidden Windows 95 VxD (COMMDV08.DRV).

THE 9 SHIPPED BACKENDS

  COMMDV00.DRV  GENERIC 1.01     — UART (8250/16450/16550)
  COMMDV01.DRV  HUB6 1.00        — HUB-6 multiport
  COMMDV02.DRV  DIGI-COMXI 1.00  — DigiBoard COM/Xi (EISA/MCA)
  COMMDV03.DRV  ARNET-SPORT 1.00 — Arnet SmartPort
  COMMDV04.DRV  BOCA(1610) 1.00  — Boca BB1610/BB2016
  COMMDV05.DRV  (DIGI-PCX*)      — DigiBoard PC/Xe/Xi/8i (needs XABIOS+XACOOK firmware)
  COMMDV06.DRV  (GTEK)           — GTEK BBS-8/16
  COMMDV07.DRV  INT14H 1.00      — INT 14h software gateway
  COMMDV08.DRV  COMMDRV VxD 1.00 — Windows 95 VxD (hidden — no UI)

THE 3 UI STUBS (planned, never shipped)

DRVSETUP.EXE's menu offers these three cards but there is NO backend,
NO firmware, NO sample config, NO TSR runtime dispatch:

  AST         AST 4-port serial family
  BOCA-DMB    Boca "Dual Mode Board"
  PC-COM      PC-COM 8-port serial

Selecting them from the UI would fail at driver load time.

THE 3 TSR-ONLY VARIANTS (implemented, UI collapses them)

COMMTSR.EXE's runtime knows these but DRVSETUP.EXE collapses them under
their parent choices:

  ARNETSPLUS  — Arnet SmartPort "Plus" (UI shows just ARNET)
  DIGIPCXE    — DigiBoard PC/Xe (UI shows just PC/XI)
  DIGI2PORT   — DigiBoard 2-port (UI shows just PC/XI)

To use them you'd hand-edit the generated config file.

FIRMWARE INVENTORY

  XABIOS.BIN   2,048 B  DigiBoard PC/Xe/Xi/8i BIOS
  XACOOK.BIN   6,144 B  DigiBoard PC/Xe FEP "cook"
  XACOMX.BIN   6,144 B  DigiBoard COM/Xi firmware
  BOCA1610.BIN 3,228 B  Boca BB1610 IUART firmware

No firmware for AST, BOCA-DMB, PC-COM (confirms unimplemented).
No firmware for GTEK (dumb 16550-based cards need none).

WHAT'S IN THIS ZIP

  docs/pcboard-internals/PCBDCOM-CARDS.md   NEW — 155 lines
       Full inventory: 9 backends, 3 UI stubs, 3 TSR-only variants,
       firmware, sample configs, Windows VxD path.

  docs/pcboard-internals/PLANNED-FEATURES.md   updated — 1 line
       Category summary now includes "COMMDRV card types | — | 3"

  docs/pcboard-internals/MCI-CODES.md          updated — 1 line
       "See also" links to PCBDCOM-CARDS.md

APPLY

  1. Extract into repo root
  2. git add docs/pcboard-internals/*.md
  3. commit + push via GitHub Desktop

DISK NOTE

You mentioned "reference digit board cards disks 1-3 i dont think disk 4."
Confirmed — everything COMMDRV-related is on disks 1-3:
  Disk 1 (COMMDRV.RED)      : the 9 backend DRVs, EXEs, firmware, samples
  Disk 2 (PCBDISK.002)      : WHATSNEW.151 narrative mentions ARNET+DIGI
                              for OS/2 driver support
  Disk 3 (PCBDISK.003+PCBCFGS): no card refs
  Disk 4 (PCBOARD2.RED)     : OS/2 tree — none of the multiport code

--hexadecimal
