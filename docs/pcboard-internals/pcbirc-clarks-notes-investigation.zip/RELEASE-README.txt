pcbirc — PCBTEXT screen codes: full source investigation
=========================================================

QUESTION ANSWERED: "clark as them as stub the missing codes. he wrote notes about them??"

SHORT ANSWER

No. Clark did NOT write explanatory notes about the 28 deprecated stub
slots. His "notes" are STRUCTURAL SIGNALS only — the absence of a #define
in PCBTEXT.H and a 0 bit in UseText[] in PCBTEXT.C. Nothing textual.

FULL INVESTIGATION

Checked THREE authoritative source files across pcb153, pcb154, and reference:

1. pcb154/MAIN/SOURCE/H/PCBTEXT.H
   — 722 #define TXT_XXX entries
   — Deprecated slots have NO #define. Just a gap between adjacent numbers
     (e.g. after #19 the next is #21, no #20 line). No comment marks the gap.

2. pcb154/MAIN/SOURCE/DISPLAY/PCBTEXT.C
   — Contains the UseText[] bitflag array
   — Each 0 tells runtime "skip this slot"
   — Position markers /* 20 */, /* 30 */ only. No per-zero annotation.
   — BONUS FIND: right after UseText[], a big COMMENTED-OUT switch statement
     shows Clark's abandoned "safety net" — hardcoded English fallbacks for
     8 named prompts. Left as a comment rather than deleted.

3. reference/pcball/pcboard/pcb-util/PCBTEXT/STRS15.C
   — THE authoritative string source (759 lines, all 747 records)
   — Rich per-record metadata: {flag, alignment, length, color, "text"}
   — Deprecated slots keep their text intact so MKPCBTXT can regenerate
     the binary preserving them
   — Only 3 comment blocks in the WHOLE FILE: header, compile note, log
     length note. Nothing per-slot.

ONE INTERESTING NOTE FOUND

pcb154/MAIN/SOURCE/H/PCBTEXT.H has a stray freeform comment (with a
double-/* merge artifact) about the NEW slots 747-750:

    /*
    /*
    /* 15.4 additions — prompts for Personal PSA fields and color selection.
     * Values match STRS15.C (extracted from 15.4b MKPCBTXT.EXE binary).
     * Slots 747-750 are the next unused after the 15.3 baseline of 746.
     */

This is the ONE place in the entire PCBTEXT source tree where someone
wrote a substantive note — and it's about the 4 NEW slots, not the 28 old
ones.

WHAT'S IN THIS ZIP

  docs/pcboard-internals/PCBTEXT-CODES.md   (updated: 146 → 241 lines)
      NEW section: "Did Clark write notes about the 28 stub slots?"
      Full source investigation across 3 files.
      Table of all 28 deprecated slots with INFERRED reasons for
      deprecation (ours, not Clark's — the source has no annotations).
      Documents the abandoned switch-statement fossil in PCBTEXT.C.
      Documents the stray note about 15.4 additions.

  docs/pcboard-internals/MCI-CODES.md       (unchanged — cross-link already added)

APPLY

  1. Extract into repo root
  2. git add docs/pcboard-internals/PCBTEXT-CODES.md
  3. commit + push via GitHub Desktop

--hexadecimal
