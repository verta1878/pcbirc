# PCBoard Screen Prompts (PCBTEXT) — Complete Analysis

**Scope**: full inventory of the 747 prompt slots in `PCBTEXT` — the binary
file that holds every screen message, prompt, and error string PCBoard 15.3 /
15.41 displays. Cross-referenced against Clark's SDK headers, source code,
and the shipped binary in `pcb1541/install/dist/target/GEN/PCBTEXT`.

**Sources analyzed**:
- `pcb153/SOURCE/H/pcbtext.h` — 15.3 SDK header (718 named)
- `pcb153/upd154/SOURCE/H/pcbtext.h` — 15.41 SDK header (722 named)
- `pcb154/MAIN/SOURCE/H/PCBTEXT.H` — 15.41 MAIN branch header (722 named)
- `pcb154/MAIN/SOURCE/DISPLAY/PCBTEXT.C` — runtime dispatcher + `UseText[]` bitflags
- `pcb153/SOURCE/DISPLAY/PCBTEXT.C` — 15.3 runtime (identical layout)
- `pcb1541/install/dist/target/GEN/PCBTEXT` — shipped binary (747 records × 80 bytes)

## Headline findings

1. **747 slots. All 747 have text.** No empty records. Format: 80-byte fixed
   records, byte 0 is the color code (`0`-`8`), bytes 1-79 are space-padded text.

2. **Header + 716 active + 2 deprecated + 28 reserved = 747.** Every slot
   accounted for:
   - Slot 0: version string header (`"PCBoard version 14.5 & 15.0 & 15.2 & 15.3 PCBTEXT file"`)
   - 716 slots: named in `PCBTEXT.H` + marked "used" by `UseText[]==1` — actively displayed
   - 2 slots: named + `UseText[]==0` — legacy code path, name kept for source compat (#108 `TXT_USERSFILEPACKED`, #184 `TXT_RELOADINGPCBOARD`)
   - 28 slots: unnamed + `UseText[]==0` — pure legacy text, no code path reads them

3. **`UseText[]` is the ground truth.** The 8-bit-per-byte bitflag array in
   `PCBTEXT.C` at compile time tells the runtime whether each slot is active.
   The header (`PCBTEXT.H`) also omits names for the deprecated slots, but the
   bitflag is what actually gates whether the string is loaded.

4. **15.3 → 15.41 added 4 new prompts (#747-#750).** For gender, birthdate,
   web address, favorite color — user-registration extensions. But the shipped
   `PCBTEXT` binary is a 15.3-vintage file with 747 records (0..746), so slots
   747-750 are declared in the header but **not present** in the on-disk binary:
   - `#747` `TXT_ENTERGENDER` — declared, but PCBTEXT binary would need re-generation to include it
   - `#748` `TXT_ENTERBIRTHDATE` — declared, but PCBTEXT binary would need re-generation to include it
   - `#749` `TXT_ENTERWEBADDR` — declared, but PCBTEXT binary would need re-generation to include it
   - `#750` `TXT_ENTERCOLOR` — declared, but PCBTEXT binary would need re-generation to include it

## Classification

| Category | Count | Meaning |
|---|---:|---|
| Header | 1 | Slot 0 — version identifier |
| Active + named | 716 | Currently used by 15.3 / 15.41 |
| Deprecated + named | 2 | Name kept in header for source compat; runtime skips |
| Reserved + unnamed | 28 | Legacy text from older versions, name dropped |
| Missing from binary | 4 | New in 15.41 header, need re-generated PCBTEXT to appear |
| **Total in binary** | **747** | slots 0..746 |
| **Total in 15.41 header** | **750** | slots 1..750 |

## The 28 reserved unnamed slots (the "missing screen codes")

These are prompts Clark shipped in the binary but that neither the SDK header
nor the runtime code path uses. Third-party tools can only reference them by
numeric index — no symbolic constant exists. They're preserved for backward
compatibility with older PCBoard versions (14.5, 15.0) that displayed them.

| Slot | Color | Text |
|-----:|:-----:|:-----|
| 20 | 1 | `Printer Off-Line ...` |
| 23 | 1 | `Path error in system configuration!` |
| 44 | 1 | `Error reading Script Questionnaire` |
| 47 | 1 | `No record available to update!` |
| 48 | 6 | `Messages Successfully Packed & Purified!` |
| 81 | 2 | `Purge older than (Enter)=010180` |
| 91 | 2 | `Reference Message number purification proceeding ...` |
| 115 | 3 | `  Registered in Conferences` |
| 122 | 6 | `Enter (U) for status while awaiting other caller ...` |
| 124 | 1 | `Sorry, @FIRST@, PACK not available from remote ...` |
| 147 | 1 | `Message Base Error!  Attempting to continue ...` |
| 151 | 2 | `Checking user file - please wait ...` |
| 172 | 1 | `Unable to write USER Record - Aborting!` |
| 174 | 1 | `Number of Users Purged:` |
| 183 | 1 | `PCBPACK Security Level Fail!` |
| 201 | 1 | `Error in filename request!` |
| 202 | 6 | `Welcome back to PCBoard~` |
| 205 | 1 | `Only ASCII and Kermit Protocols supported at 7-E-1!` |
| 206 | 1 | `Number of Msgs Purged :` |
| 207 | 1 | `Number of Bytes Purged:` |
| 362 | 1 | `Thread Read Terminated ...` |
| 364 | 1 | `Message Text Search Terminated ...` |
| 391 | 1 | `SHELL Batch file Missing (` |
| 392 | 0 | `Resetting Packet ...` |
| 410 | 0 | `Hanging Up Phone ...` |
| 432 | 1 | `Sorry, @FIRST@, Insufficient Security for 'From' edit!` |
| 456 | 1 | `Pack Message Base Before Continuing!` |
| 462 | 1 | `Assign More Message BLOCKS using PCBSetup!` |

## The 2 deprecated named slots

These have names in `PCBTEXT.H` (so source code that includes the header still
compiles) but are marked `UseText[]==0` — the runtime never reads them. Kept
for source-level backward compatibility.

| Slot | Name | Color | Text |
|-----:|:-----|:-----:|:-----|
| 108 | `TXT_USERSFILEPACKED` | 7 | `User file successfully packed.` |
| 184 | `TXT_RELOADINGPCBOARD` | 7 | `Reloading PCBoard.  Please wait ...` |

## Color codes (byte 0 of each record)

| Code | Meaning | Typical use |
|:----:|:--------|:------------|
| `0` | Follow the display file's current color | Status messages, transient text |
| `1` | Bright red (errors) | Access denied, warnings, aborts |
| `2` | Bright green | Success messages, action prompts |
| `3` | Bright yellow | Configuration prompts |
| `4` | Bright blue | Rarely used |
| `5` | Bright magenta | Rarely used |
| `6` | Bright cyan | Info, welcome messages |
| `7` | Bright white | Prompts, questions |
| `8` | Bright dark grey | Rarely used |

Colors are DOS-style — foreground on background=0. The runtime combines with
the current display file's color state per the `PCBTEXT.C` dispatch logic.

## Record format

```
typedef struct {
  char Color;       // "0".."8" — foreground color code
  char Str[80];     // Prompt text, space-padded to 80 bytes (79 usable)
} pcbtexttype;
```

The struct is `#pragma pack(1)` so each record is exactly 81 bytes on disk?
No — the on-disk format is 80 bytes total: byte 0 is Color, bytes 1..79 are
text (79 chars max, space-padded). The `Str[80]` in the struct includes byte
index 0 through 79 giving 80 chars, but the on-disk layout uses 80 bytes total
with byte 0 as the color prefix. The C struct is a load-time interpretation.

## Provenance

- **Ground truth**: `pcb154/MAIN/SOURCE/DISPLAY/PCBTEXT.C` `UseText[]` bitflags
- **Name authority**: `pcb154/MAIN/SOURCE/H/PCBTEXT.H` — 722 `#define TXT_*` entries
- **Binary**: `pcb1541/install/dist/target/GEN/PCBTEXT` — 59,760 bytes / 747 records
- **License**: Clark Development Company source, © 1996, part of the freely
  redistributable PCBoard 15.41 release.

## See also

- `MCI-CODES.md` — companion analysis of `@TOKEN@` macros in prompts
- `PLANNED-FEATURES.md` — cross-reference for what Clark meant to add
- `pcb1541/install/dist/target/GEN/PCBTEXT` — the binary being analyzed

## Did Clark write notes about the 28 stub slots?

**Short answer: No explanatory notes. Only structural signals.**

The full source tree contains three files that authoritatively describe every
PCBTEXT slot:

1. **`pcb154/MAIN/SOURCE/H/PCBTEXT.H`** — the SDK header with `#define TXT_XXX N`
   entries. Deprecated slots have NO `#define` at all. Between `#17`, `#18`, `#19`
   and `#21`, `#22` there is simply a gap where `#20` and `#23` would go — no
   comment marks the absence.

2. **`pcb154/MAIN/SOURCE/DISPLAY/PCBTEXT.C`** — the runtime with the `UseText[]`
   bitflag array. Each 0 in the array tells the runtime "skip loading this slot".
   The array has only position markers (`/* 20 */`, `/* 30 */`, etc.) — no
   annotation on the individual zeros.

3. **`reference/pcball/pcboard/pcb-util/PCBTEXT/STRS15.C`** — the source of truth
   for the shipped binary. All 747 records are declared here with rich per-record
   metadata (flag, alignment, max length, color, text). Even the deprecated slots
   keep their text so `MKPCBTXT.EXE` can regenerate the binary preserving them.
   No slot has a note explaining WHY it's deprecated.

The full comment inventory in `STRS15.C` is just three blocks: the standard file
header, a compile note (`"merge duplicate strings" must be off`), and a caller-log
length note (`56 chars max for full-log records`). Nothing per-slot.

### What we CAN infer from the text itself

Reading the deprecated strings and cross-referencing PCBoard release history:

| Slot | Text | Why deprecated (inferred) |
|-----:|:-----|:--------------------------|
| 20 | `Printer Off-Line ...` | Hardcopy log-printer support — removed when BBSes moved to log files only |
| 23 | `Path error in system configuration!` | Replaced by specific per-directory error messages |
| 44 | `Error reading Script Questionnaire` | Replaced by newer questionnaire subsystem |
| 47 | `No record available to update!` | Message-base update error — replaced by specific error paths |
| 48 | `Messages Successfully Packed & Purified!` | Old PACK completion — combined into newer status output |
| 81 | `Purge older than (Enter)=010180` | Legacy purge default of 1980 — obsolete |
| 91 | `Reference Message number purification proceeding ...` | Old purification path — replaced by PCBPACK |
| 115 | `  Registered in Conferences` | Conference registration display — layout changed |
| 122 | `Enter (U) for status while awaiting other caller ...` | Waiting-for-caller prompt from early BBS-linking era |
| 124 | `Sorry, @FIRST@, PACK not available from remote ...` | PACK-from-remote restriction — policy changed |
| 147 | `Message Base Error!  Attempting to continue ...` | Recovery style — replaced by fatal-abort model |
| 151 | `Checking user file - please wait ...` | Old user-file scan — automated silently later |
| 172 | `Unable to write USER Record - Aborting!` | Replaced by more specific errors |
| 174 | `Number of Users Purged:` | Old PURGE stats — replaced by summary line |
| 183 | `PCBPACK Security Level Fail!` | Moved to different subsystem |
| 201 | `Error in filename request!` | Split into specific per-op errors |
| 202 | `Welcome back to PCBoard~` | Replaced by `DISPLAY` files (`WELCOME`, `WELFIRST`) |
| 205 | `Only ASCII and Kermit Protocols supported at 7-E-1!` | 7-E-1 parity restriction — obsolete after 8-N-1 standard |
| 206 | `Number of Msgs Purged :` | Old PURGE stats — see #174 |
| 207 | `Number of Bytes Purged:` | Old PURGE stats — see #174 |
| 362 | `Thread Read Terminated ...` | Replaced by generic terminate message |
| 364 | `Message Text Search Terminated ...` | Replaced by generic terminate message |
| 391 | `SHELL Batch file Missing (` | SHELL fallback — obsolete after DOOR system |
| 392 | `Resetting Packet ...` | Packet recovery from earlier protocol era |
| 410 | `Hanging Up Phone ...` | Old modem hangup — replaced by silent modem control |
| 432 | `Sorry, @FIRST@, Insufficient Security for \`From\` edit!` | Feature removed |
| 456 | `Pack Message Base Before Continuing!` | Automated in newer versions |
| 462 | `Assign More Message BLOCKS using PCBSetup!` | Configuration model changed |

These inferences are ours (based on text semantics + PCBoard history), not
Clark's — the source has no per-slot commentary.

### An interesting fossil in `PCBTEXT.C`

Right after the `UseText[]` array, `processtext()` contains a large **commented-out
switch statement** that would have provided hardcoded English fallback strings for
8 named prompts (`TXT_FILESSHOWPROMPT`, `TXT_ENTERDIRCMD`, `TXT_NOFILESFOUND`,
`TXT_DIRECTORYOF`, `TXT_SHORTINEFFECT`, `TXT_LONGINEFFECT`, `TXT_SHOWLONGDESC`,
`TXT_USESHORTDESC`). This was Clark's abandoned "safety net" for missing PCBTEXT
records — left in place as a comment rather than deleted. The runtime instead
trusts that PCBTEXT is well-formed and uses only whatever the file provides.

### An anomaly in the `MAIN` branch header

`pcb154/MAIN/SOURCE/H/PCBTEXT.H` contains a stray unclosed comment near the
15.4-additions block:

```c
/*
/*
/* 15.4 additions — prompts for Personal PSA fields and color selection.
 * Values match STRS15.C (extracted from 15.4b MKPCBTXT.EXE binary).
 * Slots 747-750 are the next unused after the 15.3 baseline of 746.
 */
```

The doubled `/*` looks like a merge or edit artifact. This is the ONE spot in the
whole PCBTEXT source tree where Clark (or a maintainer) wrote a substantive
freeform note — and it's about the 4 NEW slots (747-750), not the 28 old ones.

