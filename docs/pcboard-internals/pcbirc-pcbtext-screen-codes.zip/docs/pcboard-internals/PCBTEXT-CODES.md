# PCBoard Screen Prompts (PCBTEXT) — Complete Analysis

**Scope**: full inventory of the 747 prompt slots in `PCBTEXT` — the binary
file that holds every screen message, prompt, and error string PCBoard 15.3 /
15.41 displays. Cross-referenced against Clark's SDK headers, source code,
and the shipped binary in `pcb1541/install/dist/target/GEN/PCBTEXT`.

**Sources analyzed**:
- `pcb153/SOURCE/H/pcbtext.h` — 15.3 SDK header (718 named)
- `pcb153/upd154/SOURCE/H/pcbtext.h` — 15.41 SDK header (722 named)
- `pcb154/MAIN/SOURCE/H/PCBTEXT.H` — 15.41 MAIN branch header (722 named)
- `pcb154/MAIN/SOURCE/DISPLAY/PCBTEXT.C` — runtime dispatcher + `UseText[]` bitflags
- `pcb153/SOURCE/DISPLAY/PCBTEXT.C` — 15.3 runtime (identical layout)
- `pcb1541/install/dist/target/GEN/PCBTEXT` — shipped binary (747 records × 80 bytes)

## Headline findings

1. **747 slots. All 747 have text.** No empty records. Format: 80-byte fixed
   records, byte 0 is the color code (`0`-`8`), bytes 1-79 are space-padded text.

2. **Header + 716 active + 2 deprecated + 28 reserved = 747.** Every slot
   accounted for:
   - Slot 0: version string header (`"PCBoard version 14.5 & 15.0 & 15.2 & 15.3 PCBTEXT file"`)
   - 716 slots: named in `PCBTEXT.H` + marked "used" by `UseText[]==1` — actively displayed
   - 2 slots: named + `UseText[]==0` — legacy code path, name kept for source compat (#108 `TXT_USERSFILEPACKED`, #184 `TXT_RELOADINGPCBOARD`)
   - 28 slots: unnamed + `UseText[]==0` — pure legacy text, no code path reads them

3. **`UseText[]` is the ground truth.** The 8-bit-per-byte bitflag array in
   `PCBTEXT.C` at compile time tells the runtime whether each slot is active.
   The header (`PCBTEXT.H`) also omits names for the deprecated slots, but the
   bitflag is what actually gates whether the string is loaded.

4. **15.3 → 15.41 added 4 new prompts (#747-#750).** For gender, birthdate,
   web address, favorite color — user-registration extensions. But the shipped
   `PCBTEXT` binary is a 15.3-vintage file with 747 records (0..746), so slots
   747-750 are declared in the header but **not present** in the on-disk binary:
   - `#747` `TXT_ENTERGENDER` — declared, but PCBTEXT binary would need re-generation to include it
   - `#748` `TXT_ENTERBIRTHDATE` — declared, but PCBTEXT binary would need re-generation to include it
   - `#749` `TXT_ENTERWEBADDR` — declared, but PCBTEXT binary would need re-generation to include it
   - `#750` `TXT_ENTERCOLOR` — declared, but PCBTEXT binary would need re-generation to include it

## Classification

| Category | Count | Meaning |
|---|---:|---|
| Header | 1 | Slot 0 — version identifier |
| Active + named | 716 | Currently used by 15.3 / 15.41 |
| Deprecated + named | 2 | Name kept in header for source compat; runtime skips |
| Reserved + unnamed | 28 | Legacy text from older versions, name dropped |
| Missing from binary | 4 | New in 15.41 header, need re-generated PCBTEXT to appear |
| **Total in binary** | **747** | slots 0..746 |
| **Total in 15.41 header** | **750** | slots 1..750 |

## The 28 reserved unnamed slots (the "missing screen codes")

These are prompts Clark shipped in the binary but that neither the SDK header
nor the runtime code path uses. Third-party tools can only reference them by
numeric index — no symbolic constant exists. They're preserved for backward
compatibility with older PCBoard versions (14.5, 15.0) that displayed them.

| Slot | Color | Text |
|-----:|:-----:|:-----|
| 20 | 1 | `Printer Off-Line ...` |
| 23 | 1 | `Path error in system configuration!` |
| 44 | 1 | `Error reading Script Questionnaire` |
| 47 | 1 | `No record available to update!` |
| 48 | 6 | `Messages Successfully Packed & Purified!` |
| 81 | 2 | `Purge older than (Enter)=010180` |
| 91 | 2 | `Reference Message number purification proceeding ...` |
| 115 | 3 | `  Registered in Conferences` |
| 122 | 6 | `Enter (U) for status while awaiting other caller ...` |
| 124 | 1 | `Sorry, @FIRST@, PACK not available from remote ...` |
| 147 | 1 | `Message Base Error!  Attempting to continue ...` |
| 151 | 2 | `Checking user file - please wait ...` |
| 172 | 1 | `Unable to write USER Record - Aborting!` |
| 174 | 1 | `Number of Users Purged:` |
| 183 | 1 | `PCBPACK Security Level Fail!` |
| 201 | 1 | `Error in filename request!` |
| 202 | 6 | `Welcome back to PCBoard~` |
| 205 | 1 | `Only ASCII and Kermit Protocols supported at 7-E-1!` |
| 206 | 1 | `Number of Msgs Purged :` |
| 207 | 1 | `Number of Bytes Purged:` |
| 362 | 1 | `Thread Read Terminated ...` |
| 364 | 1 | `Message Text Search Terminated ...` |
| 391 | 1 | `SHELL Batch file Missing (` |
| 392 | 0 | `Resetting Packet ...` |
| 410 | 0 | `Hanging Up Phone ...` |
| 432 | 1 | `Sorry, @FIRST@, Insufficient Security for 'From' edit!` |
| 456 | 1 | `Pack Message Base Before Continuing!` |
| 462 | 1 | `Assign More Message BLOCKS using PCBSetup!` |

## The 2 deprecated named slots

These have names in `PCBTEXT.H` (so source code that includes the header still
compiles) but are marked `UseText[]==0` — the runtime never reads them. Kept
for source-level backward compatibility.

| Slot | Name | Color | Text |
|-----:|:-----|:-----:|:-----|
| 108 | `TXT_USERSFILEPACKED` | 7 | `User file successfully packed.` |
| 184 | `TXT_RELOADINGPCBOARD` | 7 | `Reloading PCBoard.  Please wait ...` |

## Color codes (byte 0 of each record)

| Code | Meaning | Typical use |
|:----:|:--------|:------------|
| `0` | Follow the display file's current color | Status messages, transient text |
| `1` | Bright red (errors) | Access denied, warnings, aborts |
| `2` | Bright green | Success messages, action prompts |
| `3` | Bright yellow | Configuration prompts |
| `4` | Bright blue | Rarely used |
| `5` | Bright magenta | Rarely used |
| `6` | Bright cyan | Info, welcome messages |
| `7` | Bright white | Prompts, questions |
| `8` | Bright dark grey | Rarely used |

Colors are DOS-style — foreground on background=0. The runtime combines with
the current display file's color state per the `PCBTEXT.C` dispatch logic.

## Record format

```
typedef struct {
  char Color;       // "0".."8" — foreground color code
  char Str[80];     // Prompt text, space-padded to 80 bytes (79 usable)
} pcbtexttype;
```

The struct is `#pragma pack(1)` so each record is exactly 81 bytes on disk?
No — the on-disk format is 80 bytes total: byte 0 is Color, bytes 1..79 are
text (79 chars max, space-padded). The `Str[80]` in the struct includes byte
index 0 through 79 giving 80 chars, but the on-disk layout uses 80 bytes total
with byte 0 as the color prefix. The C struct is a load-time interpretation.

## Provenance

- **Ground truth**: `pcb154/MAIN/SOURCE/DISPLAY/PCBTEXT.C` `UseText[]` bitflags
- **Name authority**: `pcb154/MAIN/SOURCE/H/PCBTEXT.H` — 722 `#define TXT_*` entries
- **Binary**: `pcb1541/install/dist/target/GEN/PCBTEXT` — 59,760 bytes / 747 records
- **License**: Clark Development Company source, © 1996, part of the freely
  redistributable PCBoard 15.41 release.

## See also

- `MCI-CODES.md` — companion analysis of `@TOKEN@` macros in prompts
- `PLANNED-FEATURES.md` — cross-reference for what Clark meant to add
- `pcb1541/install/dist/target/GEN/PCBTEXT` — the binary being analyzed