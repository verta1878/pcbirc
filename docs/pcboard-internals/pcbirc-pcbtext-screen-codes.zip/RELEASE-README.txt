pcbirc — PCBTEXT screen codes analysis
=======================================

PARITY CHECK RESULT

Fresh clone of origin/main verified. Origin HEAD: d7f0217 
"install v1.8 phase (three shipments)". 10509 tracked files.

Origin has advanced through:
  - v1.7.0 → reverted (Option A tried, rolled back per your "put them back")
  - v1.7.1 → 18 missing files landed from PCBDISK.002/003
  - v1.7.2 → track-back + real CRLF protection via .gitattributes
  - v1.8.0 → PPL samples cataloged for toolkit/pplc/
  - v1.8.1 → native LHA encoder scaffold
  - v1.8.2 → RUNTIME-DEPS.md

All my v1.7.1 work integrated. Everything I shipped is on origin.

SCREEN CODES INVESTIGATION

You said "a number of screen codes are missing." Traced back to Clark's
SDK headers vs the shipped PCBTEXT binary. Full analysis in this zip.

HEADLINE FINDINGS

  * PCBTEXT binary has 747 records (0..746). All 747 have text.
  * PCBTEXT.H (15.41) names only 722 constants — 25 unnamed slots.
  * Clark's PCBTEXT.C UseText[] bitflag array explicitly marks 31 slots
    as "not used" — slot 0 (header) + 2 named-but-deprecated (108, 184)
    + 28 unnamed-and-deprecated.

  The "missing screen codes" = these 28 unnamed slots that shipped in
  the binary but never got named constants in the SDK header:

     20, 23, 44, 47, 48, 81, 91, 115, 122, 124, 147, 151, 172, 174,
    183, 201, 202, 205, 206, 207, 362, 364, 391, 392, 410, 432, 456, 462

  These are LEGACY strings from PCBoard 14.5 / 15.0 that got dropped
  from the runtime but the text was kept in the binary. They're
  accessible only by numeric index — no symbolic constant exists.

  Examples:
    #20  "Printer Off-Line ..."          (from era when sysops printed logs)
    #202 "Welcome back to PCBoard~"      (replaced by DISPLAY files)
    #205 "Only ASCII and Kermit Protocols supported at 7-E-1!"
    #391 "SHELL Batch file Missing ("
    #410 "Hanging Up Phone ..."          (replaced by modem status)
    #456 "Pack Message Base Before Continuing!"

  Plus 2 deprecated-but-still-named:
    #108 TXT_USERSFILEPACKED  = "User file successfully packed."
    #184 TXT_RELOADINGPCBOARD = "Reloading PCBoard. Please wait ..."

  Plus 4 declared in the 15.41 header but NOT present in the binary
  (would need PCBTEXT regeneration):
    #747 TXT_ENTERGENDER
    #748 TXT_ENTERBIRTHDATE
    #749 TXT_ENTERWEBADDR
    #750 TXT_ENTERCOLOR

WHAT'S IN THIS ZIP

  docs/pcboard-internals/PCBTEXT-CODES.md  (new — 146 lines)
      Full analysis: 747-slot classification, deprecated/reserved
      inventory with text preview, color code reference, record
      format, provenance.

  docs/pcboard-internals/MCI-CODES.md      (updated — added cross-link)
      One-line addition to "See also" pointing to PCBTEXT-CODES.md.

APPLY

  1. Extract into repo root
  2. git add docs/pcboard-internals/*.md
  3. commit + push via GitHub Desktop

--hexadecimal
