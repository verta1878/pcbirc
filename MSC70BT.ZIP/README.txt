MSC70BT.ZIP - Microsoft C/C++ 7.0 (retail) build tools

Standalone Microsoft C 7.0 toolchain for building the PCBKMS family of
the pwa153 SDK. Parallel to PCB153BT.ZIP (Borland C++ 3.1) and
TC201BT.ZIP (Turbo C 2.01).

Extract to C:\MSC70 (DOS/Windows host) or the OS/2 equivalent.

  BIN\      DOS-hosted compiler (CL + C13216/C23216/C33216 + C1XX3216),
            LINK, LIB, NMAKE, MS32KRNL.DLL/MS32EM87.DLL
            NOTE: the DOS compiler needs a DPMI host (386-Max/Windows).
  INCLUDE\  standard headers (+ SYS\) - shared by both hosts
  LIB\      runtime libraries (SLIBCR/MLIBCR/CLIBCR/LLIBCR etc.)
  OS2\      OS/2 HOSTED add-on (C7 for OS/2) - runs in real 16-bit mode,
            NO DPMI. This is the preferred route for headless builds.
    BINP\   OS/2 protected-mode compiler (C11616/C21616/C31616/
            C1XX1616), CL, LINK, LIB, NMAKE, PWB
    BINB\   bound executables that run under BOTH DOS and OS/2
    DLL\    MSHELP.DLL

The OS/2 add-on uses the INCLUDE\ and LIB\ from the base product (both
included here), so OS2\ + INCLUDE\ + LIB\ is a complete 16-bit OS/2
compile environment. See MSC70\README.md and MSC70\OS2\README.OS2.
